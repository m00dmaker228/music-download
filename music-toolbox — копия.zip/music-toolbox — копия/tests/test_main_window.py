"""Smoke test of the GUI with the offscreen platform plugin."""

from __future__ import annotations

import os

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QEventLoop, QThreadPool, QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app.ui.main_window import MainWindow  # noqa: E402
from app.ui.state import AppState  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _spin(ms: int = 300) -> None:
    loop = QEventLoop()
    QTimer.singleShot(ms, loop.quit)
    loop.exec()


@pytest.mark.usefixtures("no_path_binaries")
def test_window_opens_with_five_tabs(qapp, fake_binary) -> None:
    from app.core import binaries, paths

    fake_binary(paths.bin_dir() / binaries.exe_name("yt-dlp"), "2026.10.01")

    state = AppState()
    win = MainWindow(state)
    win.show()
    titles = [win.tabs.tabText(i) for i in range(win.tabs.count())]
    assert titles == ["Завантажити", "Пошук", "Теги", "Обробка", "Налаштування"]

    # Binary probe runs in a worker thread; wait for it to report back.
    for _ in range(20):
        _spin(100)
        if state.binaries["yt-dlp"].available:
            break
    QThreadPool.globalInstance().waitForDone(2000)
    _spin(100)

    assert state.binaries["yt-dlp"].version == "2026.10.01"
    assert not state.binaries["ffmpeg"].available
    # Missing ffmpeg → settings tab selected, feature tabs disabled with a hint.
    assert win.tabs.currentWidget() is win.settings_tab
    assert not win.tags_tab.content.isEnabled()
    assert not win.tags_tab.banner.isHidden()  # tab page itself is not current
    assert "ffmpeg" in win.tags_tab.banner.text()
    assert "ffmpeg" in win.status_bins.text()
    assert win.settings_tab.bin_table.item(0, 2).text() == "2026.10.01"
    win.close()
