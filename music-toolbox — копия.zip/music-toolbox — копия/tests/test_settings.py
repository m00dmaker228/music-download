from __future__ import annotations

import json
from pathlib import Path

from app.core import paths, settings


def test_defaults() -> None:
    s = settings.Settings()
    assert s.work_dir.endswith("soundcloud")
    assert s.backup_dir == str(Path(s.work_dir) / "_backup")
    assert s.result_strategy == "new_file"
    assert 1 <= s.parallel_downloads <= 4


def test_roundtrip() -> None:
    s = settings.Settings(work_dir="/tmp/музика", parallel_downloads=3, default_format="opus")
    path = settings.save(s)
    assert path == paths.settings_file()
    loaded = settings.load()
    assert loaded == s
    # Cyrillic must be stored as-is, not escaped.
    assert "музика" in path.read_text(encoding="utf-8")


def test_load_missing_returns_defaults() -> None:
    assert settings.load() == settings.Settings()


def test_load_ignores_unknown_and_clamps() -> None:
    paths.settings_file().write_text(
        json.dumps({"parallel_downloads": 99, "bogus": 1, "result_strategy": "nope"}),
        encoding="utf-8",
    )
    s = settings.load()
    assert s.parallel_downloads == 4
    assert s.result_strategy == "new_file"


def test_load_corrupt_returns_defaults() -> None:
    paths.settings_file().write_text("{not json", encoding="utf-8")
    assert settings.load() == settings.Settings()
