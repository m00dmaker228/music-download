"""GUI-thread plumbing test; skipped when PySide6 isn't installed."""

from __future__ import annotations

import pytest

PySide6 = pytest.importorskip("PySide6")

from PySide6.QtCore import QCoreApplication, QEventLoop, QThreadPool, QTimer  # noqa: E402

from app.ui import workers  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QCoreApplication.instance() or QCoreApplication([])
    yield app


def _wait_done(worker: workers.Worker, qapp, timeout_ms: int = 5000) -> None:
    loop = QEventLoop()
    worker.signals.done.connect(loop.quit)
    QTimer.singleShot(timeout_ms, loop.quit)
    workers.start(worker)
    loop.exec()
    QThreadPool.globalInstance().waitForDone(timeout_ms)


def test_worker_success_and_progress(qapp) -> None:
    got: dict = {}

    def task(ctx, a, b=1):
        ctx.progress(step=1)
        ctx.log("hello")
        return a + b

    w = workers.Worker(task, 2, b=3)
    w.signals.progress.connect(lambda p: got.setdefault("progress", []).append(p))
    w.signals.log.connect(lambda m: got.setdefault("log", []).append(m))
    w.signals.finished.connect(lambda r: got.__setitem__("result", r))
    _wait_done(w, qapp)
    assert got["result"] == 5
    assert got["progress"] == [{"step": 1}]
    assert got["log"] == ["hello"]


def test_worker_error_is_reported(qapp) -> None:
    got: dict = {}

    def task(ctx):
        raise RuntimeError("bad things")

    w = workers.Worker(task)
    w.signals.error.connect(lambda m, tb: got.update(msg=m, tb=tb))
    _wait_done(w, qapp)
    assert got["msg"] == "bad things"
    assert "RuntimeError" in got["tb"]


def test_worker_cancel_flag(qapp) -> None:
    def task(ctx):
        return ctx.is_cancelled()

    w = workers.Worker(task)
    w.cancel()
    got: list = []
    w.signals.finished.connect(got.append)
    _wait_done(w, qapp)
    assert got == [True]
