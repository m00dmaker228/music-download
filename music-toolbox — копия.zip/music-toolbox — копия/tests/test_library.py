from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from app.core import library

ffmpeg = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(
    ffmpeg is None or shutil.which("ffprobe") is None, reason="ffmpeg/ffprobe not on PATH"
)


def _mp3(path: Path, seconds: float = 1.5, title: str | None = "T") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    meta = ["-metadata", f"title={title}", "-metadata", "album=PH_"] if title else []
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency=440:sample_rate=44100:duration={seconds}",
            *meta,
            "-c:a",
            "libmp3lame",
            "-b:a",
            "64k",
            str(path),
        ],
        check=True,
    )
    return path


def test_file_info(tmp_path: Path) -> None:
    p = _mp3(tmp_path / "PH_Artist - Song.mp3")
    info = library.file_info(p)
    assert info.prefix == "PH_"
    assert info.fmt == "mp3"
    assert info.duration and abs(info.duration - 1.5) < 0.2
    assert info.bitrate == 64
    assert info.sample_rate == 44100 and info.channels == 1
    assert info.has_tags and info.album == "PH_" and info.title == "T"


def test_scan_filters_recursive_and_caches(tmp_path: Path) -> None:
    work = tmp_path / "work"
    _mp3(work / "A_one.mp3")
    _mp3(work / "sub" / "B_two.mp3")
    (work / "notes.txt").write_text("x")
    cache = library.LibraryCache(tmp_path / "lib.sqlite3")

    flat = library.scan(work, recursive=False, cache=cache)
    assert [f.name for f in flat] == ["A_one.mp3"]
    deep = library.scan(work, recursive=True, cache=cache)
    assert sorted(f.name for f in deep) == ["A_one.mp3", "B_two.mp3"]

    # Second scan is served from cache (no ffprobe): patch probe to detect calls.
    calls: list[Path] = []
    orig = library.probe
    library.probe = lambda p, timeout=60: calls.append(p) or orig(p)
    try:
        again = library.scan(work, recursive=True, cache=cache)
    finally:
        library.probe = orig
    assert calls == []
    assert [f.path for f in again] == [f.path for f in deep]

    # Modified file is re-probed; deleted file is pruned from cache.
    _mp3(work / "A_one.mp3", seconds=2.5)
    (work / "sub" / "B_two.mp3").unlink()
    res = library.scan(work, recursive=True, cache=cache)
    assert [f.name for f in res] == ["A_one.mp3"]
    assert res[0].duration > 2
    assert cache.get(work / "sub" / "B_two.mp3") is None
    cache.close()


def test_scan_progress_and_cancel(tmp_path: Path) -> None:
    for i in range(3):
        _mp3(tmp_path / f"X_{i}.mp3")
    seen: list[int] = []
    res = library.scan(tmp_path, progress=lambda i, n, p: seen.append(i))
    assert seen == [1, 2, 3] and len(res) == 3
    res = library.scan(tmp_path, is_cancelled=lambda: True)
    assert res == []


def test_scan_missing_dir(tmp_path: Path) -> None:
    assert library.scan(tmp_path / "nope") == []
