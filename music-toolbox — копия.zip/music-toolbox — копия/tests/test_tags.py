from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from app.core import tags

FORMATS = {
    "mp3": ["-c:a", "libmp3lame", "-b:a", "64k"],
    "m4a": ["-c:a", "aac", "-b:a", "64k"],
    "opus": ["-c:a", "libopus", "-b:a", "48k"],
    "flac": ["-c:a", "flac"],
    "wav": ["-c:a", "pcm_s16le"],
}

ffmpeg = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(ffmpeg is None, reason="ffmpeg not on PATH")


def _make(tmp_path: Path, name: str, ext: str, with_tags: bool = True) -> Path:
    out = tmp_path / f"{name}.{ext}"
    meta = ["-metadata", "title=Old T", "-metadata", "artist=Old A", "-metadata", "album=Old L"]
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=44100:duration=1",
            *(meta if with_tags else []),
            *FORMATS[ext],
            str(out),
        ],
        check=True,
    )
    if ext == "wav" and with_tags:
        # ffmpeg writes RIFF INFO, which mutagen does not read; give the WAV an ID3 chunk.
        from mutagen.id3 import TALB, TIT2, TPE1
        from mutagen.wave import WAVE

        w = WAVE(out)
        w.add_tags()
        w.tags.add(TIT2(encoding=3, text=["Old T"]))
        w.tags.add(TPE1(encoding=3, text=["Old A"]))
        w.tags.add(TALB(encoding=3, text=["Old L"]))
        w.save()
    return out


@pytest.fixture
def png(tmp_path: Path) -> Path:
    img = tmp_path / "cover.png"
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=red:s=32x32",
            "-frames:v",
            "1",
            str(img),
        ],
        check=True,
    )
    return img


@pytest.mark.parametrize("ext", list(FORMATS))
def test_basic_tags_read(tmp_path: Path, ext: str) -> None:
    p = _make(tmp_path, "PH_Old A - Old T", ext)
    bt = tags.basic_tags(p)
    assert bt.has_any
    assert bt.title == "Old T" and bt.artist == "Old A" and bt.album == "Old L"
    rows = dict(tags.read_tags(p))
    assert any("Old T" in v for v in rows.values())
    assert "@length" in rows


@pytest.mark.parametrize("ext", list(FORMATS))
def test_strip_leaves_zero_tags(tmp_path: Path, ext: str) -> None:
    p = _make(tmp_path, "PH_x", ext)
    (r,) = tags.strip_metadata([p])
    assert r.ok, r.error
    bt = tags.basic_tags(p)
    assert not bt.has_any, tags.read_tags(p)
    assert bt.title == "" and bt.album == ""
    # Still playable / same duration.
    assert abs(tags.mutagen.File(p).info.length - 1.0) < 0.2


@pytest.mark.parametrize("ext", list(FORMATS))
def test_set_album_after_strip_only_album(tmp_path: Path, ext: str) -> None:
    p = _make(tmp_path, "PH_Artist - Song", ext)
    tags.strip_metadata([p])
    (r,) = tags.set_album_from_prefix([p])
    assert r.ok, r.error
    bt = tags.basic_tags(p)
    assert bt.album == "PH_" and bt.title == "" and bt.artist == ""
    keys = [k for k, _ in tags.read_tags(p) if not k.startswith("@")]
    assert len(keys) == 1, keys


def test_set_album_without_prefix_fails(tmp_path: Path) -> None:
    p = _make(tmp_path, "NoPrefix", "mp3")
    (r,) = tags.set_album_from_prefix([p])
    assert not r.ok and "префікс" in r.error


@pytest.mark.parametrize("ext", list(FORMATS))
def test_title_artist_from_name(tmp_path: Path, ext: str) -> None:
    p = _make(tmp_path, "PH_Some Artist - Some Title", ext)
    (r,) = tags.set_title_artist_from_name([p], "{prefix}{artist} - {title}")
    assert r.ok, r.error
    bt = tags.basic_tags(p)
    assert bt.artist == "Some Artist" and bt.title == "Some Title"


def test_title_from_name_no_prefix_in_file(tmp_path: Path) -> None:
    p = _make(tmp_path, "Artist - Title", "mp3")
    (r,) = tags.set_title_artist_from_name([p], "{prefix}{artist} - {title}")
    assert r.ok
    assert tags.basic_tags(p).artist == "Artist"


def test_template_mismatch_reports_error(tmp_path: Path) -> None:
    p = _make(tmp_path, "weird name", "mp3")
    (r,) = tags.set_title_artist_from_name([p], "{prefix}{artist} - {title}")
    assert not r.ok and "шаблон" in r.error


@pytest.mark.parametrize("ext", list(FORMATS))
def test_cover_add_and_remove(tmp_path: Path, ext: str, png: Path) -> None:
    p = _make(tmp_path, "PH_c", ext)
    (r,) = tags.add_cover([p], png)
    assert r.ok, r.error
    assert tags.basic_tags(p).has_cover
    assert tags.basic_tags(p).title == "Old T"  # text tags untouched
    (r,) = tags.remove_cover([p])
    assert r.ok, r.error
    assert not tags.basic_tags(p).has_cover
    assert tags.basic_tags(p).title == "Old T"


def test_progress_and_batch(tmp_path: Path) -> None:
    files = [_make(tmp_path, f"PH_{i}", "mp3") for i in range(3)]
    seen: list[tuple[int, int]] = []
    res = tags.strip_metadata(files, progress=lambda i, n, p: seen.append((i, n)))
    assert all(r.ok for r in res)
    assert seen == [(1, 3), (2, 3), (3, 3)]


def test_unsupported_file(tmp_path: Path) -> None:
    p = tmp_path / "PH_x.mp3"
    p.write_bytes(b"not audio at all")
    (r,) = tags.set_album_from_prefix([p])
    assert not r.ok


def test_prefix_of() -> None:
    assert tags.prefix_of(Path("PH_a_b.mp3")) == "PH_"
    assert tags.prefix_of(Path("nope.mp3")) == ""
    assert tags.prefix_of(Path("_x.mp3")) == "_"
