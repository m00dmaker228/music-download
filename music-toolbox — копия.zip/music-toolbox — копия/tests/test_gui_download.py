"""Offscreen GUI flow for the download tab with the fake yt-dlp."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.core import profiles  # noqa: E402
from app.core import settings as settings_mod  # noqa: E402
from app.core.models import Profile, QueueStatus  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402
from app.ui.state import AppState  # noqa: E402
from tests.test_gui_tags import spin, wait_until  # noqa: E402

pytestmark = pytest.mark.usefixtures("fake_ytdlp")


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def _window(tmp_path: Path):
    work = tmp_path / "work"
    settings_mod.save(settings_mod.Settings(work_dir=str(work), parallel_downloads=2))
    state = AppState()
    win = MainWindow(state)
    win.show()
    wait_until(lambda: state.binaries["yt-dlp"].available)
    return state, win, work


def test_playlist_download_skip_and_profiles(qapp, tmp_path: Path, monkeypatch) -> None:
    state, win, work = _window(tmp_path)
    tab = win.download_tab

    tab.url.setText("playlist://5")
    tab.prefix.setText("PH_")
    tab.range_from.setValue(2)
    tab.range_to.setValue(4)
    tab.btn_add.click()
    wait_until(lambda: tab.model.rowCount() == 3)
    wait_until(
        lambda: (
            all(it.status == QueueStatus.DONE for it in tab.model.items)
            and tab.controller.active == 0
        ),
        20000,
    )
    assert sorted(p.name for p in work.iterdir()) == [
        "PH_Title id2.m4a",
        "PH_Title id3.m4a",
        "PH_Title id4.m4a",
    ]
    assert [it.index for it in tab.model.items] == [2, 3, 4]
    assert all(it.progress == 100.0 for it in tab.model.items)
    assert "Завантажено: 3" in tab.counters.text()
    spin(200)
    assert state.archive.count() == 3

    # Second run of the same range: everything is skipped through the archive.
    tab.url.setText("playlist://5")
    tab.range_from.setValue(1)
    tab.range_to.setValue(5)
    tab.btn_add.click()
    wait_until(lambda: tab.model.rowCount() == 8)
    wait_until(
        lambda: tab.controller.active == 0 and tab.model.counts()[QueueStatus.PENDING] == 0, 20000
    )
    c = tab.model.counts()
    assert c[QueueStatus.SKIPPED] == 3 and c[QueueStatus.DONE] == 5

    # Hide finished + clear finished.
    tab.cb_hide.setChecked(True)
    assert tab.proxy.rowCount() == 0
    tab.btn_clear.click()
    assert tab.model.rowCount() == 0

    # Profile run starts after last_index and advances it.
    tab.profiles.append(Profile("Pl", "playlist://6", "PL_", last_index=4))
    profiles.save(tab.profiles)
    tab._fill_profiles()
    tab.prof_table.selectAll()
    tab.btn_run_profiles.click()
    wait_until(lambda: tab.model.rowCount() == 2)
    wait_until(
        lambda: tab.controller.active == 0 and tab.model.counts()[QueueStatus.PENDING] == 0, 20000
    )
    assert sorted(it.index for it in tab.model.items) == [5, 6]
    saved = {p.name: p for p in profiles.load()}
    assert saved["Pl"].last_index == 6 and saved["Pl"].last_run
    win.close()


def test_cancel_all_leaves_no_part_files(qapp, tmp_path: Path, monkeypatch) -> None:
    state, win, work = _window(tmp_path)
    tab = win.download_tab
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)

    for i in range(3):
        tab.url.setText(f"slow://s{i}")
        tab.btn_add.click()
        wait_until(lambda i=i: tab.model.rowCount() == i + 1)
    wait_until(lambda: tab.controller.active == 2)
    wait_until(lambda: any(it.progress > 0 for it in tab.model.items), 10000)
    assert list(work.glob("*.part"))
    tab.btn_cancel.click()
    wait_until(lambda: tab.controller.active == 0, 20000)
    spin(300)
    statuses = {it.status for it in tab.model.items}
    assert statuses == {QueueStatus.CANCELLED}
    assert not list(work.glob("*.part"))
    assert not list(work.glob("*.m4a"))

    # Retry failed/cancelled puts them back and finishes them.
    tab.btn_retry.click()
    wait_until(lambda: all(it.status == QueueStatus.DONE for it in tab.model.items), 60000)
    assert len(list(work.glob("*.m4a"))) == 3
    win.close()


def test_error_row_and_pause(qapp, tmp_path: Path, monkeypatch) -> None:
    state, win, work = _window(tmp_path)
    tab = win.download_tab
    shown: list[str] = []
    monkeypatch.setattr(QMessageBox, "critical", lambda *a, **k: shown.append(a[2]))

    # Listing failure is reported in a dialog + status label, nothing is queued.
    tab.url.setText("fail://list")
    tab.btn_add.click()
    wait_until(lambda: bool(shown), 10000)
    assert tab.model.rowCount() == 0 and "Помилка" in tab.form_status.text()

    tab.controller.pause()
    tab.url.setText("dlfail://x")
    tab.btn_add.click()
    wait_until(lambda: tab.model.rowCount() == 1)
    spin(300)
    assert tab.model.items[0].status == QueueStatus.PENDING  # paused: nothing starts
    assert tab.btn_pause.text() == "Продовжити"
    tab.btn_pause.click()
    wait_until(lambda: tab.model.items[0].status == QueueStatus.ERROR, 10000)
    assert "кодом 1" in tab.model.items[0].error
    assert "помилок: 1" in tab.counters.text()
    win.close()
