from __future__ import annotations

from pathlib import Path

from app.core.models import BinaryStatus, OpResult, QueueItem, QueueStatus, Track


def test_opresult_defaults() -> None:
    r = OpResult(Path("a.mp3"), ok=True)
    assert r.output_path is None and r.error is None


def test_binary_status_available() -> None:
    assert BinaryStatus("ffmpeg", Path("/x/ffmpeg"), "7").available
    assert not BinaryStatus("ffmpeg", None, None).available


def test_queue_item_defaults() -> None:
    t = Track(source="soundcloud", id="1", title="Song", url="https://sc/1")
    q = QueueItem(task_id="t1", track=t, prefix="PH_", fmt="original")
    assert q.status is QueueStatus.PENDING
    assert q.progress == 0.0
    assert str(QueueStatus.DONE) == "done"


def test_core_has_no_qt_imports() -> None:
    """Contract from the spec: `core/` must not import Qt."""
    core = Path(__file__).resolve().parents[1] / "app" / "core"
    for py in core.glob("*.py"):
        text = py.read_text(encoding="utf-8")
        assert "PySide6" not in text and "PyQt" not in text, py.name
