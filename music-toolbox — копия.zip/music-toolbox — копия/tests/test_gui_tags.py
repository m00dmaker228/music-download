"""End-to-end GUI flow offscreen: select files → strip → set album, via the real widgets."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QEventLoop, QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app.core import settings as settings_mod  # noqa: E402
from app.core import tags  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402
from app.ui.state import AppState  # noqa: E402

ffmpeg = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(
    ffmpeg is None or shutil.which("ffprobe") is None, reason="ffmpeg/ffprobe not on PATH"
)


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def spin(ms: int) -> None:
    loop = QEventLoop()
    QTimer.singleShot(ms, loop.quit)
    loop.exec()


def wait_until(cond, timeout_ms: int = 10000) -> None:
    waited = 0
    while not cond() and waited < timeout_ms:
        spin(50)
        waited += 50
    assert cond(), "timed out"


def make_mp3(path: Path) -> Path:
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:duration=1",
            "-metadata",
            "title=Old",
            "-c:a",
            "libmp3lame",
            "-b:a",
            "64k",
            str(path),
        ],
        check=True,
    )
    return path


def test_strip_then_album_via_gui(qapp, tmp_path: Path) -> None:
    work = tmp_path / "work"
    work.mkdir()
    files = [make_mp3(work / f"PH_song{i}.mp3") for i in range(2)]
    settings_mod.save(settings_mod.Settings(work_dir=str(work)))

    state = AppState()
    win = MainWindow(state)
    win.show()
    wait_until(lambda: state.has("ffmpeg", "ffprobe") and win.file_browser.model.rowCount() == 2)

    win.file_browser.table.selectAll()
    spin(50)
    assert len(state.selection) == 2

    tab = win.tags_tab
    tab.btn_strip.click()
    wait_until(lambda: not tab.batch.busy)
    assert tab.batch.table.rowCount() == 2
    assert all(not tags.basic_tags(f).has_any for f in files)

    tab.btn_album.click()
    wait_until(lambda: not tab.batch.busy)
    assert all(tags.basic_tags(f).album == "PH_" for f in files)
    assert all(tab.batch.table.item(r, 1).text() == "✓" for r in range(2))

    # Browser rescans after the batch and shows album + tags columns.
    wait_until(
        lambda: win.file_browser.model.files and win.file_browser.model.files[0].album == "PH_"
    )
    assert win.file_browser.model.files[0].has_tags

    # Single selection fills the read-only tag viewer.
    win.file_browser.table.clearSelection()
    win.file_browser.table.selectRow(0)
    wait_until(lambda: tab.view_table.rowCount() > 0)
    keys = [tab.view_table.item(r, 0).text() for r in range(tab.view_table.rowCount())]
    assert "TALB" in keys
    win.close()
