"""Shared fixtures: isolated data/config dirs, fake binaries, synthetic audio."""

from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

import pytest

from app.core import paths


@pytest.fixture(autouse=True)
def isolated_dirs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Every test gets its own data/config dirs; nothing touches the real home."""
    monkeypatch.setenv("MUSIC_TOOLBOX_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("MUSIC_TOOLBOX_CONFIG_DIR", str(tmp_path / "config"))
    paths.ensure_dirs()
    return tmp_path


def write_fake_binary(path: Path, stdout: str, exit_code: int = 0) -> Path:
    """Create a tiny executable that prints `stdout` and exits with `exit_code`."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        path = path.with_suffix(".bat") if path.suffix != ".exe" else path
        lines = [f"@echo {ln}" for ln in stdout.splitlines()] or ["@echo."]
        path.write_text("\r\n".join(lines) + f"\r\n@exit /b {exit_code}\r\n", encoding="utf-8")
    else:
        body = "#!/bin/sh\n" + "".join(f"printf '%s\\n' '{ln}'\n" for ln in stdout.splitlines())
        body += f"exit {exit_code}\n"
        path.write_text(body, encoding="utf-8")
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
    return path


@pytest.fixture
def fake_binary():
    return write_fake_binary


@pytest.fixture
def no_path_binaries(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make PATH lookups fail so tests only see what they create."""
    monkeypatch.setenv("PATH", os.devnull)


# ---- real ffmpeg (optional): synthetic audio fixtures for later stages


def _real_ffmpeg() -> str | None:
    return shutil.which("ffmpeg")


requires_ffmpeg = pytest.mark.skipif(_real_ffmpeg() is None, reason="ffmpeg not on PATH")


@pytest.fixture
def sine_wav(tmp_path: Path) -> Path:
    """2-second 440 Hz sine, 44.1 kHz mono WAV, generated with ffmpeg."""
    ffmpeg = _real_ffmpeg()
    if ffmpeg is None:
        pytest.skip("ffmpeg not on PATH")
    out = tmp_path / "sine.wav"
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=44100:duration=2",
            "-ac",
            "1",
            str(out),
        ],
        check=True,
    )
    return out


# ---- fake yt-dlp (python script) wired through binaries.find


@pytest.fixture
def fake_ytdlp(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Route `binaries.find("yt-dlp")` to tests/fake_ytdlp.py (portable, no shebang needed)."""
    from app.core import binaries

    script = Path(__file__).parent / "fake_ytdlp.py"
    if sys.platform == "win32":
        launcher = tmp_path / "yt-dlp.bat"
        launcher.write_text(f'@"{sys.executable}" "{script}" %*\r\n', encoding="utf-8")
    else:
        launcher = tmp_path / "yt-dlp"
        launcher.write_text(
            f'#!/bin/sh\nexec "{sys.executable}" "{script}" "$@"\n', encoding="utf-8"
        )
        launcher.chmod(0o755)
    real_find = binaries.find

    def find(name: str):
        if name == "yt-dlp":
            return launcher
        return real_find(name)

    monkeypatch.setattr(binaries, "find", find)
    return launcher
