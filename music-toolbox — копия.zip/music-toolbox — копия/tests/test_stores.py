from __future__ import annotations

import pytest

from app.core import presets, profiles
from app.core.models import Preset, Profile


def test_profiles_crud_roundtrip() -> None:
    items = profiles.load()
    assert items == []
    profiles.add(items, Profile("PH", "https://sc/ph", "PH_"))
    profiles.add(items, Profile("DN", "https://sc/dn", "DN_", active=False))
    with pytest.raises(ValueError):
        profiles.add(items, Profile("PH", "x", "y"))
    profiles.update(items, "DN", Profile("DN2", "https://sc/dn2", "DN_"))
    with pytest.raises(KeyError):
        profiles.update(items, "nope", Profile("z", "z", "z"))
    profiles.mark_run(items[0], 42)
    profiles.save(items)
    loaded = profiles.load()
    assert [p.name for p in loaded] == ["PH", "DN2"]
    assert loaded[0].last_index == 42 and loaded[0].last_run
    profiles.remove(loaded, "PH")
    assert [p.name for p in loaded] == ["DN2"]


def test_presets_builtin_then_custom() -> None:
    items = presets.load()
    assert any(p.operation == "speed" and p.params["factor"] == 1.25 for p in items)
    presets.upsert(items, Preset("Мій", "tempo", {"factor": 1.1}))
    presets.upsert(items, Preset("Мій", "tempo", {"factor": 1.2}))
    presets.save(items)
    loaded = presets.load()
    mine = [p for p in loaded if p.name == "Мій"]
    assert len(mine) == 1 and mine[0].params["factor"] == 1.2
    presets.remove(loaded, "Мій")
    presets.save(loaded)
    assert not any(p.name == "Мій" for p in presets.load())


def test_corrupt_store_is_ignored() -> None:
    from app.core import paths

    paths.profiles_file().parent.mkdir(parents=True, exist_ok=True)
    paths.profiles_file().write_text(
        '[{"name": 1}, "junk", {"name": "ok", "url": "u", "prefix": "p"}]'
    )
    assert [p.name for p in profiles.load()] == ["ok"]
