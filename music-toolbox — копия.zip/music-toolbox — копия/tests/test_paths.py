from __future__ import annotations

from pathlib import Path

from app.core import paths


def test_env_override(tmp_path: Path) -> None:
    assert paths.data_dir() == tmp_path / "data"
    assert paths.config_dir() == tmp_path / "config"
    assert paths.bin_dir() == tmp_path / "data" / "bin"
    assert paths.settings_file() == tmp_path / "config" / "settings.json"
    assert paths.log_file().parent == tmp_path / "data" / "logs"


def test_ensure_dirs_creates_everything() -> None:
    for d in (paths.data_dir(), paths.config_dir(), paths.bin_dir(), paths.log_dir()):
        assert d.is_dir()


def test_default_locations_without_override(monkeypatch) -> None:
    monkeypatch.delenv("MUSIC_TOOLBOX_DATA_DIR")
    monkeypatch.delenv("MUSIC_TOOLBOX_CONFIG_DIR")
    if paths.IS_WINDOWS:
        monkeypatch.setenv("LOCALAPPDATA", r"C:\Users\u\AppData\Local")
        assert paths.data_dir() == Path(r"C:\Users\u\AppData\Local") / "MusicToolbox"
        assert paths.config_dir() == paths.data_dir()
    else:
        monkeypatch.setenv("XDG_DATA_HOME", "/x/data")
        monkeypatch.setenv("XDG_CONFIG_HOME", "/x/config")
        assert paths.data_dir() == Path("/x/data/MusicToolbox")
        assert paths.config_dir() == Path("/x/config/MusicToolbox")


def test_app_root_is_project_root() -> None:
    assert (paths.app_root() / "pyproject.toml").is_file()
