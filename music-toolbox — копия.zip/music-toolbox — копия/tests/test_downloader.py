from __future__ import annotations

import threading
import time
from pathlib import Path

import pytest

from app.core import downloader
from app.core.archive import Archive

pytestmark = pytest.mark.usefixtures("fake_ytdlp")


# ---------------------------------------------------------------- helpers


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ('a/b:c*d?e"f<g>h|i', "a_b_c_d_e_f_g_h_i"),
        ("  Трек. ", "Трек"),
        ("", "untitled"),
        ("...", "untitled"),
    ],
)
def test_sanitize_filename(raw: str, expected: str) -> None:
    assert downloader.sanitize_filename(raw) == expected


def test_output_template(tmp_path: Path) -> None:
    t = downloader.output_template(tmp_path, "PH_", "{prefix}{title}.{ext}")
    assert t == str(tmp_path / "PH_%(title)s.%(ext)s")
    t = downloader.output_template(tmp_path, "", "{artist} - {title}")
    assert t == str(tmp_path / "%(uploader)s - %(title)s.%(ext)s")
    t = downloader.output_template(tmp_path, "50%_", "{title}")
    assert t == str(tmp_path / "50%%_%(title)s.%(ext)s")


def test_track_from_info() -> None:
    tr = downloader.track_from_info(
        {"ie_key": "Youtube", "id": "x1", "title": "T", "url": "https://y/x1", "duration": 10}
    )
    assert tr.source == "youtube" and tr.id == "x1" and tr.duration == 10.0


# ---------------------------------------------------------------- listing


def test_list_playlist() -> None:
    info = downloader.list_playlist("playlist://5")
    assert info.kind == "playlist"
    assert info.title == "My Playlist"
    assert [t.id for t in info.entries] == ["id1", "id2", "id3", "id4", "id5"]
    assert info.entries[0].source == "soundcloud"


def test_list_playlist_with_range() -> None:
    info = downloader.list_playlist("playlist://10", items="3:5")
    assert [t.id for t in info.entries] == ["id3", "id4", "id5"]


def test_list_single_track() -> None:
    info = downloader.list_playlist("track://abc")
    assert info.kind == "track"
    assert info.entries[0].title == "Title abc"


def test_list_failure_raises() -> None:
    with pytest.raises(RuntimeError):
        downloader.list_playlist("fail://x")


# ---------------------------------------------------------------- download


def test_download_track_progress_and_file(tmp_path: Path) -> None:
    dest = tmp_path / "out"
    events: list[dict] = []
    res = downloader.download_track(
        "track://abc", dest, prefix="PH_", fmt="original", progress=events.append
    )
    assert res.ok, res.error
    assert res.path == dest / "PH_Title abc.m4a"
    assert res.path.is_file() and res.path.stat().st_size == 1000
    assert res.track_id == "abc" and res.source == "soundcloud"
    statuses = [e["status"] for e in events]
    assert statuses[0] == "downloading" and "finished" in statuses
    assert all("info_dict" not in e for e in events)
    assert events[0]["track_id"] == "abc"
    assert not list(dest.glob("*.part"))


def test_download_mp3_format_reports_postprocess(tmp_path: Path) -> None:
    events: list[dict] = []
    res = downloader.download_track("track://q", tmp_path, fmt="mp3_320", progress=events.append)
    assert res.ok and res.path.suffix == ".mp3"
    assert any(e["phase"] == "postprocess" for e in events)


def test_download_already_exists(tmp_path: Path) -> None:
    existing = tmp_path / "Title z.m4a"
    existing.write_bytes(b"old")
    res = downloader.download_track("exists://z", tmp_path)
    assert res.ok and res.path == existing


def test_download_failure(tmp_path: Path) -> None:
    logs: list[str] = []
    res = downloader.download_track("fail://z", tmp_path, log_fn=logs.append)
    assert not res.ok and "кодом 1" in res.error
    assert any("fake failure" in ln for ln in logs)


def test_download_cancel_removes_part(tmp_path: Path) -> None:
    cancel = threading.Event()
    seen = threading.Event()

    def progress(_p: dict) -> None:
        seen.set()

    def runner() -> None:
        global result
        result = downloader.download_track(
            "slow://c", tmp_path, progress=progress, is_cancelled=cancel.is_set
        )

    t = threading.Thread(target=runner)
    t.start()
    assert seen.wait(5)
    time.sleep(0.3)
    cancel.set()
    t.join(15)
    assert not t.is_alive()
    assert result.cancelled and not result.ok
    assert not list(tmp_path.glob("*.part"))
    assert not (tmp_path / "Title c.m4a").exists()


def test_unknown_format(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        downloader.download_track("track://a", tmp_path, fmt="wma")


# ---------------------------------------------------------------- archive


def test_archive_roundtrip(tmp_path: Path) -> None:
    with Archive(tmp_path / "a.sqlite3") as ar:
        assert not ar.has("soundcloud", "1")
        ar.add("soundcloud", "1", tmp_path / "x.mp3", "X")
        ar.add("soundcloud", "1", tmp_path / "x.mp3", "X")  # idempotent
        assert ar.has("soundcloud", "1")
        assert ar.count() == 1
        ar.remove("soundcloud", "1")
        assert not ar.has("soundcloud", "1")
