from __future__ import annotations

import io
import subprocess
import tarfile
import zipfile
from pathlib import Path

import pytest

from app.core import binaries, paths

pytestmark = pytest.mark.usefixtures("no_path_binaries")


# ---------------------------------------------------------------- lookup


def test_find_returns_none_when_missing() -> None:
    assert binaries.find("yt-dlp") is None
    assert binaries.status("ffmpeg").available is False


def test_find_prefers_data_dir(fake_binary) -> None:
    exe = fake_binary(paths.bin_dir() / binaries.exe_name("yt-dlp"), "2026.10.01")
    assert binaries.find("yt-dlp") == exe


def test_find_rejects_unknown_name() -> None:
    with pytest.raises(ValueError):
        binaries.find("sox")


def test_find_falls_back_to_path(fake_binary, tmp_path: Path, monkeypatch) -> None:
    exe = fake_binary(tmp_path / "onpath" / binaries.exe_name("ffprobe"), "ffprobe version 7.1")
    monkeypatch.setenv("PATH", str(exe.parent))
    found = binaries.find("ffprobe")
    assert found is not None and found.parent == exe.parent


# ---------------------------------------------------------------- version


@pytest.mark.parametrize(
    ("name", "output", "expected"),
    [
        ("yt-dlp", "2026.10.01\n", "2026.10.01"),
        (
            "ffmpeg",
            "ffmpeg version N-118000-gabcdef Copyright (c) 2000-2026\n built with gcc",
            "N-118000-gabcdef",
        ),
        (
            "ffprobe",
            "ffprobe version 7.1.1-full_build-www.gyan.dev Copyright",
            "7.1.1-full_build-www.gyan.dev",
        ),
        ("ffmpeg", "", None),
        ("ffmpeg", "something weird", "something weird"),
    ],
)
def test_parse_version(name: str, output: str, expected: str | None) -> None:
    assert binaries.parse_version(name, output) == expected


def test_version_runs_binary(fake_binary) -> None:
    fake_binary(paths.bin_dir() / binaries.exe_name("yt-dlp"), "2026.10.01")
    fake_binary(paths.bin_dir() / binaries.exe_name("ffmpeg"), "ffmpeg version 8.0-gpl")
    assert binaries.version("yt-dlp") == "2026.10.01"
    assert binaries.version("ffmpeg") == "8.0-gpl"
    st = binaries.status_all()
    assert st["yt-dlp"].version == "2026.10.01"
    assert st["ffprobe"].available is False
    assert binaries.all_available() is False


def test_version_failing_binary_returns_none(fake_binary) -> None:
    fake_binary(paths.bin_dir() / binaries.exe_name("yt-dlp"), "boom", exit_code=1)
    assert binaries.version("yt-dlp") is None


# ---------------------------------------------------------------- subprocess helpers


def test_popen_kwargs_utf8_and_no_window() -> None:
    kw = binaries.popen_kwargs()
    assert kw["encoding"] == "utf-8"
    assert kw["env"]["PYTHONIOENCODING"] == "utf-8"
    if binaries.IS_WINDOWS:
        assert kw["creationflags"] == binaries.CREATE_NO_WINDOW
    else:
        assert "creationflags" not in kw


def test_popen_streams_utf8_lines(fake_binary) -> None:
    exe = fake_binary(paths.bin_dir() / binaries.exe_name("ffmpeg"), "рядок один\nрядок два")
    proc = binaries.popen([exe])
    out = proc.stdout.read().splitlines()
    proc.wait()
    assert out == ["рядок один", "рядок два"]
    assert proc.returncode == 0


def test_run_captures_output(fake_binary) -> None:
    exe = fake_binary(paths.bin_dir() / binaries.exe_name("ffprobe"), "hello")
    cp = binaries.run([exe])
    assert isinstance(cp, subprocess.CompletedProcess)
    assert cp.stdout.strip() == "hello"


def test_format_command_logged(fake_binary, caplog) -> None:
    exe = fake_binary(paths.bin_dir() / binaries.exe_name("yt-dlp"), "x")
    with caplog.at_level("INFO", logger="app.core.binaries"):
        binaries.run([exe, "--version"])
    assert any("RUN" in r.message and "--version" in r.message for r in caplog.records)


# ---------------------------------------------------------------- download / install


class _FakeResponse(io.BytesIO):
    def __init__(self, data: bytes, length: int | None) -> None:
        super().__init__(data)
        self.headers = {"Content-Length": str(length)} if length is not None else {}

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def test_download_reports_progress_and_is_atomic(monkeypatch, tmp_path: Path) -> None:
    payload = b"x" * (binaries._CHUNK * 2 + 10)
    monkeypatch.setattr(
        binaries, "urlopen", lambda req, timeout: _FakeResponse(payload, len(payload))
    )
    seen: list[tuple[str, int, int]] = []
    dest = tmp_path / "out.bin"
    binaries.download("https://example/x", dest, lambda s, d, t: seen.append((s, d, t)))
    assert dest.read_bytes() == payload
    assert not dest.with_name("out.bin.tmp").exists()
    assert seen[0] == ("out.bin", 0, len(payload))
    assert seen[-1] == ("out.bin", len(payload), len(payload))


def test_download_cancel_removes_tmp(monkeypatch, tmp_path: Path) -> None:
    payload = b"y" * (binaries._CHUNK * 3)
    monkeypatch.setattr(binaries, "urlopen", lambda req, timeout: _FakeResponse(payload, None))
    dest = tmp_path / "out.bin"
    with pytest.raises(binaries.CancelledError):
        binaries.download("https://example/x", dest, is_cancelled=lambda: True)
    assert not dest.exists()
    assert not dest.with_name("out.bin.tmp").exists()


def test_install_ytdlp_places_executable(monkeypatch) -> None:
    monkeypatch.setattr(
        binaries, "urlopen", lambda req, timeout: _FakeResponse(b"#!/bin/sh\nexit 0\n", 16)
    )
    monkeypatch.setattr(binaries, "version", lambda name: "fake")
    (dest,) = binaries.install("yt-dlp")
    assert dest == paths.bin_dir() / binaries.exe_name("yt-dlp")
    assert dest.is_file()
    if not binaries.IS_WINDOWS:
        assert dest.stat().st_mode & 0o111


def _zip_archive(tmp_path: Path) -> Path:
    arc = tmp_path / "ffmpeg-master-latest-win64-gpl.zip"
    with zipfile.ZipFile(arc, "w") as zf:
        root = "ffmpeg-master-latest-win64-gpl"
        zf.writestr(f"{root}/bin/{binaries.exe_name('ffmpeg')}", b"FF")
        zf.writestr(f"{root}/bin/{binaries.exe_name('ffprobe')}", b"FP")
        zf.writestr(f"{root}/bin/{binaries.exe_name('ffplay')}", b"no")
        zf.writestr(f"{root}/LICENSE.txt", b"...")
    return arc


def _tar_archive(tmp_path: Path) -> Path:
    arc = tmp_path / "ffmpeg-master-latest-linux64-gpl.tar.xz"
    with tarfile.open(arc, "w:xz") as tf:
        root = "ffmpeg-master-latest-linux64-gpl"
        for name, data in (("ffmpeg", b"FF"), ("ffprobe", b"FP"), ("ffplay", b"no")):
            info = tarfile.TarInfo(f"{root}/bin/{binaries.exe_name(name)}")
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    return arc


@pytest.mark.parametrize("maker", [_zip_archive, _tar_archive])
def test_extract_ffmpeg_archive(tmp_path: Path, maker) -> None:
    out = binaries.extract_ffmpeg_archive(maker(tmp_path), paths.bin_dir())
    names = sorted(p.name for p in out)
    assert names == sorted([binaries.exe_name("ffmpeg"), binaries.exe_name("ffprobe")])
    assert (paths.bin_dir() / binaries.exe_name("ffmpeg")).read_bytes() == b"FF"
    assert not (paths.bin_dir() / binaries.exe_name("ffplay")).exists()


def test_extract_ffmpeg_archive_incomplete(tmp_path: Path) -> None:
    arc = tmp_path / "bad.zip"
    with zipfile.ZipFile(arc, "w") as zf:
        zf.writestr(f"x/bin/{binaries.exe_name('ffmpeg')}", b"FF")
    with pytest.raises(RuntimeError):
        binaries.extract_ffmpeg_archive(arc, paths.bin_dir())


def test_install_ffmpeg_end_to_end(monkeypatch, tmp_path: Path) -> None:
    arc = _zip_archive(tmp_path) if binaries.IS_WINDOWS else _tar_archive(tmp_path)
    data = arc.read_bytes()
    monkeypatch.setattr(binaries, "urlopen", lambda req, timeout: _FakeResponse(data, len(data)))
    monkeypatch.setattr(binaries, "version", lambda name: "fake")
    out = binaries.install("ffprobe")
    assert len(out) == 2
    assert binaries.find("ffmpeg") is not None
    assert binaries.find("ffprobe") is not None


def test_install_unknown() -> None:
    with pytest.raises(ValueError):
        binaries.install("sox")
