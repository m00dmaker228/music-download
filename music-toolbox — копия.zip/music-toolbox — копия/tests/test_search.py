from __future__ import annotations

import io
import json

import pytest

from app.core import search

pytestmark = pytest.mark.usefixtures("fake_ytdlp")


def test_search_source_soundcloud() -> None:
    tracks = search.search_source("hello world", "soundcloud", limit=10)
    assert [t.title for t in tracks] == ["hello world result 1", "hello world result 2"]
    assert all(t.source == "soundcloud" for t in tracks)
    yt = search.search_source("hello", "youtube")
    assert yt and all(t.source == "youtube" for t in yt)


def test_search_all_parallel(monkeypatch) -> None:
    def fake(query, source, limit=10, timeout=120):
        if source == "youtube":
            raise RuntimeError("yt down")
        return [search.Track(source, f"{source}1", f"{query} {source}", "https://x/1")]

    monkeypatch.setattr(search, "search_source", fake)
    res = search.search_all("q", ["soundcloud", "youtube"])
    assert isinstance(res["youtube"], RuntimeError)
    assert res["soundcloud"][0].title == "q soundcloud"
    assert search.search_all("q", []) == {}


def test_search_source_unknown() -> None:
    with pytest.raises(ValueError):
        search.search_source("x", "spotify")
    assert search.search_source("   ", "youtube") == []


def test_itunes_lookup(monkeypatch) -> None:
    payload = {
        "results": [
            {
                "trackName": "Song",
                "artistName": "Artist",
                "collectionName": "Album",
                "releaseDate": "2019-05-01T07:00:00Z",
                "trackTimeMillis": 215000,
            }
        ]
    }

    class Resp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            self.close()

    seen = {}

    def fake_urlopen(req, timeout):
        seen["url"] = req.full_url
        return Resp(json.dumps(payload).encode())

    monkeypatch.setattr(search, "urlopen", fake_urlopen)
    hits = search.itunes_lookup("Artist Song", limit=3)
    assert hits[0].title == "Song" and hits[0].year == "2019" and hits[0].duration == 215.0
    assert "term=Artist+Song" in seen["url"] and "limit=3" in seen["url"]
    assert search.itunes_lookup("") == []
