"""Offscreen GUI flow: select wav → tempo x2 → result listed; presets save/apply."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QInputDialog  # noqa: E402

from app.core import presets, process  # noqa: E402
from app.core import settings as settings_mod  # noqa: E402
from app.core.models import Preset  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402
from app.ui.state import AppState  # noqa: E402
from tests.test_gui_tags import spin, wait_until  # noqa: E402

ffmpeg = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(
    ffmpeg is None or shutil.which("ffprobe") is None, reason="ffmpeg/ffprobe not on PATH"
)


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def test_tempo_and_presets_via_gui(qapp, tmp_path: Path, monkeypatch) -> None:
    work = tmp_path / "work"
    work.mkdir()
    wav = work / "PH_a.wav"
    subprocess.run(
        [ffmpeg, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=duration=4", str(wav)],
        check=True,
    )
    settings_mod.save(settings_mod.Settings(work_dir=str(work)))

    state = AppState()
    win = MainWindow(state)
    win.show()
    wait_until(lambda: state.has("ffmpeg", "ffprobe") and win.file_browser.model.rowCount() == 1)
    win.file_browser.table.selectAll()
    spin(50)

    tab = win.process_tab
    tab.op_list.setCurrentRow(0)  # tempo
    tab.current_form().widgets["factor"].setValue(2.0)
    tab.btn_run.click()
    wait_until(lambda: not tab.batch.busy, 30000)
    assert tab.batch.table.rowCount() == 1
    assert tab.batch.table.item(0, 1).text() == "✓"
    out = work / "PH_a_tempo2.wav"
    assert out.exists() and abs(process.duration_of(out) - 2.0) < 0.15
    wait_until(lambda: win.file_browser.model.rowCount() == 2)

    # Save current settings as a preset, then apply a built-in one.
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **k: ("Двічі швидше", True))
    tab.btn_preset_save.click()
    assert any(p.name == "Двічі швидше" and p.params["factor"] == 2.0 for p in presets.load())

    tab.presets.append(Preset("Low", "normalize", {"lufs": -20.0}))
    tab._fill_presets()
    tab.preset_combo.setCurrentIndex(tab.preset_combo.findData("Low"))
    tab.btn_preset_apply.click()
    assert tab.current_spec().key == "normalize"
    assert tab.current_form().widgets["lufs"].value() == -20.0
    win.close()
