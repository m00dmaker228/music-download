"""Stand-in for yt-dlp used by the test-suite.

Behaviour is controlled by the URL it is asked to handle:
  playlist://N          -J → playlist with N entries
  track://ID            -J → single track; download → writes a file and emits progress
  slow://ID             like track:// but takes ~10 s (for cancellation tests)
  fail://ID             exits with code 1
  exists://ID           prints "has already been downloaded"
"""

from __future__ import annotations

import json
import os
import sys
import time


def _arg(flag: str, default: str | None = None) -> str | None:
    if flag in sys.argv:
        return sys.argv[sys.argv.index(flag) + 1]
    return default


def main() -> int:
    argv = sys.argv[1:]
    if "--version" in argv:
        print("2026.10.21-fake")
        return 0
    url = argv[-1]
    if url.startswith(("scsearch", "ytsearch")):
        url = "search://" + url
    scheme, _, rest = url.partition("://")
    if "-J" in argv:
        if scheme == "fail":
            print("ERROR: [generic] Unsupported URL (fake)")
            return 1
        if scheme == "playlist":
            n = int(rest)
            items = _arg("--playlist-items")
            lo, hi = 1, n
            if items:
                a, _, b = items.partition(":")
                lo, hi = int(a or 1), int(b or n)
            entries = [
                {
                    "ie_key": "Soundcloud",
                    "id": f"id{i}",
                    "title": f"Track {i}",
                    "url": f"track://id{i}",
                    "uploader": "Uploader",
                    "duration": 100 + i,
                }
                for i in range(lo, hi + 1)
            ]
            print(json.dumps({"_type": "playlist", "title": "My Playlist", "entries": entries}))
            return 0
        if scheme == "search":
            # scsearch5:query / ytsearch5:query
            kind, _, query = rest.partition(":")
            ie = "Youtube" if kind.startswith("yt") else "Soundcloud"
            entries = [
                {
                    "ie_key": ie,
                    "id": f"{kind}{i}",
                    "title": f"{query} result {i}",
                    "url": f"https://example/{kind}/{i}",
                    "uploader": "Someone",
                    "duration": 200,
                }
                for i in range(1, 3)
            ]
            print(json.dumps({"_type": "playlist", "entries": entries}))
            return 0
        print(
            json.dumps(
                {
                    "extractor_key": "Soundcloud",
                    "id": rest,
                    "title": f"Title {rest}",
                    "webpage_url": url,
                    "uploader": "Uploader",
                    "duration": 123.4,
                }
            )
        )
        return 0

    # ---- download mode
    out_tpl = _arg("-o") or "%(title)s.%(ext)s"
    ext = "mp3" if "mp3" in argv else "m4a"
    title = f"Title {rest}"
    filename = out_tpl.replace("%(title)s", title).replace("%(ext)s", ext)
    info = {"id": rest, "ie_key": "Soundcloud", "title": title}
    if scheme in ("fail", "dlfail"):
        print("ERROR: Unable to download: fake failure")
        return 1
    if scheme == "exists":
        print(f"[download] {filename} has already been downloaded")
        return 0
    total = 1000
    steps = 50 if scheme == "slow" else 4
    delay = 0.2 if scheme == "slow" else 0.0
    part = filename + ".part"
    os.makedirs(os.path.dirname(filename) or ".", exist_ok=True)
    with open(part, "wb") as fh:
        for i in range(1, steps + 1):
            fh.write(b"x" * (total // steps))
            fh.flush()
            print(
                json.dumps(
                    {
                        "status": "downloading",
                        "downloaded_bytes": total * i // steps,
                        "total_bytes": total,
                        "speed": 12345.0,
                        "eta": steps - i,
                        "filename": filename,
                        "info_dict": info,
                    }
                ),
                flush=True,
            )
            time.sleep(delay)
    os.replace(part, filename)
    print(
        json.dumps(
            {
                "status": "finished",
                "downloaded_bytes": total,
                "total_bytes": total,
                "filename": filename,
                "info_dict": info,
            }
        ),
        flush=True,
    )
    if "-x" in argv:
        print(json.dumps({"status": "started", "postprocessor": "ExtractAudio", "info_dict": info}))
    print(f"MTB_FILE={filename}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
