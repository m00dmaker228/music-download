from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from app.core import process
from app.core.process import OutputPolicy

ffmpeg = shutil.which("ffmpeg")
pytestmark = pytest.mark.skipif(
    ffmpeg is None or shutil.which("ffprobe") is None, reason="ffmpeg/ffprobe not on PATH"
)


def gen(
    path: Path, seconds: float = 4.0, silence_pad: float = 0.0, codec: list | None = None
) -> Path:
    """Sine (optionally padded with silence on both sides) into `path`."""
    src = f"sine=frequency=440:sample_rate=44100:duration={seconds}"
    af = []
    if silence_pad:
        af = [
            "-af",
            f"adelay={int(silence_pad * 1000)}|{int(silence_pad * 1000)},"
            f"apad=pad_dur={silence_pad}",
        ]
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-loglevel",
            "error",
            "-f",
            "lavfi",
            "-i",
            src,
            *af,
            *(codec or ["-c:a", "pcm_s16le"]),
            str(path),
        ],
        check=True,
    )
    return path


def dur(path: Path) -> float:
    d = process.duration_of(path)
    assert d is not None
    return d


@pytest.fixture
def wav(tmp_path: Path) -> Path:
    return gen(tmp_path / "PH_test.wav")


def _only_ok(results):
    assert all(r.ok for r in results), [r.error for r in results]
    return results[0].output_path


# ---------------------------------------------------------------- helpers


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("1:30", 90.0),
        ("00:01:30.250", 90.25),
        ("75", 75.0),
        ("2,5", 2.5),
        ("", None),
        (None, None),
        (3, 3.0),
    ],
)
def test_parse_time(text, expected) -> None:
    assert process.parse_time(text) == expected


def test_parse_time_invalid() -> None:
    with pytest.raises(ValueError):
        process.parse_time("abc")


def test_format_time() -> None:
    assert process.format_time(90.25) == "01:30.250"


def test_atempo_chain() -> None:
    assert process._atempo_chain(1.5) == "atempo=1.500000"
    assert process._atempo_chain(0.3).startswith("atempo=0.5,")
    assert process._atempo_chain(3.0) == "atempo=2.0,atempo=1.500000"


def test_output_policy(tmp_path: Path) -> None:
    src = tmp_path / "a.wav"
    src.write_bytes(b"x")
    assert OutputPolicy().target(src, "_cut") == tmp_path / "a_cut.wav"
    (tmp_path / "a_cut.wav").write_bytes(b"y")
    assert OutputPolicy().target(src, "_cut") == tmp_path / "a_cut_2.wav"
    assert OutputPolicy("replace_with_backup").target(src, "_cut") == src
    assert OutputPolicy("replace_with_backup").target(src, "", ".mp3") == tmp_path / "a.mp3"


# ---------------------------------------------------------------- operations (synthetic wav)


def test_tempo(wav: Path) -> None:
    seen: list[float] = []
    out = _only_ok(
        process.tempo([wav], factor=2.0, progress=lambda i, n, p, percent: seen.append(percent))
    )
    assert out.name == "PH_test_tempo2.wav"
    assert abs(dur(out) - 2.0) < 0.15
    assert seen and seen[-1] == 100.0


def test_pitch_keeps_duration(wav: Path) -> None:
    out = _only_ok(process.pitch([wav], semitones=3))
    assert out.name == "PH_test_pitch3.wav"
    assert abs(dur(out) - 4.0) < 0.25


def test_pitch_fallback_without_rubberband(wav: Path, monkeypatch) -> None:
    monkeypatch.setattr(process, "available_filters", lambda: set())
    out = _only_ok(process.pitch([wav], semitones=-2))
    assert abs(dur(out) - 4.0) < 0.25


def test_speed(wav: Path) -> None:
    out = _only_ok(process.speed([wav], factor=1.25))
    assert out.name == "PH_test_x1.25.wav"
    assert abs(dur(out) - 3.2) < 0.15


def test_slowed_reverb(wav: Path) -> None:
    out = _only_ok(process.slowed_reverb([wav], factor=0.8, reverb=0.5))
    assert dur(out) > 4.9  # slowed to 5 s (+ echo tail)


def test_cut_copy_and_reencode(wav: Path) -> None:
    out = _only_ok(process.cut([wav], start="0:01", end="0:03"))
    assert out.name == "PH_test_cut.wav"
    assert abs(dur(out) - 2.0) < 0.1
    out2 = _only_ok(process.cut([wav], start=1, end=None, reencode=True))
    assert abs(dur(out2) - 3.0) < 0.1


def test_cut_invalid_range(wav: Path) -> None:
    with pytest.raises(ValueError):
        process.cut([wav], start="0:03", end="0:01")


def test_fade(wav: Path) -> None:
    out = _only_ok(process.fade([wav], fade_in=0.5, fade_out=1.0))
    assert abs(dur(out) - 4.0) < 0.1
    with pytest.raises(ValueError):
        process.fade([wav])


def test_normalize_two_pass(wav: Path) -> None:
    out = _only_ok(process.normalize([wav], lufs=-14))
    assert out.name == "PH_test_normm14.wav"
    assert abs(dur(out) - 4.0) < 0.15
    # Loudness of a full-scale sine is ~-3 LUFS; after normalising it must be near -14.
    cp = subprocess.run(
        [
            ffmpeg,
            "-hide_banner",
            "-i",
            str(out),
            "-af",
            "loudnorm=print_format=json",
            "-f",
            "null",
            "-",
        ],
        capture_output=True,
        text=True,
    )
    import json

    text = cp.stderr
    measured = json.loads(text[text.rfind("{") : text.rfind("}") + 1])
    assert abs(float(measured["input_i"]) - (-14)) < 1.5


@pytest.mark.parametrize("fmt", process.CONVERT_FORMATS)
def test_convert(wav: Path, fmt: str) -> None:
    results = process.convert([wav], fmt=fmt)
    out = _only_ok(results)
    ext = fmt.split("_")[0]
    assert out.suffix == f".{ext}"
    if fmt == "wav":
        assert out.name == "PH_test_2.wav"  # never overwrite the source
    assert abs(dur(out) - 4.0) < 0.2


def test_concat(tmp_path: Path) -> None:
    a = gen(tmp_path / "A_1.wav", 2.0)
    b = gen(tmp_path / "A_2.wav", 3.0)
    results = process.concat([a, b])
    assert all(r.ok for r in results) and len(results) == 2
    out = results[0].output_path
    assert out.name == "A_1_joined.wav"
    assert abs(dur(out) - 5.0) < 0.1
    with pytest.raises(ValueError):
        process.concat([a])


def test_silence_remove(tmp_path: Path) -> None:
    padded = gen(tmp_path / "S_pad.wav", seconds=2.0, silence_pad=1.5)
    assert dur(padded) > 4.5
    out = _only_ok(process.silence_remove([padded], threshold_db=-50, min_duration=0.3))
    assert abs(dur(out) - 2.0) < 0.3


# ---------------------------------------------------------------- policy, batch, cancel, errors


def test_replace_with_backup(wav: Path, tmp_path: Path) -> None:
    backup_dir = tmp_path / "bak"
    policy = OutputPolicy("replace_with_backup", backup_dir)
    out = _only_ok(process.tempo([wav], factor=2.0, policy=policy))
    assert out == wav
    assert abs(dur(wav) - 2.0) < 0.15
    backups = list(backup_dir.iterdir())
    assert len(backups) == 1 and abs(dur(backups[0]) - 4.0) < 0.1
    _only_ok(process.tempo([wav], factor=2.0, policy=policy))
    assert len(list(backup_dir.iterdir())) == 2


def test_batch_mixed_results(tmp_path: Path) -> None:
    good = gen(tmp_path / "G_1.wav")
    bad = tmp_path / "B_1.wav"
    bad.write_bytes(b"garbage")
    seen: list[tuple[int, int]] = []
    results = process.speed(
        [good, bad], factor=1.1, progress=lambda i, n, p, **k: seen.append((i, n))
    )
    assert results[0].ok and not results[1].ok
    assert "ffmpeg" in results[1].error
    assert seen[-1] == (2, 2)
    assert not list(tmp_path.glob("*.mtbtmp*"))


def test_cancel_marks_remaining(tmp_path: Path) -> None:
    files = [gen(tmp_path / f"C_{i}.wav", 1.0) for i in range(3)]
    results = process.tempo(files, factor=1.5, is_cancelled=lambda: True)
    assert all(not r.ok and r.error == "Скасовано" for r in results)
    assert not list(tmp_path.glob("*tempo*"))


def test_codec_args() -> None:
    assert process.codec_args("mp3", 192)[-1] == "192k"
    assert process.codec_args(".flac") == ["-c:a", "flac"]
    assert process.codec_args("xyz") == []
