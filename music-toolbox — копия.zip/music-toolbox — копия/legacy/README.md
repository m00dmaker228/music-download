# legacy

Сюди кладуться старі скрипти — `soundcloud.py`, `soundcloud_single_track.py`,
`strip_metadata.py` — як джерело логіки для етапів 2 і 5 (список PLAYLISTS,
аргументи yt-dlp, порядок очищення тегів). Вони не імпортуються додатком і не
перевіряються ruff/pytest.
