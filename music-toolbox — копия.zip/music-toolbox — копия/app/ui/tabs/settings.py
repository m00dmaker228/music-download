"""Tab «Налаштування»: folders, defaults, binaries install/update, operation log."""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core import binaries, paths
from app.core.settings import DEFAULT_FORMATS, RESULT_STRATEGIES
from app.ui import logbus, workers
from app.ui.file_browser import human_size, open_in_file_manager
from app.ui.state import AppState

log = logging.getLogger(__name__)

STRATEGY_LABELS = {
    "new_file": "Новий файл із суфіксом",
    "replace_with_backup": "Замінити, бекап у папку бекапів",
}
FORMAT_LABELS = {
    "original": "Оригінал (без перекодування)",
    "mp3_320": "MP3 320 kbps",
    "m4a": "M4A (AAC)",
    "opus": "Opus",
}
MAX_LOG_LINES = 5000


def _path_label(text: str) -> QLineEdit:
    """Read-only field for a long path: never widens the tab, is selectable/copyable."""
    field = QLineEdit(text)
    field.setReadOnly(True)
    field.setFrame(False)
    field.setStyleSheet("QLineEdit { background: transparent; }")
    field.setCursorPosition(0)
    field.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
    return field


class SettingsTab(QWidget):
    def __init__(self, state: AppState, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.state = state
        self._install_worker: workers.Worker | None = None

        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.addWidget(self._build_folders())
        layout.addWidget(self._build_defaults())
        layout.addWidget(self._build_binaries())
        layout.addWidget(self._build_log(), 1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        self._load_from_settings()
        state.binaries_changed.connect(self._on_binaries)
        logbus.bus().record.connect(self._append_log)

    # ------------------------------------------------------------------ folders
    def _build_folders(self) -> QGroupBox:
        box = QGroupBox("Папки")
        form = QFormLayout(box)
        self.work_dir = QLineEdit()
        self.backup_dir = QLineEdit()
        form.addRow("Робоча папка", self._with_browse(self.work_dir))
        form.addRow("Папка бекапів", self._with_browse(self.backup_dir))
        self.recursive = QCheckBox("Сканувати робочу папку рекурсивно")
        form.addRow("", self.recursive)
        return box

    def _with_browse(self, edit: QLineEdit) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        btn = QPushButton("Огляд…")
        btn.clicked.connect(lambda: self._browse(edit))
        h.addWidget(edit, 1)
        h.addWidget(btn)
        return w

    def _browse(self, edit: QLineEdit) -> None:
        start = edit.text() or str(Path.home())
        chosen = QFileDialog.getExistingDirectory(self, "Вибрати папку", start)
        if chosen:
            edit.setText(chosen)

    # ------------------------------------------------------------------ defaults
    def _build_defaults(self) -> QGroupBox:
        box = QGroupBox("Параметри за замовчуванням")
        form = QFormLayout(box)
        self.strategy = QComboBox()
        for key in RESULT_STRATEGIES:
            self.strategy.addItem(STRATEGY_LABELS[key], key)
        self.parallel = QSpinBox()
        self.parallel.setRange(1, 4)
        self.filename_template = QLineEdit()
        self.filename_template.setPlaceholderText("{prefix}{title}.{ext}")
        self.tag_template = QLineEdit()
        self.tag_template.setPlaceholderText("{prefix}{artist} - {title}")
        self.default_format = QComboBox()
        for key in DEFAULT_FORMATS:
            self.default_format.addItem(FORMAT_LABELS[key], key)
        form.addRow("Результат обробки", self.strategy)
        form.addRow("Паралельних завантажень", self.parallel)
        form.addRow("Шаблон імені файлу", self.filename_template)
        form.addRow("Шаблон тегів із назви", self.tag_template)
        form.addRow("Формат за замовчуванням", self.default_format)

        btn_save = QPushButton("Зберегти налаштування")
        btn_save.clicked.connect(self._save)
        btn_reset = QPushButton("Скинути зміни")
        btn_reset.clicked.connect(self._load_from_settings)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(btn_reset)
        row.addWidget(btn_save)
        form.addRow(row)
        return box

    def _load_from_settings(self) -> None:
        s = self.state.settings
        self.work_dir.setText(s.work_dir)
        self.backup_dir.setText(s.backup_dir)
        self.recursive.setChecked(s.recursive_scan)
        self.strategy.setCurrentIndex(max(0, self.strategy.findData(s.result_strategy)))
        self.parallel.setValue(s.parallel_downloads)
        self.filename_template.setText(s.filename_template)
        self.tag_template.setText(s.tag_template)
        self.default_format.setCurrentIndex(max(0, self.default_format.findData(s.default_format)))

    def _save(self) -> None:
        s = self.state.settings
        work = self.work_dir.text().strip()
        if not work:
            QMessageBox.warning(self, "Налаштування", "Робоча папка не може бути порожньою.")
            return
        s.work_dir = work
        s.backup_dir = self.backup_dir.text().strip() or str(Path(work) / "_backup")
        s.recursive_scan = self.recursive.isChecked()
        s.result_strategy = self.strategy.currentData()
        s.parallel_downloads = self.parallel.value()
        s.filename_template = self.filename_template.text().strip() or "{prefix}{title}.{ext}"
        s.tag_template = self.tag_template.text().strip() or "{prefix}{artist} - {title}"
        s.default_format = self.default_format.currentData()
        try:
            Path(work).mkdir(parents=True, exist_ok=True)
            self.state.save_settings()
        except OSError as exc:
            log.error("Cannot save settings: %s", exc)
            QMessageBox.critical(self, "Налаштування", f"Не вдалося зберегти:\n{exc}")
            return
        self._load_from_settings()

    # ------------------------------------------------------------------ binaries
    def _build_binaries(self) -> QGroupBox:
        box = QGroupBox("Зовнішні програми")
        v = QVBoxLayout(box)
        v.addWidget(_path_label(f"Папка встановлення: {paths.bin_dir()}"))

        self.bin_table = QTableWidget(len(binaries.NAMES), 3)
        self.bin_table.setHorizontalHeaderLabels(("Програма", "Шлях", "Версія"))
        self.bin_table.verticalHeader().setVisible(False)
        self.bin_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.bin_table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        hdr = self.bin_table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        for row, name in enumerate(binaries.NAMES):
            self.bin_table.setItem(row, 0, QTableWidgetItem(name))
            self.bin_table.setItem(row, 1, QTableWidgetItem("…"))
            self.bin_table.setItem(row, 2, QTableWidgetItem(""))
        self.bin_table.setSizeAdjustPolicy(QAbstractItemView.SizeAdjustPolicy.AdjustToContents)
        row_h = self.bin_table.verticalHeader().defaultSectionSize()
        head_h = self.bin_table.horizontalHeader().sizeHint().height()
        self.bin_table.setFixedHeight(head_h + row_h * len(binaries.NAMES) + 4)
        self.bin_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        v.addWidget(self.bin_table)

        self.btn_check = QPushButton("Перевірити")
        self.btn_check.clicked.connect(self.state.refresh_binaries)
        self.btn_ytdlp = QPushButton("Встановити / оновити yt-dlp")
        self.btn_ytdlp.clicked.connect(lambda: self._install("yt-dlp"))
        self.btn_ffmpeg = QPushButton("Встановити / оновити ffmpeg + ffprobe")
        self.btn_ffmpeg.clicked.connect(lambda: self._install("ffmpeg"))
        self.btn_cancel = QPushButton("Скасувати")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel_install)
        grid = QGridLayout()
        grid.addWidget(self.btn_ytdlp, 0, 0)
        grid.addWidget(self.btn_ffmpeg, 0, 1)
        grid.addWidget(self.btn_check, 1, 0)
        grid.addWidget(self.btn_cancel, 1, 1)
        v.addLayout(grid)

        self.install_progress = QProgressBar()
        self.install_progress.setRange(0, 100)
        self.install_progress.setTextVisible(True)
        self.install_progress.hide()
        self.install_label = QLabel()
        self.install_label.hide()
        v.addWidget(self.install_label)
        v.addWidget(self.install_progress)
        return box

    def _on_binaries(self, statuses: dict) -> None:
        for row, name in enumerate(binaries.NAMES):
            st = statuses[name]
            path_item = self.bin_table.item(row, 1)
            ver_item = self.bin_table.item(row, 2)
            path_item.setText(str(st.path) if st.path else "не знайдено")
            ver_item.setText(st.version or ("?" if st.path else ""))
            color = Qt.GlobalColor.darkGreen if st.available else Qt.GlobalColor.red
            path_item.setForeground(color)

    def _set_install_ui(self, busy: bool, label: str = "") -> None:
        for b in (self.btn_check, self.btn_ytdlp, self.btn_ffmpeg):
            b.setEnabled(not busy)
        self.btn_cancel.setEnabled(busy)
        self.install_progress.setVisible(busy)
        self.install_label.setVisible(busy)
        self.install_label.setText(label)
        if busy:
            self.install_progress.setRange(0, 0)

    def _install(self, name: str) -> None:
        if self._install_worker is not None:
            return

        def task(ctx):
            def progress(stage: str, done: int, total: int) -> None:
                ctx.progress(stage=stage, done=done, total=total)

            return binaries.install(name, progress, ctx.is_cancelled)

        w = workers.Worker(task)
        w.signals.progress.connect(self._on_install_progress)
        w.signals.finished.connect(self._on_install_done)
        w.signals.error.connect(self._on_install_error)
        w.signals.done.connect(self._on_install_finished)
        self._install_worker = w
        self._set_install_ui(True, f"Завантаження {name}…")
        log.info("Installing %s", name)
        workers.start(w)

    def _cancel_install(self) -> None:
        if self._install_worker is not None:
            self._install_worker.cancel()
            self.install_label.setText("Скасування…")

    def _on_install_progress(self, payload: dict) -> None:
        stage = payload.get("stage", "")
        done = int(payload.get("done", 0))
        total = int(payload.get("total", 0))
        if stage == "extract":
            self.install_progress.setRange(0, 0)
            self.install_label.setText("Розпакування…")
            return
        if total > 0:
            self.install_progress.setRange(0, 100)
            self.install_progress.setValue(int(done * 100 / total))
            self.install_label.setText(f"{stage}: {human_size(done)} / {human_size(total)}")
        else:
            self.install_progress.setRange(0, 0)
            self.install_label.setText(f"{stage}: {human_size(done)}")

    def _on_install_done(self, result) -> None:
        log.info("Installed: %s", result)
        QMessageBox.information(
            self, "Встановлення", "Встановлено:\n" + "\n".join(str(p) for p in result)
        )

    def _on_install_error(self, msg: str, tb: str) -> None:
        if isinstance(msg, str) and "CancelledError" in tb:
            QMessageBox.information(self, "Встановлення", "Встановлення скасовано.")
            return
        QMessageBox.critical(
            self,
            "Встановлення",
            f"Помилка встановлення:\n{msg}\n\nПовний текст помилки є в логу нижче.",
        )

    def _on_install_finished(self) -> None:
        self._install_worker = None
        self._set_install_ui(False)
        self.state.refresh_binaries()

    # ------------------------------------------------------------------ log
    def _build_log(self) -> QGroupBox:
        box = QGroupBox("Лог операцій")
        v = QVBoxLayout(box)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(MAX_LOG_LINES)
        self.log_view.setMinimumHeight(180)
        v.addWidget(self.log_view, 1)
        btn_copy = QPushButton("Копіювати")
        btn_copy.clicked.connect(
            lambda: QGuiApplication.clipboard().setText(self.log_view.toPlainText())
        )
        btn_clear = QPushButton("Очистити")
        btn_clear.clicked.connect(self.log_view.clear)
        btn_open = QPushButton("Відкрити файл логу")
        btn_open.clicked.connect(lambda: open_in_file_manager(paths.log_file()))
        row = QHBoxLayout()
        for b in (btn_copy, btn_clear, btn_open):
            row.addWidget(b)
        row.addWidget(_path_label(str(paths.log_file())), 1)
        v.addLayout(row)
        return box

    def _append_log(self, line: str) -> None:
        self.log_view.appendPlainText(line)
