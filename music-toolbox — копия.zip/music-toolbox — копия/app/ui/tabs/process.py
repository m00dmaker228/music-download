"""Tab «Обробка»: ten ffmpeg operations, each with its own parameters, presets, batch run."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from PySide6.QtCore import Qt, QUrl
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from app.core import presets, process
from app.core.models import Preset
from app.core.process import OutputPolicy
from app.ui.batch import BatchPanel
from app.ui.state import AppState
from app.ui.tabs.base import BaseTab

log = logging.getLogger(__name__)


@dataclass(slots=True)
class Param:
    key: str
    label: str
    kind: str  # float | time | bool | choice | str
    default: object = None
    minimum: float = 0.0
    maximum: float = 1.0
    step: float = 1.0
    choices: tuple[tuple[str, str], ...] = ()  # (label, value)


@dataclass(slots=True)
class OpSpec:
    key: str
    title: str
    hint: str
    params: list[Param]


CONVERT_LABELS = (
    ("MP3 128 kbps", "mp3_128"),
    ("MP3 192 kbps", "mp3_192"),
    ("MP3 320 kbps", "mp3_320"),
    ("M4A (AAC)", "m4a"),
    ("Opus", "opus"),
    ("FLAC", "flac"),
    ("WAV", "wav"),
)

OPS: list[OpSpec] = [
    OpSpec(
        "tempo",
        "Темп без зміни тону",
        "atempo (ланцюжок для <0.5 / >2.0)",
        [Param("factor", "Множник", "float", 1.0, 0.25, 4.0, 0.05)],
    ),
    OpSpec(
        "pitch",
        "Тон без зміни темпу",
        "rubberband або asetrate+atempo",
        [Param("semitones", "Півтони", "float", 0.0, -12.0, 12.0, 1.0)],
    ),
    OpSpec(
        "speed",
        "Швидкість + тон",
        "asetrate+aresample; Nightcore 1.25, Slowed 0.85",
        [Param("factor", "Множник", "float", 1.25, 0.25, 4.0, 0.05)],
    ),
    OpSpec(
        "slowed_reverb",
        "Slowed + reverb",
        "asetrate + aecho",
        [
            Param("factor", "Множник", "float", 0.85, 0.25, 2.0, 0.05),
            Param("reverb", "Сила реверба (0–1)", "float", 0.5, 0.0, 1.0, 0.1),
        ],
    ),
    OpSpec(
        "cut",
        "Обрізати",
        "-ss / -to, -c copy або перекодування",
        [
            Param("start", "Від (мм:сс.мс)", "time", ""),
            Param("end", "До (мм:сс.мс, порожньо = до кінця)", "time", ""),
            Param("reencode", "Перекодувати (точний зріз)", "bool", False),
        ],
    ),
    OpSpec(
        "fade",
        "Fade in / out",
        "afade",
        [
            Param("fade_in", "Fade in, с", "float", 0.0, 0.0, 120.0, 0.5),
            Param("fade_out", "Fade out, с", "float", 3.0, 0.0, 120.0, 0.5),
        ],
    ),
    OpSpec(
        "normalize",
        "Нормалізація",
        "loudnorm, двопрохідна",
        [Param("lufs", "Цільова гучність, LUFS", "float", -14.0, -40.0, -5.0, 1.0)],
    ),
    OpSpec(
        "convert",
        "Конвертація",
        "mp3 128/192/320, m4a, opus, flac, wav",
        [Param("fmt", "Формат", "choice", "mp3_320", choices=CONVERT_LABELS)],
    ),
    OpSpec(
        "concat",
        "Об'єднання",
        "concat; порядок = порядок у панелі «Файли»",
        [Param("output_name", "Назва результату (без розширення)", "str", "")],
    ),
    OpSpec(
        "silence_remove",
        "Вирізати тишу",
        "silenceremove",
        [
            Param("threshold_db", "Поріг, дБ", "float", -50.0, -90.0, 0.0, 1.0),
            Param("min_duration", "Мін. тривалість тиші, с", "float", 0.5, 0.05, 10.0, 0.05),
        ],
    ),
]
OPS_BY_KEY = {o.key: o for o in OPS}


class ParamForm(QWidget):
    """Form built from an OpSpec; values() returns the kwargs for the core function."""

    def __init__(self, spec: OpSpec) -> None:
        super().__init__()
        self.spec = spec
        self.widgets: dict[str, QWidget] = {}
        form = QFormLayout(self)
        form.addRow(QLabel(f"<i>{spec.hint}</i>"))
        for p in spec.params:
            w: QWidget
            if p.kind == "float":
                sb = QDoubleSpinBox()
                sb.setRange(p.minimum, p.maximum)
                sb.setSingleStep(p.step)
                sb.setDecimals(2)
                sb.setValue(float(p.default))
                w = sb
            elif p.kind == "bool":
                cb = QCheckBox()
                cb.setChecked(bool(p.default))
                w = cb
            elif p.kind == "choice":
                combo = QComboBox()
                for label, value in p.choices:
                    combo.addItem(label, value)
                combo.setCurrentIndex(max(0, combo.findData(p.default)))
                w = combo
            else:
                le = QLineEdit(str(p.default or ""))
                if p.kind == "time":
                    le.setPlaceholderText("мм:сс.мс")
                w = le
            self.widgets[p.key] = w
            form.addRow(p.label, w)
        if spec.key == "speed":
            row = QHBoxLayout()
            for label, val in (("Nightcore 1.25", 1.25), ("Slowed 0.85", 0.85), ("1.0", 1.0)):
                b = QPushButton(label)
                b.clicked.connect(lambda _c=False, v=val: self.widgets["factor"].setValue(v))
                row.addWidget(b)
            row.addStretch()
            form.addRow("Пресети", row)

    def values(self) -> dict:
        out: dict = {}
        for p in self.spec.params:
            w = self.widgets[p.key]
            if p.kind == "float":
                out[p.key] = float(w.value())
            elif p.kind == "bool":
                out[p.key] = bool(w.isChecked())
            elif p.kind == "choice":
                out[p.key] = w.currentData()
            else:
                text = w.text().strip()
                out[p.key] = text if text else None
        return out

    def set_values(self, params: dict) -> None:
        for p in self.spec.params:
            if p.key not in params:
                continue
            w = self.widgets[p.key]
            v = params[p.key]
            if p.kind == "float":
                w.setValue(float(v))
            elif p.kind == "bool":
                w.setChecked(bool(v))
            elif p.kind == "choice":
                w.setCurrentIndex(max(0, w.findData(v)))
            else:
                w.setText("" if v is None else str(v))


class ProcessTab(BaseTab):
    required_binaries = ("ffmpeg", "ffprobe")

    def __init__(self, state: AppState) -> None:
        super().__init__(state)
        self.presets: list[Preset] = presets.load()
        self._player = None

        layout = QVBoxLayout(self.content)
        layout.setContentsMargins(0, 0, 0, 0)
        self.sel_label = QLabel("Вибрано файлів: 0")
        layout.addWidget(self.sel_label)

        # ---- operations list + parameter forms
        self.op_list = QListWidget()
        self.forms = QStackedWidget()
        for spec in OPS:
            self.op_list.addItem(spec.title)
            self.forms.addWidget(ParamForm(spec))
        self.op_list.currentRowChanged.connect(self.forms.setCurrentIndex)
        self.op_list.setCurrentRow(0)
        self.op_list.setMaximumWidth(220)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.addWidget(self.forms)

        self.btn_preview = QPushButton("▶ Прослухати фрагмент")
        self.btn_preview.setToolTip("Відтворює вибраний файл від «Від» до «До»")
        self.btn_preview.clicked.connect(self._preview)
        self.btn_stop = QPushButton("■ Стоп")
        self.btn_stop.clicked.connect(self._stop_preview)
        self.btn_run = QPushButton("Застосувати до вибраних файлів")
        self.btn_run.setDefault(True)
        self.btn_run.clicked.connect(self._run)
        run_row = QHBoxLayout()
        run_row.addWidget(self.btn_preview)
        run_row.addWidget(self.btn_stop)
        run_row.addStretch()
        run_row.addWidget(self.btn_run)
        rv.addLayout(run_row)

        presets_box = QGroupBox("Пресети")
        pr = QHBoxLayout(presets_box)
        self.preset_combo = QComboBox()
        self.btn_preset_apply = QPushButton("Застосувати")
        self.btn_preset_apply.clicked.connect(self._apply_preset)
        self.btn_preset_save = QPushButton("Зберегти поточне як…")
        self.btn_preset_save.clicked.connect(self._save_preset)
        self.btn_preset_delete = QPushButton("Видалити")
        self.btn_preset_delete.clicked.connect(self._delete_preset)
        pr.addWidget(self.preset_combo, 1)
        pr.addWidget(self.btn_preset_apply)
        pr.addWidget(self.btn_preset_save)
        pr.addWidget(self.btn_preset_delete)
        rv.addWidget(presets_box)
        self._fill_presets()

        top = QHBoxLayout()
        top.addWidget(self.op_list)
        top.addWidget(right, 1)
        top_w = QWidget()
        top_w.setLayout(top)

        self.batch = BatchPanel(state)
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(top_w)
        split.addWidget(self.batch)
        split.setSizes([360, 240])
        layout.addWidget(split, 1)

        state.selection_changed.connect(
            lambda sel: self.sel_label.setText(f"Вибрано файлів: {len(sel)}")
        )

    # ------------------------------------------------------------------ run
    def current_spec(self) -> OpSpec:
        return OPS[self.op_list.currentRow()]

    def current_form(self) -> ParamForm:
        return self.forms.currentWidget()  # type: ignore[return-value]

    def _policy(self) -> OutputPolicy:
        s = self.state.settings
        return OutputPolicy(s.result_strategy, s.backup_path)

    def _run(self) -> None:
        spec = self.current_spec()
        params = self.current_form().values()
        paths = list(self.state.selection)
        if spec.key == "concat" and len(paths) < 2:
            QMessageBox.information(self, spec.title, "Виберіть щонайменше два файли.")
            return
        try:
            # Validate parameters eagerly with an empty batch so errors show before work starts.
            process.FUNCTIONS[spec.key]([], **params)
        except ValueError as exc:
            QMessageBox.warning(self, spec.title, str(exc))
            return
        params["policy"] = self._policy()
        self.batch.run(spec.title, process.FUNCTIONS[spec.key], paths, params)

    # ------------------------------------------------------------------ preview (cut)
    def _preview(self) -> None:
        sel = self.state.selection
        if len(sel) != 1:
            QMessageBox.information(self, "Прослухати", "Виберіть рівно один файл.")
            return
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except ImportError:
            QMessageBox.warning(self, "Прослухати", "Модуль QtMultimedia недоступний.")
            return
        form = self.current_form()
        start = end = None
        if form.spec.key == "cut":
            vals = form.values()
            try:
                start = process.parse_time(vals.get("start")) or 0.0
                end = process.parse_time(vals.get("end"))
            except ValueError as exc:
                QMessageBox.warning(self, "Прослухати", str(exc))
                return
        self._stop_preview()
        player = QMediaPlayer(self)
        audio = QAudioOutput(self)
        player.setAudioOutput(audio)
        player.setSource(QUrl.fromLocalFile(str(sel[0])))
        self._player = (player, audio)
        end_ms = int(end * 1000) if end else None

        def on_pos(ms: int) -> None:
            if end_ms is not None and ms >= end_ms:
                self._stop_preview()

        player.positionChanged.connect(on_pos)
        player.errorOccurred.connect(
            lambda _e, msg: QMessageBox.warning(self, "Прослухати", msg or "помилка відтворення")
        )
        player.setPosition(int((start or 0.0) * 1000))
        player.play()
        log.info("Preview %s from %s to %s", sel[0].name, start, end)

    def _stop_preview(self) -> None:
        if self._player:
            player, _audio = self._player
            player.stop()
            player.deleteLater()
            self._player = None

    # ------------------------------------------------------------------ presets
    def _fill_presets(self) -> None:
        self.preset_combo.clear()
        for p in self.presets:
            title = OPS_BY_KEY[p.operation].title if p.operation in OPS_BY_KEY else p.operation
            self.preset_combo.addItem(f"{p.name}  —  {title}", p.name)

    def _selected_preset(self) -> Preset | None:
        name = self.preset_combo.currentData()
        return next((p for p in self.presets if p.name == name), None)

    def _apply_preset(self) -> None:
        p = self._selected_preset()
        if p is None:
            return
        if p.operation not in OPS_BY_KEY:
            QMessageBox.warning(self, "Пресет", f"Невідома операція: {p.operation}")
            return
        row = list(OPS_BY_KEY).index(p.operation)
        self.op_list.setCurrentRow(row)
        self.current_form().set_values(p.params)

    def _save_preset(self) -> None:
        spec = self.current_spec()
        params = self.current_form().values()
        name, ok = QInputDialog.getText(self, "Зберегти пресет", "Назва пресету:")
        name = name.strip()
        if not ok or not name:
            return
        presets.upsert(self.presets, Preset(name, spec.key, params))
        presets.save(self.presets)
        self._fill_presets()
        self.preset_combo.setCurrentIndex(max(0, self.preset_combo.findData(name)))
        log.info("Preset saved: %s (%s %s)", name, spec.key, params)

    def _delete_preset(self) -> None:
        p = self._selected_preset()
        if p is None:
            return
        if (
            QMessageBox.question(self, "Пресет", f"Видалити пресет «{p.name}»?")
            != QMessageBox.StandardButton.Yes
        ):
            return
        presets.remove(self.presets, p.name)
        presets.save(self.presets)
        self._fill_presets()
