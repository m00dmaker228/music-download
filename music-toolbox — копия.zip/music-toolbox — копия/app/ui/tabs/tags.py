"""Tab «Теги»: six independent actions on the files selected in the left panel."""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from app.core import tags
from app.ui import workers
from app.ui.batch import BatchPanel
from app.ui.state import AppState
from app.ui.tabs.base import BaseTab

log = logging.getLogger(__name__)


class TagsTab(BaseTab):
    required_binaries = ("ffmpeg", "ffprobe")

    def __init__(self, state: AppState) -> None:
        super().__init__(state)
        layout = QVBoxLayout(self.content)
        layout.setContentsMargins(0, 0, 0, 0)

        self.sel_label = QLabel("Вибрано файлів: 0")
        layout.addWidget(self.sel_label)

        actions = QGroupBox("Дії над вибраними файлами (кожна окремо)")
        grid = QGridLayout(actions)

        self.btn_strip = QPushButton("1. Очистити всі метадані")
        self.btn_strip.setToolTip("ffmpeg -map_metadata -1 -c copy; при невдачі — mutagen")
        self.btn_strip.clicked.connect(self._strip)
        self.btn_album = QPushButton("2. Записати album = префікс")
        self.btn_album.setToolTip("album = частина назви до першого «_» включно")
        self.btn_album.clicked.connect(self._album)
        self.btn_title = QPushButton("3. Записати title/artist із назви")
        self.btn_title.clicked.connect(self._title_artist)
        self.template = QLineEdit(state.settings.tag_template)
        self.template.setPlaceholderText("{prefix}{artist} - {title}")
        self.btn_remove_cover = QPushButton("4. Видалити обкладинку")
        self.btn_remove_cover.clicked.connect(self._remove_cover)
        self.btn_add_cover = QPushButton("5. Додати обкладинку з файлу…")
        self.btn_add_cover.clicked.connect(self._add_cover)
        self.btn_view = QPushButton("6. Переглянути теги")
        self.btn_view.clicked.connect(self._view)

        grid.addWidget(self.btn_strip, 0, 0)
        grid.addWidget(self.btn_album, 0, 1)
        grid.addWidget(self.btn_title, 1, 0)
        tpl_row = QHBoxLayout()
        tpl_row.addWidget(QLabel("Шаблон:"))
        tpl_row.addWidget(self.template, 1)
        grid.addLayout(tpl_row, 1, 1)
        grid.addWidget(self.btn_remove_cover, 2, 0)
        grid.addWidget(self.btn_add_cover, 2, 1)
        grid.addWidget(self.btn_view, 3, 0)
        layout.addWidget(actions)

        self.batch = BatchPanel(state)
        self.view_table = QTableWidget(0, 2)
        self.view_table.setHorizontalHeaderLabels(("Тег", "Значення"))
        self.view_table.verticalHeader().setVisible(False)
        self.view_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        hdr = self.view_table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        view_box = QGroupBox("Теги вибраного файлу (лише читання)")
        vb = QVBoxLayout(view_box)
        vb.addWidget(self.view_table)

        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.batch)
        split.addWidget(view_box)
        split.setSizes([300, 200])
        layout.addWidget(split, 1)

        state.selection_changed.connect(self._on_selection)
        state.settings_changed.connect(lambda: self.template.setText(state.settings.tag_template))

    # ------------------------------------------------------------------
    def _paths(self) -> list[Path]:
        return list(self.state.selection)

    def _on_selection(self, sel: list[Path]) -> None:
        self.sel_label.setText(f"Вибрано файлів: {len(sel)}")
        if len(sel) == 1:
            self._view()
        else:
            self.view_table.setRowCount(0)

    def _strip(self) -> None:
        self.batch.run("Очищення метаданих", tags.strip_metadata, self._paths())

    def _album(self) -> None:
        self.batch.run("Запис album", tags.set_album_from_prefix, self._paths())

    def _title_artist(self) -> None:
        tpl = self.template.text().strip() or "{prefix}{artist} - {title}"
        if "{title}" not in tpl and "{artist}" not in tpl:
            QMessageBox.warning(self, "Шаблон", "Шаблон має містити {title} і/або {artist}.")
            return
        self.batch.run(
            "Запис title/artist", tags.set_title_artist_from_name, self._paths(), {"template": tpl}
        )

    def _remove_cover(self) -> None:
        self.batch.run("Видалення обкладинки", tags.remove_cover, self._paths())

    def _add_cover(self) -> None:
        if not self._paths():
            QMessageBox.information(self, "Обкладинка", "Виберіть файли ліворуч.")
            return
        img, _ = QFileDialog.getOpenFileName(
            self, "Зображення обкладинки", "", "Зображення (*.jpg *.jpeg *.png)"
        )
        if not img:
            return
        self.batch.run("Додавання обкладинки", tags.add_cover, self._paths(), {"image": Path(img)})

    def _view(self) -> None:
        sel = self._paths()
        if len(sel) != 1:
            QMessageBox.information(self, "Теги", "Виберіть рівно один файл.")
            return
        path = sel[0]

        def task(ctx):
            return tags.read_tags(path)

        w = workers.Worker(task)
        w.signals.finished.connect(self._fill_view)
        w.signals.error.connect(lambda m, tb: self._fill_view([("помилка", m)]))
        workers.start(w)

    def _fill_view(self, rows: list[tuple[str, str]]) -> None:
        self.view_table.setRowCount(0)
        for key, val in rows:
            r = self.view_table.rowCount()
            self.view_table.insertRow(r)
            self.view_table.setItem(r, 0, QTableWidgetItem(key))
            self.view_table.setItem(r, 1, QTableWidgetItem(val))
