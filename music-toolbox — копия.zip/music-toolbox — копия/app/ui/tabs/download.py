"""Tab «Завантажити»: URL form, playlist profiles, download queue with live progress."""

from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableView,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core import downloader, profiles
from app.core.models import Profile, QueueItem, QueueStatus, Track
from app.ui import workers
from app.ui.queue import ProgressDelegate, QueueController, QueueFilterProxy, QueueModel
from app.ui.state import AppState
from app.ui.tabs.base import BaseTab
from app.ui.tabs.settings import FORMAT_LABELS

log = logging.getLogger(__name__)


class ProfileDialog(QDialog):
    def __init__(self, parent: QWidget, profile: Profile | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Профіль плейлиста")
        self.name = QLineEdit(profile.name if profile else "")
        self.url = QLineEdit(profile.url if profile else "")
        self.url.setPlaceholderText("https://soundcloud.com/…/sets/…")
        self.prefix = QLineEdit(profile.prefix if profile else "")
        self.prefix.setPlaceholderText("PH_")
        self.active = QCheckBox("Активний")
        self.active.setChecked(profile.active if profile else True)
        self.last_index = QSpinBox()
        self.last_index.setRange(0, 100000)
        self.last_index.setValue(profile.last_index if profile else 0)
        self.last_index.setToolTip("Наступний запуск почнеться з треку № last+1")
        form = QFormLayout(self)
        form.addRow("Назва", self.name)
        form.addRow("URL", self.url)
        form.addRow("Префікс", self.prefix)
        form.addRow("", self.active)
        form.addRow("Останній завантажений №", self.last_index)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self._old = profile

    def _accept(self) -> None:
        if not self.name.text().strip() or not self.url.text().strip():
            QMessageBox.warning(self, "Профіль", "Назва і URL обов'язкові.")
            return
        self.accept()

    def result_profile(self) -> Profile:
        return Profile(
            name=self.name.text().strip(),
            url=self.url.text().strip(),
            prefix=self.prefix.text().strip(),
            active=self.active.isChecked(),
            last_index=self.last_index.value(),
            last_run=self._old.last_run if self._old else None,
        )


class DownloadTab(BaseTab):
    required_binaries = ("yt-dlp", "ffmpeg")

    def __init__(self, state: AppState) -> None:
        super().__init__(state)
        self.profiles: list[Profile] = profiles.load()
        self.model = QueueModel()
        self.controller = QueueController(state, self.model)
        self._listing: workers.Worker | None = None

        layout = QVBoxLayout(self.content)
        layout.setContentsMargins(0, 0, 0, 0)
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self._build_form_and_profiles())
        split.addWidget(self._build_queue())
        split.setSizes([300, 400])
        layout.addWidget(split, 1)

        self.controller.changed.connect(self._refresh_counters)
        state.enqueue_tracks.connect(self.enqueue_tracks)
        state.settings_changed.connect(
            lambda: self.fmt.setCurrentIndex(
                max(0, self.fmt.findData(state.settings.default_format))
            )
        )
        self._refresh_counters()

    # ------------------------------------------------------------------ form + profiles
    def _build_form_and_profiles(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)

        form_box = QGroupBox("Завантажити за посиланням (трек, плейлист, профіль, альбом)")
        f = QFormLayout(form_box)
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://soundcloud.com/… або https://youtube.com/…")
        self.url.returnPressed.connect(self._add_url)
        f.addRow("URL", self.url)
        row = QHBoxLayout()
        self.prefix = QLineEdit()
        self.prefix.setPlaceholderText("PH_")
        self.prefix.setMaximumWidth(120)
        self.range_from = QSpinBox()
        self.range_from.setRange(0, 100000)
        self.range_from.setSpecialValueText("початок")
        self.range_to = QSpinBox()
        self.range_to.setRange(0, 100000)
        self.range_to.setSpecialValueText("кінець")
        self.fmt = QComboBox()
        for key, label in FORMAT_LABELS.items():
            self.fmt.addItem(label, key)
        self.fmt.setCurrentIndex(max(0, self.fmt.findData(self.state.settings.default_format)))
        self.btn_add = QPushButton("Додати в чергу")
        self.btn_add.clicked.connect(self._add_url)
        row.addWidget(QLabel("Префікс"))
        row.addWidget(self.prefix)
        row.addWidget(QLabel("Треки від"))
        row.addWidget(self.range_from)
        row.addWidget(QLabel("до"))
        row.addWidget(self.range_to)
        row.addWidget(QLabel("Формат"))
        row.addWidget(self.fmt)
        row.addStretch()
        row.addWidget(self.btn_add)
        f.addRow(row)
        self.form_status = QLabel("")
        f.addRow(self.form_status)
        v.addWidget(form_box)

        prof_box = QGroupBox("Профілі плейлистів")
        pv = QVBoxLayout(prof_box)
        self.prof_table = QTableWidget(0, 6)
        self.prof_table.setHorizontalHeaderLabels(
            ("Назва", "URL", "Префікс", "Активний", "Останній №", "Останній запуск")
        )
        self.prof_table.verticalHeader().setVisible(False)
        self.prof_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.prof_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.prof_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        ph = self.prof_table.horizontalHeader()
        ph.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for i in (2, 3, 4, 5):
            ph.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        self.prof_table.doubleClicked.connect(lambda _i: self._edit_profile())
        pv.addWidget(self.prof_table, 1)
        pr = QHBoxLayout()
        b_add = QPushButton("Додати")
        b_add.clicked.connect(self._add_profile)
        b_edit = QPushButton("Редагувати")
        b_edit.clicked.connect(self._edit_profile)
        b_del = QPushButton("Видалити")
        b_del.clicked.connect(self._delete_profile)
        self.btn_run_profiles = QPushButton("Запустити вибрані профілі")
        self.btn_run_profiles.clicked.connect(self._run_profiles)
        for b in (b_add, b_edit, b_del):
            pr.addWidget(b)
        pr.addStretch()
        pr.addWidget(self.btn_run_profiles)
        pv.addLayout(pr)
        v.addWidget(prof_box, 1)
        self._fill_profiles()
        return w

    def _fill_profiles(self) -> None:
        self.prof_table.setRowCount(0)
        for p in self.profiles:
            row = self.prof_table.rowCount()
            self.prof_table.insertRow(row)
            cells = (
                p.name,
                p.url,
                p.prefix,
                "так" if p.active else "ні",
                str(p.last_index),
                (p.last_run or "")[:16].replace("T", " "),
            )
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, p.name)
                self.prof_table.setItem(row, col, item)

    def _selected_profiles(self) -> list[Profile]:
        names = {
            self.prof_table.item(i.row(), 0).data(Qt.ItemDataRole.UserRole)
            for i in self.prof_table.selectedIndexes()
        }
        return [p for p in self.profiles if p.name in names]

    def _add_profile(self) -> None:
        dlg = ProfileDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            profiles.add(self.profiles, dlg.result_profile())
        except ValueError as exc:
            QMessageBox.warning(self, "Профіль", str(exc))
            return
        profiles.save(self.profiles)
        self._fill_profiles()

    def _edit_profile(self) -> None:
        sel = self._selected_profiles()
        if len(sel) != 1:
            QMessageBox.information(self, "Профіль", "Виберіть один профіль.")
            return
        dlg = ProfileDialog(self, sel[0])
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            profiles.update(self.profiles, sel[0].name, dlg.result_profile())
        except ValueError as exc:
            QMessageBox.warning(self, "Профіль", str(exc))
            return
        profiles.save(self.profiles)
        self._fill_profiles()

    def _delete_profile(self) -> None:
        sel = self._selected_profiles()
        if not sel:
            return
        names = ", ".join(p.name for p in sel)
        if (
            QMessageBox.question(self, "Профіль", f"Видалити: {names}?")
            != QMessageBox.StandardButton.Yes
        ):
            return
        for p in sel:
            profiles.remove(self.profiles, p.name)
        profiles.save(self.profiles)
        self._fill_profiles()

    # ------------------------------------------------------------------ queue widget
    def _build_queue(self) -> QWidget:
        box = QGroupBox("Черга завантажень")
        v = QVBoxLayout(box)
        top = QHBoxLayout()
        self.overall = QLabel("Черга порожня")
        self.btn_pause = QPushButton("Пауза")
        self.btn_pause.clicked.connect(self._toggle_pause)
        self.btn_cancel = QPushButton("Скасувати все")
        self.btn_cancel.clicked.connect(self._cancel_all)
        top.addWidget(self.overall, 1)
        top.addWidget(self.btn_pause)
        top.addWidget(self.btn_cancel)
        v.addLayout(top)

        self.proxy = QueueFilterProxy()
        self.proxy.setSourceModel(self.model)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setItemDelegateForColumn(QueueModel.COL_PROGRESS, ProgressDelegate(self.table))
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(22)
        th = self.table.horizontalHeader()
        th.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        th.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        th.resizeSection(3, 140)
        for i in (0, 1, 4, 5, 6):
            th.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        self.table.doubleClicked.connect(self._show_error)
        v.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.counters = QLabel("")
        self.cb_hide = QCheckBox("Сховати завершені")
        self.cb_hide.toggled.connect(self._toggle_hide)
        self.btn_retry = QPushButton("Повторити помилкові")
        self.btn_retry.clicked.connect(self.controller.retry_failed)
        self.btn_clear = QPushButton("Очистити завершені")
        self.btn_clear.clicked.connect(self._clear_finished)
        bottom.addWidget(self.counters, 1)
        bottom.addWidget(self.cb_hide)
        bottom.addWidget(self.btn_retry)
        bottom.addWidget(self.btn_clear)
        v.addLayout(bottom)
        return box

    def _toggle_pause(self) -> None:
        if self.controller.paused:
            self.controller.resume()
        else:
            self.controller.pause()

    def _cancel_all(self) -> None:
        if self.controller.active == 0 and not any(
            it.status == QueueStatus.PENDING for it in self.model.items
        ):
            return
        if (
            QMessageBox.question(self, "Черга", "Скасувати всі завантаження?")
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.controller.cancel_all()

    def _toggle_hide(self, on: bool) -> None:
        self.proxy.hide_finished = on
        self.proxy.invalidate()

    def _clear_finished(self) -> None:
        self.model.clear_finished()
        self._refresh_counters()

    def _show_error(self, index) -> None:
        src = self.proxy.mapToSource(index).row()
        it = self.model.items[src]
        if it.error:
            QMessageBox.information(self, it.track.title, it.error)

    def _refresh_counters(self) -> None:
        c = self.model.counts()
        self.counters.setText(
            f"Завантажено: {c[QueueStatus.DONE]}  ·  пропущено: {c[QueueStatus.SKIPPED]}  ·  "
            f"помилок: {c[QueueStatus.ERROR]}  ·  в черзі: {c[QueueStatus.PENDING]}  ·  "
            f"активних: {c[QueueStatus.DOWNLOADING]}"
        )
        self.btn_pause.setText("Продовжити" if self.controller.paused else "Пауза")
        self.overall.setText(self.controller.overall_text())
        if self.proxy.hide_finished:
            self.proxy.invalidate()

    # ------------------------------------------------------------------ enqueue
    def enqueue_tracks(self, tracks: list[Track], prefix: str, fmt: str, title: str = "") -> None:
        if not tracks:
            return
        self.controller.add_tracks(list(tracks), prefix, fmt, title or (prefix or "пошук"))

    def _add_url(self) -> None:
        url = self.url.text().strip()
        if not url:
            return
        if self._listing is not None:
            QMessageBox.information(
                self, "Завантажити", "Зачекайте, попередній список ще читається."
            )
            return
        prefix = self.prefix.text().strip()
        fmt = self.fmt.currentData()
        lo, hi = self.range_from.value(), self.range_to.value()
        items = f"{lo or 1}:{hi}" if hi else (f"{lo}:" if lo else None)
        self._start_listing(url, items, prefix, fmt, title=prefix or url, start_index=lo or 1)

    def _start_listing(
        self,
        url: str,
        items: str | None,
        prefix: str,
        fmt: str,
        title: str,
        start_index: int = 1,
        on_item_done=None,
    ) -> None:
        self.form_status.setText(f"Читаю список: {url}")
        self.btn_add.setEnabled(False)
        self.btn_run_profiles.setEnabled(False)

        w = workers.Worker(lambda ctx: downloader.list_playlist(url, items, log_fn=ctx.log))
        w.signals.finished.connect(
            lambda info: self._on_listed(info, prefix, fmt, title, start_index, on_item_done)
        )
        w.signals.error.connect(self._on_list_error)
        w.signals.done.connect(self._on_list_done)
        self._listing = w
        workers.start(w)

    def _on_listed(self, info, prefix, fmt, title, start_index, on_item_done) -> None:
        if not info.entries:
            self.form_status.setText("Список порожній.")
            return
        self.controller.add_tracks(
            info.entries,
            prefix,
            fmt,
            title=f"{prefix or info.title}",
            on_item_done=on_item_done,
            start_index=start_index,
        )
        self.form_status.setText(f"Додано в чергу: {len(info.entries)} ({info.title})")
        self.url.clear()

    def _on_list_error(self, msg: str, tb: str) -> None:
        self.form_status.setText("Помилка читання списку (деталі в логу).")
        QMessageBox.critical(self, "Завантажити", msg)

    def _on_list_done(self) -> None:
        self._listing = None
        self.btn_add.setEnabled(True)
        self.btn_run_profiles.setEnabled(True)
        if self._pending_profiles:
            self._run_next_profile()

    # ------------------------------------------------------------------ profiles → queue
    _pending_profiles: list[Profile] = []

    def _run_profiles(self) -> None:
        sel = [p for p in self._selected_profiles() if p.active]
        if not sel:
            QMessageBox.information(self, "Профілі", "Виберіть хоча б один активний профіль.")
            return
        self._pending_profiles = list(sel)
        if self._listing is None:
            self._run_next_profile()

    def _run_next_profile(self) -> None:
        if not self._pending_profiles:
            return
        p = self._pending_profiles.pop(0)
        start = p.last_index + 1
        items = f"{start}:" if start > 1 else None
        profiles.mark_run(p)
        profiles.save(self.profiles)
        self._fill_profiles()

        def on_done(it: QueueItem, prof=p) -> None:
            profiles.mark_run(prof, it.index)
            profiles.save(self.profiles)
            self._fill_profiles()

        self._start_listing(
            p.url,
            items,
            p.prefix,
            self.state.settings.default_format,
            title=p.name,
            start_index=start,
            on_item_done=on_done,
        )
