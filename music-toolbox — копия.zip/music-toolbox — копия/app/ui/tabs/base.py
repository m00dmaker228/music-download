"""Base class for feature tabs: gets app state and a banner when binaries are missing."""

from __future__ import annotations

from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from app.ui.state import AppState


class BaseTab(QWidget):
    """A tab whose content is disabled with a hint while binaries are missing."""

    required_binaries: tuple[str, ...] = ("yt-dlp", "ffmpeg", "ffprobe")

    def __init__(self, state: AppState, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.state = state
        self.banner = QLabel()
        self.banner.setWordWrap(True)
        self.banner.setStyleSheet(
            "QLabel { background: #fff3cd; color: #664d03; border: 1px solid #ffe69c;"
            " border-radius: 4px; padding: 6px; }"
        )
        self.banner.hide()
        self.content = QWidget()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.addWidget(self.banner)
        outer.addWidget(self.content, 1)
        state.binaries_changed.connect(self._on_binaries)

    def _on_binaries(self, statuses: dict) -> None:
        missing = [n for n in self.required_binaries if not statuses[n].available]
        if missing:
            self.banner.setText(
                "Не знайдено: "
                + ", ".join(missing)
                + ". Перейдіть у вкладку «Налаштування» і натисніть «Встановити / оновити»."
            )
            self.banner.show()
            self.content.setEnabled(False)
        else:
            self.banner.hide()
            self.content.setEnabled(True)


class PlaceholderTab(BaseTab):
    """Stub for tabs that arrive in later stages."""

    def __init__(self, state: AppState, stage: int, title: str, items: list[str]) -> None:
        super().__init__(state)
        layout = QVBoxLayout(self.content)
        head = QLabel(f"<h3>{title}</h3><p>Буде реалізовано на етапі {stage}:</p>")
        layout.addWidget(head)
        for text in items:
            layout.addWidget(QLabel(f"• {text}"))
        layout.addStretch()
