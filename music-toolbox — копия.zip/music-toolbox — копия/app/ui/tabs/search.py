"""Tab «Пошук»: query → SoundCloud / YouTube results (parallel) + iTunes reference metadata."""

from __future__ import annotations

import logging

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from app.core import search
from app.core.models import Track
from app.ui import workers
from app.ui.file_browser import human_duration
from app.ui.state import AppState
from app.ui.tabs.base import BaseTab
from app.ui.tabs.settings import FORMAT_LABELS

log = logging.getLogger(__name__)

SOURCE_LABELS = {"soundcloud": "SoundCloud", "youtube": "YouTube"}


class SearchTab(BaseTab):
    required_binaries = ("yt-dlp",)

    def __init__(self, state: AppState) -> None:
        super().__init__(state)
        self._worker: workers.Worker | None = None
        self._itunes_worker: workers.Worker | None = None
        self.tracks: list[Track] = []

        layout = QVBoxLayout(self.content)
        layout.setContentsMargins(0, 0, 0, 0)

        self.query = QLineEdit()
        self.query.setPlaceholderText("назва — виконавець")
        self.query.returnPressed.connect(self._search)
        self.cb_sc = QCheckBox("SoundCloud")
        self.cb_sc.setChecked(True)
        self.cb_yt = QCheckBox("YouTube")
        self.cb_yt.setChecked(True)
        self.cb_itunes = QCheckBox("Підказки iTunes")
        self.cb_itunes.setChecked(True)
        self.btn_search = QPushButton("Шукати")
        self.btn_search.setDefault(True)
        self.btn_search.clicked.connect(self._search)
        row = QHBoxLayout()
        row.addWidget(self.query, 1)
        row.addWidget(self.cb_sc)
        row.addWidget(self.cb_yt)
        row.addWidget(self.cb_itunes)
        row.addWidget(self.btn_search)
        layout.addLayout(row)

        self.status = QLabel("")
        layout.addWidget(self.status)

        # iTunes hints
        hints_box = QGroupBox("Довідкові метадані (iTunes Search API, без завантаження)")
        hv = QVBoxLayout(hints_box)
        self.hints = QTableWidget(0, 5)
        self.hints.setHorizontalHeaderLabels(("Назва", "Виконавець", "Альбом", "Рік", "Тривалість"))
        self.hints.verticalHeader().setVisible(False)
        self.hints.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.hints.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        hh = self.hints.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.hints.setMaximumHeight(140)
        self.hints.cellDoubleClicked.connect(self._use_hint)
        hv.addWidget(self.hints)

        # results
        results_box = QGroupBox("Результати (подвійний клік — відкрити в браузері)")
        rv = QVBoxLayout(results_box)
        self.results = QTableWidget(0, 5)
        self.results.setHorizontalHeaderLabels(("Джерело", "Назва", "Автор", "Тривалість", "URL"))
        self.results.verticalHeader().setVisible(False)
        self.results.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.results.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.results.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        rh = self.results.horizontalHeader()
        rh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        rh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        rh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        rh.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        rh.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.results.cellDoubleClicked.connect(self._open_url)
        rv.addWidget(self.results, 1)

        dl_row = QHBoxLayout()
        dl_row.addWidget(QLabel("Префікс:"))
        self.prefix = QLineEdit()
        self.prefix.setPlaceholderText("PH_")
        self.prefix.setMaximumWidth(140)
        dl_row.addWidget(self.prefix)
        dl_row.addWidget(QLabel("Формат:"))
        self.fmt = QComboBox()
        for key, label in FORMAT_LABELS.items():
            self.fmt.addItem(label, key)
        self.fmt.setCurrentIndex(max(0, self.fmt.findData(state.settings.default_format)))
        dl_row.addWidget(self.fmt)
        dl_row.addStretch()
        self.btn_download = QPushButton("Завантажити вибране → у чергу")
        self.btn_download.clicked.connect(self._download_selected)
        dl_row.addWidget(self.btn_download)
        rv.addLayout(dl_row)

        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(hints_box)
        split.addWidget(results_box)
        split.setSizes([150, 400])
        layout.addWidget(split, 1)

        state.settings_changed.connect(
            lambda: self.fmt.setCurrentIndex(
                max(0, self.fmt.findData(state.settings.default_format))
            )
        )

    # ------------------------------------------------------------------
    def _search(self) -> None:
        q = self.query.text().strip()
        if not q:
            return
        sources = [
            s for s, cb in (("soundcloud", self.cb_sc), ("youtube", self.cb_yt)) if cb.isChecked()
        ]
        if not sources:
            QMessageBox.information(self, "Пошук", "Виберіть хоча б одне джерело.")
            return
        if self._worker is not None:
            return
        self.results.setRowCount(0)
        self.tracks = []
        self.status.setText("Пошук…")
        self.btn_search.setEnabled(False)
        log.info("Search %r in %s", q, sources)

        w = workers.Worker(lambda ctx: search.search_all(q, sources))
        w.signals.finished.connect(self._on_results)
        w.signals.error.connect(lambda m, tb: self.status.setText(f"Помилка: {m}"))
        w.signals.done.connect(self._on_done)
        self._worker = w
        workers.start(w)

        if self.cb_itunes.isChecked():
            self.hints.setRowCount(0)
            iw = workers.Worker(lambda ctx: search.itunes_lookup(q, limit=5))
            iw.signals.finished.connect(self._on_hints)
            iw.signals.error.connect(lambda m, tb: log.warning("iTunes lookup failed: %s", m))
            self._itunes_worker = iw
            workers.start(iw)

    def _on_done(self) -> None:
        self._worker = None
        self.btn_search.setEnabled(True)

    def _on_results(self, res: dict) -> None:
        errors = []
        for source, value in res.items():
            if isinstance(value, Exception):
                errors.append(f"{SOURCE_LABELS.get(source, source)}: {value}".splitlines()[0])
                continue
            for t in value:
                self.tracks.append(t)
                row = self.results.rowCount()
                self.results.insertRow(row)
                cells = (
                    SOURCE_LABELS.get(t.source, t.source),
                    t.title,
                    t.uploader,
                    human_duration(t.duration),
                    t.url,
                )
                for col, text in enumerate(cells):
                    item = QTableWidgetItem(text)
                    if col == 0:
                        item.setData(Qt.ItemDataRole.UserRole, len(self.tracks) - 1)
                    self.results.setItem(row, col, item)
        msg = f"Знайдено: {len(self.tracks)}"
        if errors:
            msg += "  ·  " + "; ".join(errors)
        self.status.setText(msg)

    def _on_hints(self, hits: list) -> None:
        self.hints.setRowCount(0)
        for h in hits:
            row = self.hints.rowCount()
            self.hints.insertRow(row)
            for col, text in enumerate(
                (h.title, h.artist, h.album, h.year, human_duration(h.duration))
            ):
                self.hints.setItem(row, col, QTableWidgetItem(text))

    def _use_hint(self, row: int, _col: int) -> None:
        title = self.hints.item(row, 0).text()
        artist = self.hints.item(row, 1).text()
        self.query.setText(f"{artist} - {title}")

    def _selected_tracks(self) -> list[Track]:
        rows = sorted({i.row() for i in self.results.selectedIndexes()})
        return [self.tracks[self.results.item(r, 0).data(Qt.ItemDataRole.UserRole)] for r in rows]

    def _open_url(self, row: int, _col: int) -> None:
        url = self.results.item(row, 4).text()
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def _download_selected(self) -> None:
        tracks = self._selected_tracks()
        if not tracks:
            QMessageBox.information(self, "Завантажити", "Виберіть результати в таблиці.")
            return
        prefix = self.prefix.text().strip()
        self.state.enqueue_tracks.emit(tracks, prefix, self.fmt.currentData())
        self.status.setText(f"Додано в чергу: {len(tracks)} (вкладка «Завантажити»)")
