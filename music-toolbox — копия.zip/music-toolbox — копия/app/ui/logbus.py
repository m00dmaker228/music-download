"""Bridge Python logging into the GUI log view (thread-safe through a Qt signal)."""

from __future__ import annotations

import logging

from PySide6.QtCore import QObject, Signal

from app.core.logsetup import DATEFMT, FORMAT


class LogBus(QObject):
    record = Signal(str)


_bus: LogBus | None = None


def bus() -> LogBus:
    global _bus
    if _bus is None:
        _bus = LogBus()
    return _bus


class QtLogHandler(logging.Handler):
    def __init__(self) -> None:
        super().__init__(logging.INFO)
        self.setFormatter(logging.Formatter(FORMAT, DATEFMT))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            bus().record.emit(self.format(record))
        except Exception:  # noqa: BLE001
            self.handleError(record)


def install() -> QtLogHandler:
    root = logging.getLogger()
    for h in root.handlers:
        if isinstance(h, QtLogHandler):
            return h
    handler = QtLogHandler()
    root.addHandler(handler)
    return handler
