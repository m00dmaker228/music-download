"""Shared GUI state: settings, binary availability, current file selection."""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from app.core import binaries, paths
from app.core import settings as settings_mod
from app.core.archive import Archive
from app.core.library import LibraryCache
from app.core.models import BinaryStatus
from app.ui import workers

log = logging.getLogger(__name__)


class AppState(QObject):
    settings_changed = Signal()
    binaries_changed = Signal(dict)  # {name: BinaryStatus}
    selection_changed = Signal(list)  # list[Path]
    files_changed = Signal()  # ask the file browser to rescan
    status_message = Signal(str)  # short text for the status bar
    enqueue_tracks = Signal(list, str, str)  # (list[Track], prefix, fmt) → download queue

    def __init__(self) -> None:
        super().__init__()
        self.settings = settings_mod.load()
        self.binaries: dict[str, BinaryStatus] = {
            n: BinaryStatus(n, None, None) for n in binaries.NAMES
        }
        self.selection: list[Path] = []
        paths.ensure_dirs()
        self.library_cache = LibraryCache()
        self.archive = Archive()
        self._checking = False

    # ---- settings
    def save_settings(self) -> None:
        settings_mod.save(self.settings)
        log.info("Settings saved")
        self.settings_changed.emit()

    # ---- selection
    def set_selection(self, paths_: list[Path]) -> None:
        self.selection = list(paths_)
        self.selection_changed.emit(self.selection)

    # ---- binaries
    @property
    def binaries_ok(self) -> bool:
        return all(b.available for b in self.binaries.values())

    def has(self, *names: str) -> bool:
        return all(self.binaries[n].available for n in names)

    def missing_binaries(self) -> list[str]:
        return [n for n, b in self.binaries.items() if not b.available]

    def refresh_binaries(self) -> None:
        """Probe versions in the background and emit `binaries_changed`."""
        if self._checking:
            return
        self._checking = True

        def task(ctx):
            return binaries.status_all()

        w = workers.Worker(task)
        w.signals.finished.connect(self._on_binaries)
        w.signals.done.connect(lambda: setattr(self, "_checking", False))
        workers.start(w)

    def _on_binaries(self, result: dict[str, BinaryStatus]) -> None:
        self.binaries = result
        self.binaries_changed.emit(result)
