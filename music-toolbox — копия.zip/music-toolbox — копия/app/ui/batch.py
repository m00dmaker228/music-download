"""Run a core batch function (tags/process) in a worker and show per-file results."""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.models import OpResult
from app.ui import workers
from app.ui.state import AppState

log = logging.getLogger(__name__)


class BatchPanel(QWidget):
    """Progress bar + results table + cancel; one batch at a time."""

    started = Signal()
    finished = Signal(list)  # list[OpResult]

    def __init__(self, state: AppState, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.state = state
        self._worker: workers.Worker | None = None

        self.label = QLabel("Готово")
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.btn_cancel = QPushButton("Скасувати")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.cancel)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(("Файл", "Статус", "Результат / помилка"))
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.cellDoubleClicked.connect(self._show_error)

        top = QHBoxLayout()
        top.addWidget(self.label, 1)
        top.addWidget(self.bar, 2)
        top.addWidget(self.btn_cancel)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addLayout(top)
        layout.addWidget(self.table, 1)

    @property
    def busy(self) -> bool:
        return self._worker is not None

    def run(
        self,
        title: str,
        fn: Callable[..., list[OpResult]],
        paths: list[Path],
        params: dict | None = None,
        on_done: Callable[[list[OpResult]], None] | None = None,
    ) -> bool:
        """Start `fn(paths, **params, progress=..., [is_cancelled=...])`."""
        if self.busy:
            QMessageBox.information(self, title, "Інша операція ще виконується.")
            return False
        if not paths:
            QMessageBox.information(self, title, "Виберіть файли в панелі «Файли» ліворуч.")
            return False
        params = dict(params or {})
        self.table.setRowCount(0)
        self.bar.setRange(0, len(paths))
        self.bar.setValue(0)
        self.label.setText(f"{title}: 0 / {len(paths)}")
        self.btn_cancel.setEnabled(True)
        log.info("Batch '%s' on %d file(s): %s", title, len(paths), params)

        def task(ctx):
            def progress(i, n, p, **extra):
                ctx.progress(done=i, total=n, path=str(p), **extra)

            kwargs = dict(params)
            kwargs["progress"] = progress
            if fn_accepts_cancel(fn):
                kwargs["is_cancelled"] = ctx.is_cancelled
            return fn(paths, **kwargs)

        w = workers.Worker(task)
        w.signals.progress.connect(lambda p: self._on_progress(title, p))
        w.signals.finished.connect(lambda res: self._on_finished(res, on_done))
        w.signals.error.connect(self._on_error)
        w.signals.done.connect(self._on_done)
        self._worker = w
        self.started.emit()
        workers.start(w)
        return True

    def cancel(self) -> None:
        if self._worker:
            self._worker.cancel()
            self.label.setText("Скасування…")

    # ---- internals
    def _on_progress(self, title: str, p: dict) -> None:
        if "percent" in p:
            self.label.setText(f"{title}: {p['done']} / {p['total']}  ({p['percent']:.0f}%)")
            self.bar.setRange(0, 100 * p["total"])
            self.bar.setValue(int(100 * (p["done"] - 1) + p["percent"]))
        else:
            self.label.setText(f"{title}: {p['done']} / {p['total']}")
            self.bar.setRange(0, p["total"])
            self.bar.setValue(p["done"])

    def _on_finished(self, results: list[OpResult], on_done) -> None:
        ok = sum(1 for r in results if r.ok)
        self.label.setText(f"Готово: {ok} успішно, {len(results) - ok} з помилками")
        self.bar.setRange(0, 1)
        self.bar.setValue(1)
        self.table.setRowCount(0)
        for r in results:
            row = self.table.rowCount()
            self.table.insertRow(row)
            status = QTableWidgetItem("✓" if r.ok else "✗")
            status.setForeground(Qt.GlobalColor.darkGreen if r.ok else Qt.GlobalColor.red)
            text = r.output_path.name if (r.ok and r.output_path) else (r.error or "")
            err_item = QTableWidgetItem(text.splitlines()[0] if text else "")
            err_item.setData(Qt.ItemDataRole.UserRole, text)
            self.table.setItem(row, 0, QTableWidgetItem(r.path.name))
            self.table.setItem(row, 1, status)
            self.table.setItem(row, 2, err_item)
        self.finished.emit(results)
        if on_done:
            on_done(results)
        self.state.files_changed.emit()

    def _on_error(self, msg: str, tb: str) -> None:
        self.label.setText(f"Помилка: {msg}")
        QMessageBox.critical(self, "Помилка", f"{msg}\n\nПовний текст є в логу (Налаштування).")

    def _on_done(self) -> None:
        self._worker = None
        self.btn_cancel.setEnabled(False)

    def _show_error(self, row: int, _col: int) -> None:
        item = self.table.item(row, 2)
        text = item.data(Qt.ItemDataRole.UserRole) if item else ""
        if text and len(text) > 60 or (text and "\n" in text):
            QMessageBox.information(self, self.table.item(row, 0).text(), text)


def fn_accepts_cancel(fn: Callable) -> bool:
    import inspect

    try:
        return "is_cancelled" in inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False
