"""Main window: file browser on the left, feature tabs on the right."""

from __future__ import annotations

import logging

from PySide6.QtCore import QSettings, Qt, QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QLabel,
    QMainWindow,
    QMessageBox,
    QSplitter,
    QSystemTrayIcon,
    QTabWidget,
)

from app.core import paths
from app.core.models import QueueStatus
from app.ui import taskbar
from app.ui.file_browser import FileBrowser
from app.ui.state import AppState
from app.ui.tabs.download import DownloadTab
from app.ui.tabs.process import ProcessTab
from app.ui.tabs.search import SearchTab
from app.ui.tabs.settings import SettingsTab
from app.ui.tabs.tags import TagsTab

log = logging.getLogger(__name__)


def app_icon() -> QIcon:
    for cand in (paths.app_root() / "build" / "icon.png", paths.app_root() / "icon.png"):
        if cand.is_file():
            return QIcon(str(cand))
    return QIcon()


class MainWindow(QMainWindow):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self.setWindowTitle(paths.APP_DISPLAY_NAME)
        self.setWindowIcon(app_icon())
        self.resize(1280, 800)

        self.file_browser = FileBrowser(state)

        self.tabs = QTabWidget()
        self.download_tab = DownloadTab(state)
        self.search_tab = SearchTab(state)
        self.tags_tab = TagsTab(state)
        self.process_tab = ProcessTab(state)
        self.settings_tab = SettingsTab(state)
        self.tabs.addTab(self.download_tab, "Завантажити")
        self.tabs.addTab(self.search_tab, "Пошук")
        self.tabs.addTab(self.tags_tab, "Теги")
        self.tabs.addTab(self.process_tab, "Обробка")
        self.tabs.addTab(self.settings_tab, "Налаштування")

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self.file_browser)
        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)
        splitter.setSizes([480, 800])
        self.splitter = splitter
        self.setCentralWidget(splitter)

        self.status_bins = QLabel()
        self.status_sel = QLabel()
        self.statusBar().addWidget(self.status_sel, 1)
        self.statusBar().addPermanentWidget(self.status_bins)

        state.binaries_changed.connect(self._on_binaries)
        state.status_message.connect(lambda m: self.statusBar().showMessage(m, 5000))
        self.file_browser.selection_changed.connect(
            lambda sel: self.status_sel.setText(f"Вибрано файлів: {len(sel)}")
        )
        self.status_sel.setText("Вибрано файлів: 0")
        self.status_bins.setText("Перевірка програм…")

        # Search results → download queue, and switch to that tab so the user sees them.
        state.enqueue_tracks.connect(lambda *_a: self.tabs.setCurrentWidget(self.download_tab))

        # Notifications + taskbar progress for the download queue.
        self.tray: QSystemTrayIcon | None = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray = QSystemTrayIcon(self.windowIcon(), self)
            self.tray.setToolTip(paths.APP_DISPLAY_NAME)
            self.tray.show()
        self.taskbar: taskbar.TaskbarProgress | None = None
        self.download_tab.controller.group_finished.connect(self._notify_group)
        self.download_tab.controller.changed.connect(self._update_taskbar)

        self._restore_geometry()
        # Probe binaries after the window is shown so start-up never blocks.
        QTimer.singleShot(0, state.refresh_binaries)
        QTimer.singleShot(0, self._init_taskbar)

    # ---- binaries status
    def _on_binaries(self, statuses: dict) -> None:
        missing = [n for n, s in statuses.items() if not s.available]
        if missing:
            self.status_bins.setText("Відсутні: " + ", ".join(missing))
            self.status_bins.setStyleSheet("color: #b02a37;")
            self.tabs.setCurrentWidget(self.settings_tab)
        else:
            parts = [f"{n} {s.version or '?'}" for n, s in statuses.items()]
            self.status_bins.setText(" · ".join(parts))
            self.status_bins.setStyleSheet("")

    # ---- notifications / taskbar
    def _notify_group(self, title: str, done: int, errors: int) -> None:
        text = f"{title}: завантажено {done}" + (f", помилок {errors}" if errors else "")
        self.statusBar().showMessage(text, 10000)
        if self.tray is not None and self.tray.isVisible():
            icon = (
                QSystemTrayIcon.MessageIcon.Warning
                if errors
                else QSystemTrayIcon.MessageIcon.Information
            )
            self.tray.showMessage("Music Toolbox — завантаження завершено", text, icon, 8000)

    def _init_taskbar(self) -> None:
        try:
            self.taskbar = taskbar.TaskbarProgress(int(self.winId()))
        except Exception as exc:  # noqa: BLE001
            log.debug("Taskbar init failed: %s", exc)

    def _update_taskbar(self) -> None:
        if self.taskbar is None or not self.taskbar.available:
            return
        counts = self.download_tab.model.counts()
        active = counts[QueueStatus.DOWNLOADING] + counts[QueueStatus.PENDING]
        if active == 0:
            self.taskbar.clear()
            return
        total = sum(counts.values())
        finished = total - active
        if self.download_tab.controller.paused:
            self.taskbar.set_state(taskbar.TBPF_PAUSED)
            return
        self.taskbar.set_progress(finished, total)

    # ---- window geometry persistence (Qt-native, separate from settings.json)
    def _qsettings(self) -> QSettings:
        return QSettings("MusicToolbox", "MusicToolbox")

    def _restore_geometry(self) -> None:
        qs = self._qsettings()
        geo = qs.value("main/geometry")
        if geo is not None:
            self.restoreGeometry(geo)
        split = qs.value("main/splitter")
        if split is not None:
            self.splitter.restoreState(split)

    def closeEvent(self, event) -> None:  # noqa: N802 — Qt override
        ctl = self.download_tab.controller
        if ctl.active > 0:
            answer = QMessageBox.question(
                self,
                "Вихід",
                f"Триває {ctl.active} завантаження. Скасувати їх і вийти?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            ctl.cancel_all()
        self.process_tab._stop_preview()
        qs = self._qsettings()
        qs.setValue("main/geometry", self.saveGeometry())
        qs.setValue("main/splitter", self.splitter.saveState())
        if self.tray is not None:
            self.tray.hide()
        super().closeEvent(event)


__all__ = ["MainWindow", "app_icon"]
