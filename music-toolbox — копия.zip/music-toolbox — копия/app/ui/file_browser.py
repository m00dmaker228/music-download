"""Left panel: files of the working folder with multi-selection, filters, rename/delete."""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QSortFilterProxyModel,
    Qt,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from app.core import library
from app.core.library import FileInfo
from app.ui import workers
from app.ui.state import AppState

log = logging.getLogger(__name__)


def human_size(n: int) -> str:
    size = float(n)
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if size < 1024 or unit == "ГБ":
            return f"{size:.0f} {unit}" if unit == "Б" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} ГБ"


def human_duration(seconds: float | None) -> str:
    if seconds is None:
        return ""
    s = int(round(seconds))
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def open_in_file_manager(path: Path) -> None:
    try:
        if sys.platform == "win32":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except OSError as exc:
        log.error("Cannot open %s: %s", path, exc)


class FileTableModel(QAbstractTableModel):
    COLUMNS = ("Назва", "Префікс", "Тривалість", "Формат", "Бітрейт", "Розмір", "Теги", "Album")

    def __init__(self) -> None:
        super().__init__()
        self.files: list[FileInfo] = []

    def set_files(self, files: list[FileInfo]) -> None:
        self.beginResetModel()
        self.files = files
        self.endResetModel()

    def rowCount(self, parent=None) -> int:  # noqa: N802
        return 0 if (parent is not None and parent.isValid()) else len(self.files)

    def columnCount(self, parent=None) -> int:  # noqa: N802
        return len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return self.COLUMNS[section]
        return None

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole) -> Any:
        if not index.isValid():
            return None
        f = self.files[index.row()]
        col = index.column()
        if role == Qt.ItemDataRole.DisplayRole:
            return (
                f.name,
                f.prefix,
                human_duration(f.duration),
                f.fmt,
                f"{f.bitrate} k" if f.bitrate else "",
                human_size(f.size),
                "✓" if f.has_tags else "",
                f.album,
            )[col]
        if role == Qt.ItemDataRole.UserRole:  # sort key
            return (
                f.name.lower(),
                f.prefix,
                f.duration or 0.0,
                f.fmt,
                f.bitrate or 0,
                f.size,
                int(f.has_tags),
                f.album.lower(),
            )[col]
        if role == Qt.ItemDataRole.ToolTipRole:
            return f.path
        if role == Qt.ItemDataRole.TextAlignmentRole and col in (2, 4, 5, 6):
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return None

    def file_at(self, row: int) -> FileInfo:
        return self.files[row]


class FileFilterProxy(QSortFilterProxyModel):
    def __init__(self) -> None:
        super().__init__()
        self.prefix = ""
        self.needle = ""
        self.setSortRole(Qt.ItemDataRole.UserRole)

    def filterAcceptsRow(self, row: int, parent: QModelIndex) -> bool:  # noqa: N802
        f: FileInfo = self.sourceModel().file_at(row)
        if self.prefix and f.prefix != self.prefix:
            return False
        return self.needle in f.name.lower() if self.needle else True


class FileBrowser(QWidget):
    selection_changed = Signal(list)  # list[Path]

    def __init__(self, state: AppState, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.state = state
        self._scan_worker: workers.Worker | None = None
        self._rescan_requested = False

        self.model = FileTableModel()
        self.proxy = FileFilterProxy()
        self.proxy.setSourceModel(self.model)

        self.prefix_box = QComboBox()
        self.prefix_box.addItem("Усі префікси", "")
        self.prefix_box.currentIndexChanged.connect(self._apply_filter)
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Фільтр за назвою…")
        self.filter_edit.setClearButtonEnabled(True)
        self.filter_edit.textChanged.connect(self._apply_filter)

        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(22)
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i in range(1, len(FileTableModel.COLUMNS)):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setStretchLastSection(False)
        self.table.selectionModel().selectionChanged.connect(self._emit_selection)
        self.table.doubleClicked.connect(self._open_file)

        self.btn_refresh = QPushButton("Оновити")
        self.btn_refresh.clicked.connect(self.refresh)
        btn_open = QPushButton("Відкрити папку")
        btn_open.clicked.connect(self._open_folder)
        btn_all = QPushButton("Вибрати всі")
        btn_all.clicked.connect(self.table.selectAll)
        self.btn_rename = QPushButton("Перейменувати")
        self.btn_rename.clicked.connect(self._rename)
        self.btn_delete = QPushButton("Видалити")
        self.btn_delete.clicked.connect(self._delete)

        buttons = QHBoxLayout()
        for b in (self.btn_refresh, btn_open, btn_all, self.btn_rename, self.btn_delete):
            buttons.addWidget(b)
        buttons.addStretch()

        filters = QHBoxLayout()
        filters.addWidget(self.prefix_box)
        filters.addWidget(self.filter_edit, 1)

        self.path_label = QLabel()
        self.path_label.setWordWrap(True)
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.count_label = QLabel()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.addWidget(QLabel("<b>Файли</b>"))
        layout.addWidget(self.path_label)
        layout.addLayout(filters)
        layout.addWidget(self.table, 1)
        layout.addWidget(self.count_label)
        layout.addLayout(buttons)

        state.settings_changed.connect(self.refresh)
        state.files_changed.connect(self.refresh)
        state.binaries_changed.connect(lambda _s: self.refresh())
        self._emit_selection()

    # ------------------------------------------------------------------ public
    def selected_paths(self) -> list[Path]:
        rows = sorted(
            {self.proxy.mapToSource(i).row() for i in self.table.selectionModel().selectedRows()}
        )
        return [Path(self.model.file_at(r).path) for r in rows]

    def selected_infos(self) -> list[FileInfo]:
        rows = sorted(
            {self.proxy.mapToSource(i).row() for i in self.table.selectionModel().selectedRows()}
        )
        return [self.model.file_at(r) for r in rows]

    def refresh(self) -> None:
        """Rescan the working folder in the background (coalesces repeated requests)."""
        if self._scan_worker is not None:
            self._rescan_requested = True
            return
        work = self.state.settings.work_path
        recursive = self.state.settings.recursive_scan
        cache = self.state.library_cache
        self.path_label.setText(str(work))
        self.btn_refresh.setEnabled(False)
        self.count_label.setText("Сканування…")

        def task(ctx):
            def prog(i, n, p):
                if i % 10 == 0 or i == n:
                    ctx.progress(done=i, total=n)

            return library.scan(work, recursive, cache, prog, ctx.is_cancelled)

        w = workers.Worker(task)
        w.signals.progress.connect(
            lambda p: self.count_label.setText(f"Сканування… {p['done']} / {p['total']}")
        )
        w.signals.finished.connect(self._on_scanned)
        w.signals.error.connect(lambda m, tb: self.count_label.setText(f"Помилка: {m}"))
        w.signals.done.connect(self._on_scan_done)
        self._scan_worker = w
        workers.start(w)

    # ------------------------------------------------------------------ internals
    def _on_scanned(self, files: list[FileInfo]) -> None:
        selected = {str(p) for p in self.selected_paths()}
        self.model.set_files(files)
        prefixes = sorted({f.prefix for f in files if f.prefix})
        current = self.prefix_box.currentData()
        self.prefix_box.blockSignals(True)
        self.prefix_box.clear()
        self.prefix_box.addItem("Усі префікси", "")
        for p in prefixes:
            self.prefix_box.addItem(p, p)
        idx = self.prefix_box.findData(current)
        self.prefix_box.setCurrentIndex(max(0, idx))
        self.prefix_box.blockSignals(False)
        self._apply_filter()
        if selected:
            sel = self.table.selectionModel()
            for row in range(self.proxy.rowCount()):
                src = self.proxy.mapToSource(self.proxy.index(row, 0)).row()
                if self.model.file_at(src).path in selected:
                    sel.select(
                        self.proxy.index(row, 0),
                        sel.SelectionFlag.Select | sel.SelectionFlag.Rows,
                    )
        self._emit_selection()

    def _on_scan_done(self) -> None:
        self._scan_worker = None
        self.btn_refresh.setEnabled(True)
        if self._rescan_requested:
            self._rescan_requested = False
            self.refresh()

    def _apply_filter(self) -> None:
        self.proxy.prefix = self.prefix_box.currentData() or ""
        self.proxy.needle = self.filter_edit.text().strip().lower()
        self.proxy.invalidate()
        self.count_label.setText(f"Файлів: {self.proxy.rowCount()} з {self.model.rowCount()}")

    def _emit_selection(self, *_args) -> None:
        sel = self.selected_paths()
        self.btn_rename.setEnabled(len(sel) == 1)
        self.btn_delete.setEnabled(bool(sel))
        self.state.set_selection(sel)
        self.selection_changed.emit(sel)

    def _open_folder(self) -> None:
        work = self.state.settings.work_path
        if not work.is_dir():
            answer = QMessageBox.question(self, "Робоча папка", f"Папки {work} не існує. Створити?")
            if answer != QMessageBox.StandardButton.Yes:
                return
            work.mkdir(parents=True, exist_ok=True)
            self.refresh()
        open_in_file_manager(work)

    def _open_file(self, index: QModelIndex) -> None:
        src = self.proxy.mapToSource(index).row()
        open_in_file_manager(Path(self.model.file_at(src).path))

    def _rename(self) -> None:
        sel = self.selected_paths()
        if len(sel) != 1:
            return
        old = sel[0]
        new_name, ok = QInputDialog.getText(self, "Перейменувати", "Нова назва:", text=old.name)
        new_name = new_name.strip()
        if not ok or not new_name or new_name == old.name:
            return
        target = old.with_name(new_name)
        if target.exists():
            QMessageBox.warning(self, "Перейменувати", f"Файл {new_name} уже існує.")
            return
        try:
            old.rename(target)
            self.state.library_cache.forget(old)
            log.info("Renamed %s -> %s", old, target)
        except OSError as exc:
            log.error("Rename failed: %s", exc)
            QMessageBox.critical(self, "Перейменувати", str(exc))
            return
        self.refresh()

    def _delete(self) -> None:
        sel = self.selected_paths()
        if not sel:
            return
        names = "\n".join(p.name for p in sel[:10]) + ("\n…" if len(sel) > 10 else "")
        answer = QMessageBox.question(
            self,
            "Видалити",
            f"Видалити {len(sel)} файл(ів) без можливості відновлення?\n\n{names}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        errors = []
        for p in sel:
            try:
                p.unlink()
                self.state.library_cache.forget(p)
                log.info("Deleted %s", p)
            except OSError as exc:
                log.error("Delete failed for %s: %s", p, exc)
                errors.append(f"{p.name}: {exc}")
        if errors:
            QMessageBox.critical(self, "Видалити", "\n".join(errors))
        self.refresh()
