"""Windows taskbar progress (ITaskbarList3 via ctypes). No-op on other platforms.

Qt 6 dropped QtWinExtras, so the COM interface is called directly. Every call is
wrapped so a failure can never affect the application.
"""

from __future__ import annotations

import ctypes
import logging
import sys

log = logging.getLogger(__name__)

TBPF_NOPROGRESS = 0
TBPF_INDETERMINATE = 0x1
TBPF_NORMAL = 0x2
TBPF_ERROR = 0x4
TBPF_PAUSED = 0x8


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_ulong),
        ("Data2", ctypes.c_ushort),
        ("Data3", ctypes.c_ushort),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    @classmethod
    def from_str(cls, text: str) -> _GUID:
        import uuid

        u = uuid.UUID(text)
        g = cls()
        g.Data1 = u.time_low
        g.Data2 = u.time_mid
        g.Data3 = u.time_hi_version
        for i, b in enumerate(u.bytes[8:]):
            g.Data4[i] = b
        return g


class TaskbarProgress:
    def __init__(self, hwnd: int) -> None:
        self._ok = False
        self._hwnd = hwnd
        if sys.platform != "win32":
            return
        try:
            ole32 = ctypes.windll.ole32  # type: ignore[attr-defined]
            ole32.CoInitialize(None)
            clsid = _GUID.from_str("56FDF344-FD6D-11d0-958A-006097C9A090")
            iid = _GUID.from_str("ea1afb91-9e28-4b86-90e9-9e9f8a5eefaf")
            ptr = ctypes.c_void_p()
            hr = ole32.CoCreateInstance(
                ctypes.byref(clsid), None, 1, ctypes.byref(iid), ctypes.byref(ptr)
            )
            if hr != 0 or not ptr.value:
                raise OSError(f"CoCreateInstance failed: 0x{hr & 0xFFFFFFFF:08x}")
            self._ptr = ptr
            vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
            proto_init = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)  # type: ignore[attr-defined]
            proto_value = ctypes.WINFUNCTYPE(  # type: ignore[attr-defined]
                ctypes.c_long,
                ctypes.c_void_p,
                ctypes.c_void_p,
                ctypes.c_ulonglong,
                ctypes.c_ulonglong,
            )
            proto_state = ctypes.WINFUNCTYPE(  # type: ignore[attr-defined]
                ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int
            )
            self._hr_init = proto_init(vtbl[3])
            self._set_value = proto_value(vtbl[9])
            self._set_state = proto_state(vtbl[10])
            self._hr_init(ptr)
            self._ok = True
        except Exception as exc:  # noqa: BLE001 — purely cosmetic feature
            log.debug("Taskbar progress unavailable: %s", exc)

    @property
    def available(self) -> bool:
        return self._ok

    def set_progress(self, done: int, total: int) -> None:
        if not self._ok:
            return
        try:
            if total <= 0:
                self._set_state(self._ptr, self._hwnd, TBPF_NOPROGRESS)
            else:
                self._set_state(self._ptr, self._hwnd, TBPF_NORMAL)
                self._set_value(self._ptr, self._hwnd, int(done), int(total))
        except Exception as exc:  # noqa: BLE001
            log.debug("Taskbar progress call failed: %s", exc)
            self._ok = False

    def set_state(self, state: int) -> None:
        if not self._ok:
            return
        try:
            self._set_state(self._ptr, self._hwnd, state)
        except Exception as exc:  # noqa: BLE001
            log.debug("Taskbar state call failed: %s", exc)
            self._ok = False

    def clear(self) -> None:
        self.set_state(TBPF_NOPROGRESS)
