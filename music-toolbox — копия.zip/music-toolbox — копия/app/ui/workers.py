"""Background execution for the GUI.

Every long operation runs as a `Worker` (QRunnable) in the global QThreadPool.
The task function receives a `WorkerContext` as its first argument and uses
`ctx.progress(**payload)`, `ctx.log(msg)` and `ctx.is_cancelled()`.
Results and errors come back on the GUI thread through Qt signals.
"""

from __future__ import annotations

import logging
import threading
import traceback
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

log = logging.getLogger(__name__)


class WorkerSignals(QObject):
    progress = Signal(dict)
    log = Signal(str)
    finished = Signal(object)  # result of the task function
    error = Signal(str, str)  # (short message, full traceback)
    done = Signal()  # always emitted last


class WorkerContext:
    """Handed to the task function; the only way the task talks to the UI."""

    def __init__(self, signals: WorkerSignals, cancel_event: threading.Event) -> None:
        self._signals = signals
        self._cancel = cancel_event

    def progress(self, **payload: Any) -> None:
        self._signals.progress.emit(payload)

    def log(self, msg: str) -> None:
        log.info(msg)
        self._signals.log.emit(msg)

    def is_cancelled(self) -> bool:
        return self._cancel.is_set()


class Worker(QRunnable):
    """Run `fn(ctx, *args, **kwargs)` in a pool thread."""

    def __init__(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()
        self._cancel = threading.Event()
        self.setAutoDelete(True)

    def cancel(self) -> None:
        self._cancel.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    @Slot()
    def run(self) -> None:
        ctx = WorkerContext(self.signals, self._cancel)
        try:
            result = self.fn(ctx, *self.args, **self.kwargs)
        except Exception as exc:  # noqa: BLE001 — every error must reach the user
            tb = traceback.format_exc()
            log.error("Worker %s failed: %s\n%s", getattr(self.fn, "__name__", self.fn), exc, tb)
            self.signals.error.emit(str(exc), tb)
        else:
            self.signals.finished.emit(result)
        finally:
            self.signals.done.emit()


_running: set[Worker] = set()


def start(worker: Worker, pool: QThreadPool | None = None) -> Worker:
    """Start the worker, keeping a strong reference until it is done."""
    _running.add(worker)
    worker.signals.done.connect(lambda w=worker: _running.discard(w))
    (pool or QThreadPool.globalInstance()).start(worker)
    return worker
