"""Download queue: table model, progress delegate and the scheduler (controller).

The controller owns a private QThreadPool whose size is the configured parallelism,
starts one `downloader.download_track` worker per queued track, and throttles
row updates to ~10/s through a 100 ms flush timer.
"""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from PySide6.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QObject,
    QSortFilterProxyModel,
    Qt,
    QThreadPool,
    QTimer,
    Signal,
)
from PySide6.QtWidgets import (
    QApplication,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionProgressBar,
)

from app.core import downloader
from app.core.models import QueueItem, QueueStatus, Track
from app.ui import workers
from app.ui.file_browser import human_size
from app.ui.state import AppState

log = logging.getLogger(__name__)

STATUS_LABELS = {
    QueueStatus.PENDING: "очікує",
    QueueStatus.DOWNLOADING: "завантажується",
    QueueStatus.DONE: "готово",
    QueueStatus.ERROR: "помилка",
    QueueStatus.SKIPPED: "пропущено",
    QueueStatus.CANCELLED: "скасовано",
}
FINISHED = {QueueStatus.DONE, QueueStatus.ERROR, QueueStatus.SKIPPED, QueueStatus.CANCELLED}


def human_eta(seconds: float | None) -> str:
    if seconds is None:
        return ""
    s = int(seconds)
    if s < 60:
        return f"{s} с"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m} хв {s:02d} с"
    h, m = divmod(m, 60)
    return f"{h} год {m:02d} хв"


# --------------------------------------------------------------------------- model


class QueueModel(QAbstractTableModel):
    COLUMNS = ("Статус", "Префікс", "Назва", "Прогрес", "Швидкість", "ETA", "Розмір")
    COL_PROGRESS = 3

    def __init__(self) -> None:
        super().__init__()
        self.items: list[QueueItem] = []
        self._rows: dict[str, int] = {}

    # ---- Qt API
    def rowCount(self, parent=None) -> int:  # noqa: N802
        return 0 if (parent is not None and parent.isValid()) else len(self.items)

    def columnCount(self, parent=None) -> int:  # noqa: N802
        return len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return self.COLUMNS[section]
        return None

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole) -> Any:
        if not index.isValid():
            return None
        it = self.items[index.row()]
        col = index.column()
        if role == Qt.ItemDataRole.DisplayRole:
            if col == 0:
                return STATUS_LABELS[it.status]
            if col == 1:
                return it.prefix
            if col == 2:
                return it.track.title
            if col == 3:
                return f"{it.progress:.0f}%"
            if col == 4:
                return f"{human_size(int(it.speed))}/с" if it.speed else ""
            if col == 5:
                return human_eta(it.eta) if it.status == QueueStatus.DOWNLOADING else ""
            if col == 6:
                if it.total_bytes:
                    return human_size(it.total_bytes)
                return human_size(it.downloaded_bytes) if it.downloaded_bytes else ""
        if role == Qt.ItemDataRole.UserRole:
            return it.progress if col == 3 else it.task_id
        if role == Qt.ItemDataRole.ToolTipRole:
            if it.error:
                return it.error
            return it.filename or it.track.url
        if role == Qt.ItemDataRole.ForegroundRole and col == 0:
            if it.status == QueueStatus.ERROR:
                return Qt.GlobalColor.red
            if it.status == QueueStatus.DONE:
                return Qt.GlobalColor.darkGreen
            if it.status in (QueueStatus.SKIPPED, QueueStatus.CANCELLED):
                return Qt.GlobalColor.gray
        return None

    # ---- mutation
    def add(self, items: list[QueueItem]) -> None:
        if not items:
            return
        start = len(self.items)
        self.beginInsertRows(QModelIndex(), start, start + len(items) - 1)
        self.items.extend(items)
        for i, it in enumerate(items, start):
            self._rows[it.task_id] = i
        self.endInsertRows()

    def clear_finished(self) -> None:
        self.beginResetModel()
        self.items = [it for it in self.items if it.status not in FINISHED]
        self._rows = {it.task_id: i for i, it in enumerate(self.items)}
        self.endResetModel()

    def item(self, task_id: str) -> QueueItem | None:
        row = self._rows.get(task_id)
        return self.items[row] if row is not None else None

    def row_changed(self, task_id: str) -> None:
        row = self._rows.get(task_id)
        if row is not None:
            self.dataChanged.emit(self.index(row, 0), self.index(row, len(self.COLUMNS) - 1))

    def counts(self) -> dict[QueueStatus, int]:
        out = dict.fromkeys(QueueStatus, 0)
        for it in self.items:
            out[it.status] += 1
        return out


class QueueFilterProxy(QSortFilterProxyModel):
    def __init__(self) -> None:
        super().__init__()
        self.hide_finished = False

    def filterAcceptsRow(self, row: int, parent: QModelIndex) -> bool:  # noqa: N802
        if not self.hide_finished:
            return True
        it: QueueItem = self.sourceModel().items[row]
        return it.status not in FINISHED


class ProgressDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index) -> None:  # noqa: D102
        pct = index.data(Qt.ItemDataRole.UserRole)
        if not isinstance(pct, float | int):
            return super().paint(painter, option, index)
        bar = QStyleOptionProgressBar()
        bar.rect = option.rect.adjusted(2, 2, -2, -2)
        bar.minimum = 0
        bar.maximum = 100
        bar.progress = int(pct)
        bar.text = f"{pct:.0f}%"
        bar.textVisible = True
        bar.state = option.state
        QApplication.style().drawControl(QStyle.ControlElement.CE_ProgressBar, bar, painter)


# --------------------------------------------------------------------------- controller


@dataclass(slots=True)
class Group:
    group_id: str
    title: str
    prefix: str
    total: int
    started: float = field(default_factory=time.monotonic)
    on_item_done: Callable[[QueueItem], None] | None = None
    notified: bool = False


class QueueController(QObject):
    changed = Signal()  # counters / overall progress may have changed
    group_finished = Signal(str, int, int)  # (title, done, errors)

    def __init__(self, state: AppState, model: QueueModel) -> None:
        super().__init__()
        self.state = state
        self.model = model
        self.paused = False
        self.groups: dict[str, Group] = {}
        self._workers: dict[str, workers.Worker] = {}
        self._dirty: set[str] = set()
        self._pool = QThreadPool(self)
        self._pool.setMaxThreadCount(state.settings.parallel_downloads)
        self._flush = QTimer(self)
        self._flush.setInterval(100)
        self._flush.timeout.connect(self._flush_rows)
        self._flush.start()
        state.settings_changed.connect(
            lambda: self._pool.setMaxThreadCount(state.settings.parallel_downloads)
        )

    # ---- adding
    def add_tracks(
        self,
        tracks: list[Track],
        prefix: str,
        fmt: str,
        title: str = "",
        on_item_done: Callable[[QueueItem], None] | None = None,
        start_index: int = 1,
    ) -> str:
        group_id = uuid.uuid4().hex[:8]
        items: list[QueueItem] = []
        for i, t in enumerate(tracks, start_index):
            it = QueueItem(
                task_id=uuid.uuid4().hex,
                track=t,
                prefix=prefix,
                fmt=fmt,
                group=group_id,
                index=i,
            )
            if t.id and self.state.archive.has(t.source, t.id):
                it.status = QueueStatus.SKIPPED
                it.progress = 100.0
            items.append(it)
        self.groups[group_id] = Group(
            group_id, title or prefix or "черга", prefix, len(items), on_item_done=on_item_done
        )
        self.model.add(items)
        log.info("Queued %d track(s) [%s] prefix=%r fmt=%s", len(items), title, prefix, fmt)
        self.changed.emit()
        self._dispatch()
        return group_id

    # ---- control
    def pause(self) -> None:
        self.paused = True
        self.changed.emit()

    def resume(self) -> None:
        self.paused = False
        self.changed.emit()
        self._dispatch()

    def cancel_all(self) -> None:
        self.paused = True
        for it in self.model.items:
            if it.status == QueueStatus.PENDING:
                it.status = QueueStatus.CANCELLED
                it.error = "Скасовано"
                self._dirty.add(it.task_id)
        for w in list(self._workers.values()):
            w.cancel()
        self.changed.emit()

    def retry_failed(self) -> None:
        for it in self.model.items:
            if it.status in (QueueStatus.ERROR, QueueStatus.CANCELLED):
                it.status = QueueStatus.PENDING
                it.progress = 0.0
                it.error = None
                it.speed = it.eta = None
                self._dirty.add(it.task_id)
        self.paused = False
        self.changed.emit()
        self._dispatch()

    @property
    def active(self) -> int:
        return len(self._workers)

    # ---- overall progress text
    def overall_text(self) -> str:
        parts = []
        for g in self.groups.values():
            items = [it for it in self.model.items if it.group == g.group_id]
            if not items:
                continue
            done = sum(1 for it in items if it.status in FINISHED)
            if done == len(items):
                continue
            elapsed = time.monotonic() - g.started
            real_done = sum(1 for it in items if it.status == QueueStatus.DONE)
            eta = ""
            if real_done >= 1 and elapsed > 1:
                remaining = len(items) - done
                eta = f", ~{human_eta(elapsed / real_done * remaining)}"
            parts.append(f"{g.title}: {done} / {len(items)}{eta}")
        return "  ·  ".join(parts) if parts else "Черга порожня або завершена"

    # ---- scheduling
    def _dispatch(self) -> None:
        if self.paused:
            return
        limit = self._pool.maxThreadCount()
        for it in self.model.items:
            if len(self._workers) >= limit:
                break
            if it.status == QueueStatus.PENDING:
                self._start(it)

    def _start(self, it: QueueItem) -> None:
        it.status = QueueStatus.DOWNLOADING
        self._dirty.add(it.task_id)
        dest = self.state.settings.work_path
        template = self.state.settings.filename_template
        url, prefix, fmt, task_id = it.track.url, it.prefix, it.fmt, it.task_id

        def task(ctx):
            return downloader.download_track(
                url,
                dest,
                prefix=prefix,
                fmt=fmt,
                filename_template=template,
                progress=lambda p: ctx.progress(task_id=task_id, **p),
                is_cancelled=ctx.is_cancelled,
                log_fn=ctx.log,
            )

        w = workers.Worker(task)
        w.signals.progress.connect(self._on_progress)
        w.signals.finished.connect(lambda res, tid=task_id: self._on_finished(tid, res))
        w.signals.error.connect(lambda m, tb, tid=task_id: self._on_error(tid, m))
        w.signals.done.connect(lambda tid=task_id: self._on_done(tid))
        self._workers[task_id] = w
        workers.start(w, self._pool)

    def _on_progress(self, p: dict) -> None:
        it = self.model.item(p.get("task_id", ""))
        if it is None:
            return
        if p.get("phase") == "postprocess":
            it.progress = 100.0
            it.speed = None
            it.eta = None
        else:
            total = p.get("total_bytes") or p.get("total_bytes_estimate")
            done = p.get("downloaded_bytes") or 0
            it.downloaded_bytes = int(done)
            if total:
                it.total_bytes = int(total)
                it.progress = min(100.0, 100.0 * done / total)
            if p.get("status") == "finished":
                it.progress = 100.0
            it.speed = p.get("speed")
            it.eta = p.get("eta")
        if p.get("filename"):
            it.filename = Path(p["filename"]).name
        self._dirty.add(it.task_id)

    def _on_finished(self, task_id: str, res: downloader.DownloadResult) -> None:
        it = self.model.item(task_id)
        if it is None:
            return
        if res.ok:
            it.status = QueueStatus.DONE
            it.progress = 100.0
            it.filename = res.path.name if res.path else it.filename
            source = res.source or it.track.source
            track_id = res.track_id or it.track.id
            if track_id:
                self.state.archive.add(source, track_id, res.path, it.track.title)
        elif res.cancelled:
            it.status = QueueStatus.CANCELLED
            it.error = "Скасовано"
        else:
            it.status = QueueStatus.ERROR
            it.error = res.error or "невідома помилка"
        it.speed = it.eta = None
        self._dirty.add(task_id)
        g = self.groups.get(it.group)
        if g and g.on_item_done and it.status == QueueStatus.DONE:
            try:
                g.on_item_done(it)
            except Exception as exc:  # noqa: BLE001
                log.error("on_item_done failed: %s", exc)

    def _on_error(self, task_id: str, msg: str) -> None:
        it = self.model.item(task_id)
        if it is None:
            return
        it.status = QueueStatus.ERROR
        it.error = msg
        it.speed = it.eta = None
        self._dirty.add(task_id)

    def _on_done(self, task_id: str) -> None:
        self._workers.pop(task_id, None)
        self._check_groups()
        self.changed.emit()
        self._dispatch()
        if not self._workers:
            self.state.files_changed.emit()

    def _check_groups(self) -> None:
        for g in self.groups.values():
            if g.notified:
                continue
            items = [it for it in self.model.items if it.group == g.group_id]
            if items and all(it.status in FINISHED for it in items):
                g.notified = True
                done = sum(1 for it in items if it.status == QueueStatus.DONE)
                errors = sum(1 for it in items if it.status == QueueStatus.ERROR)
                log.info("Group %s finished: %d done, %d errors", g.title, done, errors)
                self.group_finished.emit(g.title, done, errors)

    def _flush_rows(self) -> None:
        if not self._dirty:
            return
        dirty, self._dirty = self._dirty, set()
        for tid in dirty:
            self.model.row_changed(tid)
        self.changed.emit()
