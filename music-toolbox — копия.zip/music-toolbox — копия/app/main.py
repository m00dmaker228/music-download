"""Entry point: `python -m app.main` or the `music-toolbox` script."""

from __future__ import annotations

import logging
import sys

from app.core import logsetup, paths


def main() -> int:
    logsetup.setup()
    log = logging.getLogger("app")
    log.info(
        "Starting %s; data=%s config=%s",
        paths.APP_DISPLAY_NAME,
        paths.data_dir(),
        paths.config_dir(),
    )

    # Qt is imported here so `app.core` stays importable without PySide6.
    from PySide6.QtCore import QCoreApplication
    from PySide6.QtWidgets import QApplication

    from app.ui import logbus
    from app.ui.main_window import MainWindow
    from app.ui.state import AppState

    QCoreApplication.setOrganizationName("MusicToolbox")
    QCoreApplication.setApplicationName(paths.APP_NAME)
    app = QApplication(sys.argv)
    logbus.install()

    state = AppState()
    window = MainWindow(state)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
