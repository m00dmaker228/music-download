"""SQLite archive of downloaded tracks keyed by (source, track id).

Used to skip tracks that were already downloaded on a previous run.
"""

from __future__ import annotations

import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from . import paths

_SCHEMA = """
CREATE TABLE IF NOT EXISTS downloaded (
    source TEXT NOT NULL,
    track_id TEXT NOT NULL,
    path TEXT,
    title TEXT,
    downloaded_at TEXT NOT NULL,
    PRIMARY KEY (source, track_id)
);
"""


class Archive:
    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or paths.db_file()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def has(self, source: str, track_id: str) -> bool:
        cur = self._conn.execute(
            "SELECT 1 FROM downloaded WHERE source=? AND track_id=?", (source, track_id)
        )
        return cur.fetchone() is not None

    def add(self, source: str, track_id: str, path: Path | None = None, title: str = "") -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO downloaded(source, track_id, path, title, downloaded_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (source, track_id, str(path) if path else None, title, datetime.now(UTC).isoformat()),
        )
        self._conn.commit()

    def remove(self, source: str, track_id: str) -> None:
        self._conn.execute(
            "DELETE FROM downloaded WHERE source=? AND track_id=?", (source, track_id)
        )
        self._conn.commit()

    def count(self) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM downloaded").fetchone()[0]

    def __enter__(self) -> Archive:
        return self

    def __exit__(self, *exc) -> None:
        self.close()
