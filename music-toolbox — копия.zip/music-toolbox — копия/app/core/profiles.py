"""CRUD for saved playlist profiles (profiles.json)."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from . import jsonstore, paths
from .models import Profile


def load(path: Path | None = None) -> list[Profile]:
    return jsonstore.load_list(path or paths.profiles_file(), Profile)


def save(profiles: list[Profile], path: Path | None = None) -> Path:
    return jsonstore.save_list(path or paths.profiles_file(), profiles)


def add(profiles: list[Profile], profile: Profile) -> list[Profile]:
    if any(p.name == profile.name for p in profiles):
        raise ValueError(f"профіль «{profile.name}» уже існує")
    profiles.append(profile)
    return profiles


def update(profiles: list[Profile], old_name: str, profile: Profile) -> list[Profile]:
    for i, p in enumerate(profiles):
        if p.name == old_name:
            if profile.name != old_name and any(q.name == profile.name for q in profiles):
                raise ValueError(f"профіль «{profile.name}» уже існує")
            profiles[i] = profile
            return profiles
    raise KeyError(old_name)


def remove(profiles: list[Profile], name: str) -> list[Profile]:
    profiles[:] = [p for p in profiles if p.name != name]
    return profiles


def mark_run(profile: Profile, last_index: int | None = None) -> Profile:
    profile.last_run = datetime.now(UTC).isoformat(timespec="seconds")
    if last_index is not None:
        profile.last_index = max(profile.last_index, last_index)
    return profile
