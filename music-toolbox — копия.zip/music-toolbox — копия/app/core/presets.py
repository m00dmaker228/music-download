"""CRUD for processing presets (presets.json): operation + parameters under a name."""

from __future__ import annotations

from pathlib import Path

from . import jsonstore, paths
from .models import Preset

BUILTIN: list[Preset] = [
    Preset("Nightcore (1.25)", "speed", {"factor": 1.25}),
    Preset("Slowed (0.85)", "speed", {"factor": 0.85}),
    Preset("Slowed + reverb", "slowed_reverb", {"factor": 0.85, "reverb": 0.5}),
    Preset("Нормалізація −14 LUFS", "normalize", {"lufs": -14.0}),
    Preset("MP3 320", "convert", {"fmt": "mp3_320"}),
]


def load(path: Path | None = None) -> list[Preset]:
    items = jsonstore.load_list(path or paths.presets_file(), Preset)
    return items if items else [Preset(p.name, p.operation, dict(p.params)) for p in BUILTIN]


def save(presets: list[Preset], path: Path | None = None) -> Path:
    return jsonstore.save_list(path or paths.presets_file(), presets)


def upsert(presets: list[Preset], preset: Preset) -> list[Preset]:
    for i, p in enumerate(presets):
        if p.name == preset.name:
            presets[i] = preset
            return presets
    presets.append(preset)
    return presets


def remove(presets: list[Preset], name: str) -> list[Preset]:
    presets[:] = [p for p in presets if p.name != name]
    return presets
