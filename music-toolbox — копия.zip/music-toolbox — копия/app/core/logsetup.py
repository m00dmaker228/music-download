"""Application-wide logging: rotating file in the data dir + optional extra handlers."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from . import paths

FORMAT = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"
DATEFMT = "%Y-%m-%d %H:%M:%S"


def setup(level: int = logging.INFO) -> logging.Logger:
    """Configure the root logger once. Safe to call repeatedly."""
    root = logging.getLogger()
    if getattr(root, "_mtb_configured", False):
        return root
    root.setLevel(level)
    paths.ensure_dirs()
    fh = RotatingFileHandler(
        paths.log_file(), maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    fh.setFormatter(logging.Formatter(FORMAT, DATEFMT))
    root.addHandler(fh)
    root._mtb_configured = True  # type: ignore[attr-defined]
    return root
