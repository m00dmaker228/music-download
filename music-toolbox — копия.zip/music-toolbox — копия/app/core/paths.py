"""Filesystem locations used by the application.

All locations are functions (not module constants) so tests and the
`MUSIC_TOOLBOX_DATA_DIR` / `MUSIC_TOOLBOX_CONFIG_DIR` environment variables
can redirect them without reloading modules.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "MusicToolbox"
APP_DISPLAY_NAME = "Music Toolbox"
IS_WINDOWS = sys.platform == "win32"


def app_root() -> Path:
    """Directory of the executable (frozen) or the project root (source run)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def data_dir() -> Path:
    """Per-user data: binaries, SQLite database, logs."""
    override = os.environ.get("MUSIC_TOOLBOX_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / APP_NAME
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".local" / "share"
    return base / APP_NAME


def config_dir() -> Path:
    """Per-user config: settings.json, profiles.json, presets.json."""
    override = os.environ.get("MUSIC_TOOLBOX_CONFIG_DIR")
    if override:
        return Path(override).expanduser()
    if IS_WINDOWS:
        return data_dir()
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / APP_NAME


def bin_dir() -> Path:
    return data_dir() / "bin"


def log_dir() -> Path:
    return data_dir() / "logs"


def log_file() -> Path:
    return log_dir() / "music-toolbox.log"


def settings_file() -> Path:
    return config_dir() / "settings.json"


def profiles_file() -> Path:
    return config_dir() / "profiles.json"


def presets_file() -> Path:
    return config_dir() / "presets.json"


def db_file() -> Path:
    return data_dir() / "library.sqlite3"


def default_work_dir() -> Path:
    """Default working folder with downloaded tracks: ~/Music/soundcloud."""
    return Path.home() / "Music" / "soundcloud"


def ensure_dirs() -> None:
    for d in (data_dir(), config_dir(), bin_dir(), log_dir()):
        d.mkdir(parents=True, exist_ok=True)
