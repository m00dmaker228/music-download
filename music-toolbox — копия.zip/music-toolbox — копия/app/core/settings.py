"""settings.json read/write."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, fields
from pathlib import Path

from . import paths

log = logging.getLogger(__name__)

RESULT_STRATEGIES = ("new_file", "replace_with_backup")
DEFAULT_FORMATS = ("original", "mp3_320", "m4a", "opus")


@dataclass(slots=True)
class Settings:
    work_dir: str = ""
    backup_dir: str = ""
    result_strategy: str = "new_file"
    parallel_downloads: int = 2
    filename_template: str = "{prefix}{title}.{ext}"
    default_format: str = "original"
    recursive_scan: bool = False
    tag_template: str = "{prefix}{artist} - {title}"

    def __post_init__(self) -> None:
        if not self.work_dir:
            self.work_dir = str(paths.default_work_dir())
        if not self.backup_dir:
            self.backup_dir = str(Path(self.work_dir) / "_backup")
        if self.result_strategy not in RESULT_STRATEGIES:
            self.result_strategy = "new_file"
        if self.default_format not in DEFAULT_FORMATS:
            self.default_format = "original"
        self.parallel_downloads = max(1, min(4, int(self.parallel_downloads)))

    @property
    def work_path(self) -> Path:
        return Path(self.work_dir)

    @property
    def backup_path(self) -> Path:
        return Path(self.backup_dir)


def load(path: Path | None = None) -> Settings:
    """Load settings; unknown keys are ignored, missing keys get defaults."""
    path = path or paths.settings_file()
    if not path.is_file():
        return Settings()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log.warning("Cannot read %s: %s — using defaults", path, exc)
        return Settings()
    known = {f.name for f in fields(Settings)}
    clean = {k: v for k, v in data.items() if k in known}
    try:
        return Settings(**clean)
    except (TypeError, ValueError) as exc:
        log.warning("Invalid settings in %s: %s — using defaults", path, exc)
        return Settings()


def save(settings: Settings, path: Path | None = None) -> Path:
    path = path or paths.settings_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(asdict(settings), ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return path
