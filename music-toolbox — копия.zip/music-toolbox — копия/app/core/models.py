"""Plain dataclasses shared between core and UI. No Qt here."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path


@dataclass(slots=True)
class OpResult:
    """Result of a single file operation (tags / process)."""

    path: Path
    ok: bool
    output_path: Path | None = None
    error: str | None = None


@dataclass(slots=True)
class BinaryStatus:
    """Where an external binary was found and which version it reports."""

    name: str
    path: Path | None
    version: str | None

    @property
    def available(self) -> bool:
        return self.path is not None


class QueueStatus(StrEnum):
    PENDING = "pending"
    DOWNLOADING = "downloading"
    DONE = "done"
    ERROR = "error"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


@dataclass(slots=True)
class Track:
    """A track known from a playlist listing or search result."""

    source: str  # "soundcloud", "youtube", ...
    id: str
    title: str
    url: str
    uploader: str = ""
    duration: float | None = None  # seconds


@dataclass(slots=True)
class QueueItem:
    """One row of the download queue."""

    task_id: str
    track: Track
    prefix: str
    fmt: str  # "original" | "mp3_320" | "m4a" | "opus"
    status: QueueStatus = QueueStatus.PENDING
    progress: float = 0.0  # 0..100
    speed: float | None = None  # bytes/s
    eta: int | None = None  # seconds
    total_bytes: int | None = None
    downloaded_bytes: int = 0
    filename: str | None = None
    error: str | None = None
    group: str = ""  # playlist / batch this item belongs to
    index: int = 0  # 1-based position inside the playlist (0 = unknown)


@dataclass(slots=True)
class Profile:
    """Saved playlist profile (replaces the PLAYLISTS list in legacy scripts)."""

    name: str
    url: str
    prefix: str
    active: bool = True
    last_index: int = 0
    last_run: str | None = None  # ISO timestamp


@dataclass(slots=True)
class Preset:
    """Saved processing operation with parameters."""

    name: str
    operation: str
    params: dict = field(default_factory=dict)
