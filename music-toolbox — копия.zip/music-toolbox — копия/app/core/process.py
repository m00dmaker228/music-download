"""ffmpeg processing operations, one function per UI button.

Contract: `fn(paths, **params, progress=None, is_cancelled=None, policy=None) -> list[OpResult]`.
`progress(i, n, path, percent=...)` is called with the per-file percentage while
ffmpeg runs (`-progress pipe:1 -nostats`), then once more when the file is done.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from . import binaries
from .models import OpResult

log = logging.getLogger(__name__)

ProgressFn = Callable[..., None]
CancelFn = Callable[[], bool]

OPERATIONS = (
    "tempo",
    "pitch",
    "speed",
    "slowed_reverb",
    "cut",
    "fade",
    "normalize",
    "convert",
    "concat",
    "silence_remove",
)

CONVERT_FORMATS = ("mp3_128", "mp3_192", "mp3_320", "m4a", "opus", "flac", "wav")

_TIME_RE = re.compile(r"^(?:(\d+):)?(\d{1,2}):(\d{1,2})(?:[.,](\d{1,3}))?$")


class ProcessCancelled(Exception):
    pass


@dataclass(slots=True)
class OutputPolicy:
    """Where the result goes: a new file with a suffix, or in place with a backup."""

    strategy: str = "new_file"  # "new_file" | "replace_with_backup"
    backup_dir: Path | None = None

    def target(self, src: Path, suffix: str, ext: str | None = None) -> Path:
        ext = ext or src.suffix
        if self.strategy == "replace_with_backup" and ext == src.suffix:
            return src
        candidate = src.with_name(f"{src.stem}{suffix}{ext}")
        n = 2
        while candidate.exists():
            candidate = src.with_name(f"{src.stem}{suffix}_{n}{ext}")
            n += 1
        return candidate


# --------------------------------------------------------------------------- helpers


def parse_time(text: str | float | int | None) -> float | None:
    """'1:23.5' / '01:02:03' / '75' / 75.0 → seconds; None/'' → None."""
    if text is None:
        return None
    if isinstance(text, int | float):
        return float(text)
    s = str(text).strip()
    if not s:
        return None
    m = _TIME_RE.match(s)
    if m:
        h, mi, sec, frac = m.groups()
        total = int(h or 0) * 3600 + int(mi) * 60 + int(sec)
        if frac:
            total += int(frac.ljust(3, "0")) / 1000
        return float(total)
    try:
        return float(s.replace(",", "."))
    except ValueError as exc:
        raise ValueError(f"невірний формат часу: {text}") from exc


def format_time(seconds: float) -> str:
    m, s = divmod(max(0.0, seconds), 60)
    return f"{int(m):02d}:{s:06.3f}"


def _ffmpeg() -> Path:
    exe = binaries.find("ffmpeg")
    if exe is None:
        raise FileNotFoundError("ffmpeg не знайдено. Встановіть його у вкладці «Налаштування».")
    return exe


def duration_of(path: Path) -> float | None:
    exe = binaries.find("ffprobe")
    if exe is None:
        return None
    cp = binaries.run(
        [
            exe,
            "-v",
            "error",
            "-show_entries",
            "format=duration:stream=sample_rate",
            "-of",
            "json",
            path,
        ],
        timeout=60,
    )
    try:
        data = json.loads(cp.stdout or "{}")
        return float(data["format"]["duration"])
    except (KeyError, ValueError, TypeError):
        return None


def sample_rate_of(path: Path) -> int:
    exe = binaries.find("ffprobe")
    if exe is None:
        return 44100
    cp = binaries.run(
        [
            exe,
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=sample_rate",
            "-of",
            "json",
            path,
        ],
        timeout=60,
    )
    try:
        return int(json.loads(cp.stdout)["streams"][0]["sample_rate"])
    except (KeyError, IndexError, ValueError, TypeError):
        return 44100


_filters_cache: dict[Path, set[str]] = {}


def available_filters() -> set[str]:
    exe = _ffmpeg()
    if exe in _filters_cache:
        return _filters_cache[exe]
    cp = binaries.run([exe, "-hide_banner", "-filters"], timeout=60)
    names: set[str] = set()
    for ln in (cp.stdout or "").splitlines():
        parts = ln.split()
        if len(parts) >= 2 and parts[0] and all(c in "TSC." for c in parts[0]):
            names.add(parts[1])
    _filters_cache[exe] = names
    return names


def codec_args(ext: str, bitrate_k: int | None = None) -> list[str]:
    """Encoder arguments for an output extension."""
    ext = ext.lower().lstrip(".")
    if ext == "mp3":
        return ["-c:a", "libmp3lame", "-b:a", f"{bitrate_k or 320}k"]
    if ext in ("m4a", "mp4", "aac"):
        return ["-c:a", "aac", "-b:a", f"{bitrate_k or 256}k"]
    if ext == "opus":
        return ["-c:a", "libopus", "-b:a", f"{bitrate_k or 160}k", "-vbr", "on"]
    if ext in ("ogg", "oga"):
        return ["-c:a", "libvorbis", "-q:a", "6"]
    if ext == "flac":
        return ["-c:a", "flac"]
    if ext in ("wav", "aiff", "aif"):
        return ["-c:a", "pcm_s16le"]
    return []


def _run_ffmpeg(
    args: list,
    out_duration: float | None,
    on_percent: Callable[[float], None] | None,
    is_cancelled: CancelFn | None,
) -> str:
    """Run ffmpeg with `-progress pipe:1`; return full text output; raise on failure."""
    full = [
        _ffmpeg(),
        "-y",
        "-hide_banner",
        "-nostdin",
        "-loglevel",
        "error",
        "-progress",
        "pipe:1",
        "-nostats",
        *args,
    ]
    proc = binaries.popen(full)
    lines: list[str] = []
    last = [0.0]

    def on_line(line: str) -> None:
        if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
            if out_duration and on_percent:
                try:
                    us = int(line.split("=", 1)[1])
                except ValueError:
                    return
                pct = max(0.0, min(100.0, us / 1_000_000 / out_duration * 100))
                now = time.monotonic()
                if now - last[0] >= 0.1 or pct >= 100:
                    last[0] = now
                    on_percent(pct)
            return
        if "=" in line and line.split("=", 1)[0] in (
            "frame",
            "fps",
            "stream_0_0_q",
            "bitrate",
            "total_size",
            "out_time",
            "dup_frames",
            "drop_frames",
            "speed",
            "progress",
        ):
            return
        lines.append(line)

    code = binaries.stream_lines(proc, on_line, is_cancelled)
    text = "\n".join(lines)
    if is_cancelled and is_cancelled():
        raise ProcessCancelled()
    if code != 0:
        raise RuntimeError(f"ffmpeg завершився з кодом {code}: {text.strip()[-1500:]}")
    return text


def _finalize(src: Path, tmp: Path, policy: OutputPolicy, target: Path) -> Path:
    """Move the temp result into place; back up the original when replacing."""
    if target == src:
        backup_dir = policy.backup_dir or src.parent / "_backup"
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup = backup_dir / src.name
        n = 2
        while backup.exists():
            backup = backup_dir / f"{src.stem}_{n}{src.suffix}"
            n += 1
        shutil.copy2(src, backup)
        log.info("Backup: %s -> %s", src, backup)
    os.replace(tmp, target)
    return target


def _batch(
    paths: list[Path],
    suffix: str,
    build: Callable[[Path, Path], tuple[list, float | None]],
    progress: ProgressFn | None,
    is_cancelled: CancelFn | None,
    policy: OutputPolicy | None,
    ext: str | None = None,
) -> list[OpResult]:
    """Shared driver: for each file, `build(src, tmp)` returns (ffmpeg args, expected duration)."""
    policy = policy or OutputPolicy()
    results: list[OpResult] = []
    total = len(paths)
    for i, src in enumerate(paths, 1):
        if is_cancelled and is_cancelled():
            results.append(OpResult(src, False, None, "Скасовано"))
            continue
        out_ext = ext or src.suffix
        target = policy.target(src, suffix, out_ext)
        tmp = src.with_name(f"{src.stem}.mtbtmp{out_ext}")
        try:
            args, expected = build(src, tmp)

            def pct(p: float, i=i, src=src) -> None:
                if progress:
                    progress(i, total, src, percent=p)

            _run_ffmpeg(args, expected, pct, is_cancelled)
            if not tmp.is_file() or tmp.stat().st_size == 0:
                raise RuntimeError("ffmpeg не створив вихідний файл")
            out = _finalize(src, tmp, policy, target)
            results.append(OpResult(src, True, out))
            log.info("%s -> %s", src.name, out.name)
        except ProcessCancelled:
            tmp.unlink(missing_ok=True)
            results.append(OpResult(src, False, None, "Скасовано"))
        except Exception as exc:  # noqa: BLE001 — reported per file
            tmp.unlink(missing_ok=True)
            log.error("%s: %s", src.name, exc)
            results.append(OpResult(src, False, None, str(exc)))
        if progress:
            progress(i, total, src, percent=100.0)
    return results


def _atempo_chain(factor: float) -> str:
    """atempo only accepts 0.5–100 (older builds 0.5–2.0); chain for safety."""
    parts: list[str] = []
    f = factor
    while f < 0.5:
        parts.append("atempo=0.5")
        f /= 0.5
    while f > 2.0:
        parts.append("atempo=2.0")
        f /= 2.0
    parts.append(f"atempo={f:.6f}")
    return ",".join(parts)


def _suffix_num(x: float) -> str:
    s = f"{x:.3f}".rstrip("0").rstrip(".")
    return s.replace("-", "m")


# --------------------------------------------------------------------------- operations


def tempo(
    paths: list[Path],
    factor: float = 1.0,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Change tempo, keep pitch (atempo). factor 0.25–4.0."""
    if not 0.25 <= factor <= 4.0:
        raise ValueError("множник темпу має бути в межах 0.25–4.0")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        args = ["-i", src, "-af", _atempo_chain(factor), *codec_args(src.suffix), tmp]
        return args, (dur / factor if dur else None)

    return _batch(paths, f"_tempo{_suffix_num(factor)}", build, progress, is_cancelled, policy)


def pitch(
    paths: list[Path],
    semitones: float = 0.0,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Shift pitch, keep tempo: rubberband when available, else asetrate+atempo."""
    if not -24 <= semitones <= 24:
        raise ValueError("півтони мають бути в межах −24…+24")
    ratio = 2 ** (semitones / 12)
    use_rb = "rubberband" in available_filters()

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        if use_rb:
            af = f"rubberband=pitch={ratio:.6f}:tempo=1"
        else:
            sr = sample_rate_of(src)
            af = f"asetrate={sr * ratio:.0f},aresample={sr},{_atempo_chain(1 / ratio)}"
        return ["-i", src, "-af", af, *codec_args(src.suffix), tmp], dur

    return _batch(paths, f"_pitch{_suffix_num(semitones)}", build, progress, is_cancelled, policy)


def speed(
    paths: list[Path],
    factor: float = 1.25,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Speed and pitch together (asetrate+aresample). Nightcore 1.25, Slowed 0.85."""
    if not 0.25 <= factor <= 4.0:
        raise ValueError("множник швидкості має бути в межах 0.25–4.0")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        sr = sample_rate_of(src)
        af = f"asetrate={sr * factor:.0f},aresample={sr}"
        return ["-i", src, "-af", af, *codec_args(src.suffix), tmp], (dur / factor if dur else None)

    return _batch(paths, f"_x{_suffix_num(factor)}", build, progress, is_cancelled, policy)


def slowed_reverb(
    paths: list[Path],
    factor: float = 0.85,
    reverb: float = 0.5,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Slow down (asetrate) and add room reverb (aecho). reverb 0–1."""
    if not 0.25 <= factor <= 2.0:
        raise ValueError("множник має бути в межах 0.25–2.0")
    reverb = max(0.0, min(1.0, reverb))
    d1, d2 = 0.3 + 0.5 * reverb, 0.2 + 0.4 * reverb

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        sr = sample_rate_of(src)
        af = f"asetrate={sr * factor:.0f},aresample={sr},aecho=0.8:0.88:60|120:{d1:.2f}|{d2:.2f}"
        return ["-i", src, "-af", af, *codec_args(src.suffix), tmp], (dur / factor if dur else None)

    return _batch(
        paths,
        f"_slowed{_suffix_num(factor)}_rv{_suffix_num(reverb)}",
        build,
        progress,
        is_cancelled,
        policy,
    )


def cut(
    paths: list[Path],
    start: str | float | None = None,
    end: str | float | None = None,
    reencode: bool = False,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Trim to [start, end]. Stream copy by default (fast, cuts on frames), or re-encode."""
    s = parse_time(start) or 0.0
    e = parse_time(end)
    if e is not None and e <= s:
        raise ValueError("кінець має бути більшим за початок")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        args = ["-ss", f"{s:.3f}", "-i", src]
        if e is not None:
            args += ["-to", f"{e - s:.3f}"]
        args += codec_args(src.suffix) if reencode else ["-c", "copy"]
        args += [tmp]
        expected = (e if e is not None else dur) - s if (dur or e is not None) else None
        return args, (expected if expected and expected > 0 else None)

    return _batch(paths, "_cut", build, progress, is_cancelled, policy)


def fade(
    paths: list[Path],
    fade_in: float = 0.0,
    fade_out: float = 0.0,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """afade in/out, seconds."""
    if fade_in < 0 or fade_out < 0 or (fade_in == 0 and fade_out == 0):
        raise ValueError("вкажіть тривалість fade in і/або fade out")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        parts = []
        if fade_in > 0:
            parts.append(f"afade=t=in:st=0:d={fade_in}")
        if fade_out > 0:
            if dur is None:
                raise RuntimeError("не вдалося визначити тривалість для fade out")
            parts.append(f"afade=t=out:st={max(0.0, dur - fade_out):.3f}:d={fade_out}")
        return ["-i", src, "-af", ",".join(parts), *codec_args(src.suffix), tmp], dur

    return _batch(paths, "_fade", build, progress, is_cancelled, policy)


def _loudnorm_measure(src: Path, target: float, tp: float, lra: float) -> dict:
    """First loudnorm pass; parse the JSON block ffmpeg prints."""
    cp = binaries.run(
        [
            _ffmpeg(),
            "-hide_banner",
            "-nostdin",
            "-i",
            src,
            "-af",
            f"loudnorm=I={target}:TP={tp}:LRA={lra}:print_format=json",
            "-f",
            "null",
            os.devnull,
        ],
        timeout=3600,
    )
    text = cp.stdout or ""
    start = text.rfind("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        raise RuntimeError(f"loudnorm не повернув вимірювання: {text.strip()[-500:]}")
    return json.loads(text[start : end + 1])


def normalize(
    paths: list[Path],
    lufs: float = -14.0,
    true_peak: float = -1.5,
    lra: float = 11.0,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Two-pass EBU R128 loudness normalisation (loudnorm)."""
    if not -40 <= lufs <= -5:
        raise ValueError("цільова гучність має бути в межах −40…−5 LUFS")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        sr = sample_rate_of(src)
        m = _loudnorm_measure(src, lufs, true_peak, lra)
        af = (
            f"loudnorm=I={lufs}:TP={true_peak}:LRA={lra}"
            f":measured_I={m['input_i']}:measured_TP={m['input_tp']}"
            f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}"
            f":offset={m.get('target_offset', 0)}:linear=true:print_format=summary,"
            f"aresample={sr}"
        )
        return ["-i", src, "-af", af, *codec_args(src.suffix), tmp], dur

    return _batch(paths, f"_norm{_suffix_num(lufs)}", build, progress, is_cancelled, policy)


def convert(
    paths: list[Path],
    fmt: str = "mp3_320",
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Convert to mp3 128/192/320, m4a, opus, flac or wav."""
    if fmt not in CONVERT_FORMATS:
        raise ValueError(f"невідомий формат: {fmt}")
    ext, _, br = fmt.partition("_")
    bitrate = int(br) if br else None

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        return ["-i", src, "-vn", *codec_args(ext, bitrate), tmp], dur

    return _batch(paths, "", build, progress, is_cancelled, policy, ext=f".{ext}")


def concat(
    paths: list[Path],
    output_name: str | None = None,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Join files in the given order into one file (format of the first file)."""
    if len(paths) < 2:
        raise ValueError("для об'єднання потрібно щонайменше два файли")
    first = paths[0]
    ext = first.suffix
    name = output_name or f"{first.stem}_joined"
    target = first.with_name(f"{name}{ext}")
    n = 2
    while target.exists():
        target = first.with_name(f"{name}_{n}{ext}")
        n += 1
    tmp = first.with_name(f"{first.stem}.mtbtmp{ext}")
    total = sum(duration_of(p) or 0 for p in paths) or None
    args: list = []
    for p in paths:
        args += ["-i", p]
    inputs = "".join(f"[{i}:a]" for i in range(len(paths)))
    args += [
        "-filter_complex",
        f"{inputs}concat=n={len(paths)}:v=0:a=1[out]",
        "-map",
        "[out]",
        *codec_args(ext),
        tmp,
    ]
    try:
        _run_ffmpeg(
            args,
            total,
            (lambda p: progress(1, 1, first, percent=p)) if progress else None,
            is_cancelled,
        )
        os.replace(tmp, target)
        log.info("Joined %d files -> %s", len(paths), target.name)
        return [OpResult(p, True, target) for p in paths]
    except ProcessCancelled:
        tmp.unlink(missing_ok=True)
        return [OpResult(p, False, None, "Скасовано") for p in paths]
    except Exception as exc:  # noqa: BLE001
        tmp.unlink(missing_ok=True)
        log.error("concat: %s", exc)
        return [OpResult(p, False, None, str(exc)) for p in paths]
    finally:
        if progress:
            progress(1, 1, first, percent=100.0)


def silence_remove(
    paths: list[Path],
    threshold_db: float = -50.0,
    min_duration: float = 0.5,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    policy: OutputPolicy | None = None,
) -> list[OpResult]:
    """Cut silence at start/end and gaps longer than `min_duration` (silenceremove)."""
    if min_duration <= 0:
        raise ValueError("мінімальна тривалість тиші має бути > 0")

    def build(src: Path, tmp: Path):
        dur = duration_of(src)
        af = (
            f"silenceremove=start_periods=1:start_threshold={threshold_db}dB"
            f":start_duration={min_duration}"
            f":stop_periods=-1:stop_threshold={threshold_db}dB:stop_duration={min_duration}"
        )
        return ["-i", src, "-af", af, *codec_args(src.suffix), tmp], dur

    return _batch(paths, "_nosilence", build, progress, is_cancelled, policy)


FUNCTIONS: dict[str, Callable[..., list[OpResult]]] = {
    "tempo": tempo,
    "pitch": pitch,
    "speed": speed,
    "slowed_reverb": slowed_reverb,
    "cut": cut,
    "fade": fade,
    "normalize": normalize,
    "convert": convert,
    "concat": concat,
    "silence_remove": silence_remove,
}

__all__ = [*OPERATIONS, "FUNCTIONS", "OutputPolicy", "parse_time", "format_time"]
