"""Tag operations, one function per UI button.

Contract: `fn(paths: list[Path], **params, progress=None) -> list[OpResult]`.
mutagen does the reading/writing; strip goes through ffmpeg first (per spec) and
falls back to mutagen whenever ffmpeg fails or leaves anything behind.
"""

from __future__ import annotations

import base64
import logging
import os
import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import mutagen
from mutagen.flac import FLAC, Picture
from mutagen.id3 import APIC, ID3, TALB, TIT2, TPE1
from mutagen.mp4 import MP4, MP4Cover
from mutagen.oggflac import OggFLAC
from mutagen.oggopus import OggOpus
from mutagen.oggvorbis import OggVorbis

from . import binaries
from .models import OpResult

log = logging.getLogger(__name__)

ProgressFn = Callable[[int, int, Path], None]

SUPPORTED_EXTS = {
    ".mp3",
    ".m4a",
    ".mp4",
    ".aac",
    ".flac",
    ".ogg",
    ".oga",
    ".opus",
    ".wav",
    ".aiff",
    ".aif",
}
_ID3_KEYS = {"title": TIT2, "artist": TPE1, "album": TALB}
_ID3_FRAMES = {"title": "TIT2", "artist": "TPE1", "album": "TALB"}
_MP4_KEYS = {"title": "\xa9nam", "artist": "\xa9ART", "album": "\xa9alb"}
_VORBIS = (FLAC, OggVorbis, OggOpus, OggFLAC)


@dataclass(slots=True)
class BasicTags:
    title: str = ""
    artist: str = ""
    album: str = ""
    has_cover: bool = False
    has_any: bool = False


class UnsupportedFile(Exception):
    pass


# --------------------------------------------------------------------------- backend


def _open(path: Path) -> mutagen.FileType:
    try:
        audio = mutagen.File(path)
    except Exception as exc:  # noqa: BLE001 — mutagen raises many types
        raise UnsupportedFile(f"{path.name}: {exc}") from exc
    if audio is None:
        raise UnsupportedFile(f"{path.name}: непідтримуваний формат")
    return audio


def _is_id3(audio) -> bool:
    return isinstance(getattr(audio, "tags", None), ID3) or type(audio).__name__ in (
        "MP3",
        "WAVE",
        "AIFF",
    )


def _ensure_tags(audio) -> None:
    if audio.tags is None:
        try:
            audio.add_tags()
        except Exception as exc:  # noqa: BLE001
            raise UnsupportedFile(f"не вдалося створити теги: {exc}") from exc


def _get(audio, key: str) -> str:
    tags = audio.tags
    if tags is None:
        return ""
    if _is_id3(audio):
        frame = tags.get(_ID3_FRAMES[key])
        return str(frame.text[0]) if frame and frame.text else ""
    if isinstance(audio, MP4):
        vals = tags.get(_MP4_KEYS[key])
        return str(vals[0]) if vals else ""
    if isinstance(audio, _VORBIS):
        vals = tags.get(key)
        return str(vals[0]) if vals else ""
    return ""


def _set(audio, key: str, value: str) -> None:
    _ensure_tags(audio)
    if _is_id3(audio):
        audio.tags.delall(_ID3_FRAMES[key])
        audio.tags.add(_ID3_KEYS[key](encoding=3, text=[value]))
    elif isinstance(audio, MP4):
        audio.tags[_MP4_KEYS[key]] = [value]
    elif isinstance(audio, _VORBIS):
        audio.tags[key] = [value]
    else:
        raise UnsupportedFile("запис тегів не підтримується для цього формату")


def _has_cover(audio) -> bool:
    tags = audio.tags
    if isinstance(audio, FLAC):
        return bool(audio.pictures)
    if tags is None:
        return False
    if _is_id3(audio):
        return any(k.startswith("APIC") for k in tags.keys())
    if isinstance(audio, MP4):
        return bool(tags.get("covr"))
    if isinstance(audio, _VORBIS):
        return bool(tags.get("metadata_block_picture")) or bool(tags.get("coverart"))
    return False


def _remove_cover(audio) -> None:
    tags = audio.tags
    if isinstance(audio, FLAC):
        audio.clear_pictures()
    if tags is None:
        return
    if _is_id3(audio):
        tags.delall("APIC")
    elif isinstance(audio, MP4):
        tags.pop("covr", None)
    elif isinstance(audio, _VORBIS):
        for k in ("metadata_block_picture", "coverart", "coverartmime"):
            if k in tags:
                del tags[k]


def _add_cover(audio, data: bytes, mime: str) -> None:
    _ensure_tags(audio)
    _remove_cover(audio)
    if _is_id3(audio):
        audio.tags.add(APIC(encoding=3, mime=mime, type=3, desc="Cover", data=data))
    elif isinstance(audio, MP4):
        fmt = MP4Cover.FORMAT_PNG if mime == "image/png" else MP4Cover.FORMAT_JPEG
        audio.tags["covr"] = [MP4Cover(data, imageformat=fmt)]
    elif isinstance(audio, _VORBIS):
        pic = Picture()
        pic.data = data
        pic.type = 3
        pic.mime = mime
        if isinstance(audio, FLAC):
            audio.add_picture(pic)
        else:
            audio.tags["metadata_block_picture"] = [base64.b64encode(pic.write()).decode("ascii")]
    else:
        raise UnsupportedFile("обкладинка не підтримується для цього формату")


def _has_any(audio) -> bool:
    if isinstance(audio, FLAC) and audio.pictures:
        return True
    tags = audio.tags
    return tags is not None and len(tags.keys()) > 0


def _delete_all(audio, path: Path) -> None:
    if isinstance(audio, FLAC):
        audio.clear_pictures()
    if audio.tags is not None:
        try:
            audio.delete()
        except Exception:  # noqa: BLE001
            audio.tags.clear()
            audio.save()
            return
    audio.save()


# --------------------------------------------------------------------------- reading


def basic_tags(path: Path) -> BasicTags:
    try:
        audio = _open(path)
    except UnsupportedFile:
        return BasicTags()
    return BasicTags(
        title=_get(audio, "title"),
        artist=_get(audio, "artist"),
        album=_get(audio, "album"),
        has_cover=_has_cover(audio),
        has_any=_has_any(audio),
    )


def read_tags(path: Path) -> list[tuple[str, str]]:
    """All tags as (key, value) strings for the read-only viewer."""
    audio = _open(path)
    rows: list[tuple[str, str]] = []
    if audio.tags is not None:
        for key in audio.tags.keys():
            val = audio.tags[key]
            if str(key).startswith("APIC") or key in ("covr", "metadata_block_picture"):
                rows.append((str(key), "<зображення>"))
                continue
            if isinstance(val, list):
                text = "; ".join(str(v) for v in val)
            elif hasattr(val, "text"):
                text = "; ".join(str(t) for t in val.text)
            else:
                text = str(val)
            rows.append((str(key), text[:500]))
    if isinstance(audio, FLAC) and audio.pictures:
        rows.append(("PICTURE", f"<зображень: {len(audio.pictures)}>"))
    info = audio.info
    rows.append(("@length", f"{getattr(info, 'length', 0):.2f} s"))
    if getattr(info, "bitrate", None):
        rows.append(("@bitrate", f"{info.bitrate // 1000} kbps"))
    if getattr(info, "sample_rate", None):
        rows.append(("@sample_rate", f"{info.sample_rate} Hz"))
    return rows


# --------------------------------------------------------------------------- batch helpers


def _batch(
    paths: list[Path], fn: Callable[[Path], Path | None], progress: ProgressFn | None
) -> list[OpResult]:
    results: list[OpResult] = []
    total = len(paths)
    for i, p in enumerate(paths, 1):
        try:
            out = fn(p)
            results.append(OpResult(p, True, out or p))
        except Exception as exc:  # noqa: BLE001 — reported per file, never swallowed
            log.error("%s: %s", p, exc)
            results.append(OpResult(p, False, None, str(exc)))
        if progress:
            progress(i, total, p)
    return results


def prefix_of(path: Path) -> str:
    """`PH_Artist - Title.mp3` → `PH_`; empty when the name has no underscore."""
    stem = path.stem
    if "_" not in stem:
        return ""
    return stem.split("_", 1)[0] + "_"


def _template_regex(template: str) -> re.Pattern:
    """Build a regex from `{prefix}{artist} - {title}` to parse file stems."""
    pattern = ""
    pos = 0
    for m in re.finditer(r"\{(\w+)\}", template):
        pattern += re.escape(template[pos : m.start()])
        name = m.group(1)
        if name == "prefix":
            pattern += r"(?P<prefix>[^_]*_)?"
        else:
            pattern += rf"(?P<{name}>.+?)"
        pos = m.end()
    pattern += re.escape(template[pos:])
    return re.compile(rf"^{pattern}$")


def parse_name(stem: str, template: str) -> dict[str, str]:
    m = _template_regex(template).match(stem)
    if not m:
        raise ValueError(f"назва «{stem}» не відповідає шаблону «{template}»")
    return {k: (v or "").strip() for k, v in m.groupdict().items()}


# --------------------------------------------------------------------------- operations


def strip_metadata(paths: list[Path], progress: ProgressFn | None = None) -> list[OpResult]:
    """1. Remove every tag and picture. ffmpeg `-map_metadata -1 -c copy`, mutagen fallback."""
    ffmpeg = binaries.find("ffmpeg")

    def one(p: Path) -> Path:
        done = False
        if ffmpeg is not None:
            tmp = p.with_name(f"{p.stem}.mtbtmp{p.suffix}")
            args = [
                ffmpeg,
                "-y",
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                p,
                "-map",
                "0:a",
                "-map_metadata",
                "-1",
                "-map_metadata:s:a",
                "-1",
                "-map_chapters",
                "-1",
                "-c",
                "copy",
                "-fflags",
                "+bitexact",
                "-flags:a",
                "+bitexact",
                tmp,
            ]
            try:
                cp = binaries.run(args, timeout=600)
                if cp.returncode == 0 and tmp.is_file() and tmp.stat().st_size > 0:
                    os.replace(tmp, p)
                    done = True
                else:
                    log.warning("ffmpeg strip failed for %s: %s", p.name, cp.stdout.strip())
            finally:
                tmp.unlink(missing_ok=True)
        try:
            audio = _open(p)
        except UnsupportedFile:
            if done:
                return p
            raise
        if _has_any(audio) or not done:
            _delete_all(audio, p)
            audio = _open(p)
            if _has_any(audio):
                raise RuntimeError(
                    "після очищення залишилися теги: " + ", ".join(audio.tags.keys())
                )
        return p

    return _batch(paths, one, progress)


def set_album_from_prefix(paths: list[Path], progress: ProgressFn | None = None) -> list[OpResult]:
    """2. album = part of the file name up to and including the first `_`."""

    def one(p: Path) -> Path:
        prefix = prefix_of(p)
        if not prefix:
            raise ValueError("у назві файлу немає префікса (частини до «_»)")
        audio = _open(p)
        _set(audio, "album", prefix)
        audio.save()
        return p

    return _batch(paths, one, progress)


def set_title_artist_from_name(
    paths: list[Path],
    template: str = "{prefix}{artist} - {title}",
    progress: ProgressFn | None = None,
) -> list[OpResult]:
    """3. Parse title/artist from the file name with a template and write them."""

    def one(p: Path) -> Path:
        parts = parse_name(p.stem, template)
        audio = _open(p)
        wrote = False
        for key in ("title", "artist", "album"):
            if parts.get(key):
                _set(audio, key, parts[key])
                wrote = True
        if not wrote:
            raise ValueError("шаблон не містить {title}/{artist}")
        audio.save()
        return p

    return _batch(paths, one, progress)


def remove_cover(paths: list[Path], progress: ProgressFn | None = None) -> list[OpResult]:
    """4. Drop embedded pictures, keep text tags."""

    def one(p: Path) -> Path:
        audio = _open(p)
        _remove_cover(audio)
        audio.save()
        return p

    return _batch(paths, one, progress)


def add_cover(paths: list[Path], image: Path, progress: ProgressFn | None = None) -> list[OpResult]:
    """5. Embed `image` (jpg/png) as front cover."""
    data = Path(image).read_bytes()
    mime = "image/png" if data[:8] == b"\x89PNG\r\n\x1a\n" else "image/jpeg"

    def one(p: Path) -> Path:
        audio = _open(p)
        _add_cover(audio, data, mime)
        audio.save()
        return p

    return _batch(paths, one, progress)
