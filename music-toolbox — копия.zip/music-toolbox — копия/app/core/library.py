"""Scan the working folder: ffprobe info + tags, cached in SQLite by (path, mtime, size)."""

from __future__ import annotations

import json
import logging
import sqlite3
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path

from . import binaries, paths, tags

log = logging.getLogger(__name__)

AUDIO_EXTS = tags.SUPPORTED_EXTS
ProgressFn = Callable[[int, int, Path], None]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    path TEXT PRIMARY KEY,
    mtime REAL NOT NULL,
    size INTEGER NOT NULL,
    info TEXT NOT NULL
);
"""


@dataclass(slots=True)
class FileInfo:
    path: str
    name: str
    prefix: str
    duration: float | None
    fmt: str  # container/codec short name, e.g. "mp3", "aac", "opus"
    bitrate: int | None  # kbps
    size: int
    mtime: float
    has_tags: bool
    album: str
    title: str
    artist: str
    has_cover: bool
    sample_rate: int | None = None
    channels: int | None = None

    @property
    def p(self) -> Path:
        return Path(self.path)


def probe(path: Path, timeout: float = 60) -> dict:
    """`ffprobe -print_format json -show_format -show_streams`."""
    exe = binaries.find("ffprobe")
    if exe is None:
        raise FileNotFoundError("ffprobe не знайдено")
    cp = binaries.run(
        [exe, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path],
        timeout=timeout,
    )
    if cp.returncode != 0:
        raise RuntimeError(f"ffprobe: {cp.stdout.strip()[-500:]}")
    return json.loads(cp.stdout or "{}")


def file_info(path: Path, use_ffprobe: bool = True) -> FileInfo:
    st = path.stat()
    duration = bitrate = sample_rate = channels = None
    fmt = path.suffix.lstrip(".").lower()
    if use_ffprobe:
        try:
            data = probe(path)
            f = data.get("format", {})
            audio = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), {})
            if f.get("duration"):
                duration = float(f["duration"])
            elif audio.get("duration"):
                duration = float(audio["duration"])
            br = audio.get("bit_rate") or f.get("bit_rate")
            bitrate = int(int(br) / 1000) if br else None
            fmt = (audio.get("codec_name") or fmt).lower()
            if audio.get("sample_rate"):
                sample_rate = int(audio["sample_rate"])
            if audio.get("channels"):
                channels = int(audio["channels"])
        except (FileNotFoundError, RuntimeError, ValueError) as exc:
            log.warning("ffprobe failed for %s: %s", path.name, exc)
    bt = tags.basic_tags(path)
    return FileInfo(
        path=str(path),
        name=path.name,
        prefix=tags.prefix_of(path),
        duration=duration,
        fmt=fmt,
        bitrate=bitrate,
        size=st.st_size,
        mtime=st.st_mtime,
        has_tags=bt.has_any,
        album=bt.album,
        title=bt.title,
        artist=bt.artist,
        has_cover=bt.has_cover,
        sample_rate=sample_rate,
        channels=channels,
    )


class LibraryCache:
    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or paths.db_file()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def get(self, path: Path) -> FileInfo | None:
        try:
            st = path.stat()
        except OSError:
            return None
        row = self._conn.execute(
            "SELECT info FROM files WHERE path=? AND mtime=? AND size=?",
            (str(path), st.st_mtime, st.st_size),
        ).fetchone()
        if not row:
            return None
        try:
            return FileInfo(**json.loads(row[0]))
        except (TypeError, ValueError):
            return None

    def put(self, info: FileInfo) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO files(path, mtime, size, info) VALUES (?, ?, ?, ?)",
            (info.path, info.mtime, info.size, json.dumps(asdict(info), ensure_ascii=False)),
        )
        self._conn.commit()

    def forget(self, path: Path) -> None:
        self._conn.execute("DELETE FROM files WHERE path=?", (str(path),))
        self._conn.commit()

    def prune(self, existing: set[str]) -> None:
        rows = self._conn.execute("SELECT path FROM files").fetchall()
        gone = [(r[0],) for r in rows if r[0] not in existing]
        if gone:
            self._conn.executemany("DELETE FROM files WHERE path=?", gone)
            self._conn.commit()


def list_audio_files(work_dir: Path, recursive: bool = False) -> list[Path]:
    if not work_dir.is_dir():
        return []
    it = work_dir.rglob("*") if recursive else work_dir.iterdir()
    return sorted(
        (p for p in it if p.is_file() and p.suffix.lower() in AUDIO_EXTS),
        key=lambda p: p.name.lower(),
    )


def scan(
    work_dir: Path,
    recursive: bool = False,
    cache: LibraryCache | None = None,
    progress: ProgressFn | None = None,
    is_cancelled: Callable[[], bool] | None = None,
) -> list[FileInfo]:
    files = list_audio_files(work_dir, recursive)
    out: list[FileInfo] = []
    use_ffprobe = binaries.find("ffprobe") is not None
    for i, p in enumerate(files, 1):
        if is_cancelled and is_cancelled():
            break
        info = cache.get(p) if cache else None
        if info is None:
            try:
                info = file_info(p, use_ffprobe=use_ffprobe)
            except OSError as exc:
                log.warning("Cannot stat %s: %s", p, exc)
                continue
            if cache and use_ffprobe:
                cache.put(info)
        out.append(info)
        if progress:
            progress(i, len(files), p)
    if cache:
        cache.prune({f.path for f in out} | {str(p) for p in files})
    return out
