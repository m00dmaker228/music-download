"""yt-dlp wrapper: playlist listing, single-track download with JSON progress, cancellation.

Queue scheduling (parallelism, pause) lives in the UI layer; this module only
knows how to run one yt-dlp process at a time and report what it does.
"""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from . import binaries
from .models import Track

log = logging.getLogger(__name__)

ProgressFn = Callable[[dict], None]
CancelFn = Callable[[], bool]
LogFn = Callable[[str], None]

# Extra yt-dlp arguments per output format chosen in the UI.
FORMAT_ARGS: dict[str, list[str]] = {
    "original": [],
    "mp3_320": ["-x", "--audio-format", "mp3", "--audio-quality", "320K"],
    "m4a": ["-x", "--audio-format", "m4a"],
    "opus": ["-x", "--audio-format", "opus"],
}

_FILE_MARK = "MTB_FILE="
_TEMPLATE_TOKENS = {
    "{title}": "%(title)s",
    "{ext}": "%(ext)s",
    "{artist}": "%(uploader)s",
    "{id}": "%(id)s",
    "{index}": "%(playlist_index)s",
}
_INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_ALREADY_RE = re.compile(r"^\[download\] (.+?) has already been downloaded")


class DownloadCancelled(Exception):
    pass


@dataclass(slots=True)
class PlaylistInfo:
    title: str
    url: str
    kind: str  # "playlist" | "track"
    entries: list[Track] = field(default_factory=list)


@dataclass(slots=True)
class DownloadResult:
    ok: bool
    path: Path | None = None
    error: str | None = None
    cancelled: bool = False
    source: str = ""
    track_id: str = ""
    output: list[str] = field(default_factory=list)  # full yt-dlp text output


# --------------------------------------------------------------------------- helpers


def sanitize_filename(name: str, replacement: str = "_") -> str:
    """Replace characters that are invalid on Windows/Linux; trim trailing dots/spaces."""
    cleaned = _INVALID.sub(replacement, name).strip().rstrip(". ")
    return cleaned or "untitled"


def output_template(dest_dir: Path, prefix: str, template: str) -> str:
    """Turn `{prefix}{title}.{ext}` into a yt-dlp `-o` template."""
    tpl = template or "{prefix}{title}.{ext}"
    if "{prefix}" not in tpl:
        tpl = "{prefix}" + tpl
    safe_prefix = sanitize_filename(prefix) if prefix.strip() else ""
    out = tpl.replace("%", "%%").replace("{prefix}", safe_prefix.replace("%", "%%"))
    for token, ytdlp_token in _TEMPLATE_TOKENS.items():
        out = out.replace(token, ytdlp_token)
    if "%(ext)s" not in out:
        out += ".%(ext)s"
    return str(dest_dir / out)


def base_args() -> list[str]:
    exe = binaries.find("yt-dlp")
    if exe is None:
        raise FileNotFoundError("yt-dlp не знайдено. Встановіть його у вкладці «Налаштування».")
    args = [str(exe), "--encoding", "utf-8", "--no-colors", "--windows-filenames"]
    ffmpeg = binaries.find("ffmpeg")
    if ffmpeg is not None:
        args += ["--ffmpeg-location", str(ffmpeg.parent)]
    return args


def _source_of(info: dict) -> str:
    key = info.get("ie_key") or info.get("extractor_key") or info.get("extractor") or "unknown"
    key = str(key).lower()
    for known in ("soundcloud", "youtube", "bandcamp", "vimeo"):
        if key.startswith(known):
            return known
    return key


def track_from_info(info: dict) -> Track:
    url = info.get("webpage_url") or info.get("original_url") or info.get("url") or ""
    return Track(
        source=_source_of(info),
        id=str(info.get("id") or url),
        title=str(info.get("title") or info.get("id") or "?"),
        url=str(url),
        uploader=str(info.get("uploader") or info.get("channel") or info.get("artist") or ""),
        duration=float(info["duration"]) if info.get("duration") is not None else None,
    )


# --------------------------------------------------------------------------- listing


def list_playlist(
    url: str,
    items: str | None = None,
    timeout: float = 600,
    log_fn: LogFn | None = None,
) -> PlaylistInfo:
    """`yt-dlp -J --flat-playlist URL` → titles and ids before any download starts.

    `items` is a yt-dlp `--playlist-items` spec such as "5:40".
    """
    args = base_args() + ["-J", "--flat-playlist", "--no-warnings"]
    if items:
        args += ["--playlist-items", items]
    args.append(url)
    cp = binaries.run(args, timeout=timeout)
    text = cp.stdout or ""
    if log_fn:
        for ln in text.splitlines():
            if not ln.startswith("{"):
                log_fn(ln)
    json_line = next((ln for ln in text.splitlines() if ln.startswith("{")), None)
    if cp.returncode != 0 and json_line is None:
        raise RuntimeError(f"yt-dlp завершився з кодом {cp.returncode}:\n{text.strip()[-2000:]}")
    if json_line is None:
        raise RuntimeError(f"yt-dlp не повернув JSON:\n{text.strip()[-2000:]}")
    info = json.loads(json_line)
    if info.get("_type") == "playlist" or "entries" in info:
        entries = [track_from_info(e) for e in info.get("entries") or [] if e]
        return PlaylistInfo(
            title=str(info.get("title") or url),
            url=url,
            kind="playlist",
            entries=entries,
        )
    track = track_from_info(info)
    return PlaylistInfo(title=track.title, url=url, kind="track", entries=[track])


# --------------------------------------------------------------------------- download


def _cleanup_partials(dest_dir: Path, started_at: float) -> list[Path]:
    removed: list[Path] = []
    for pattern in ("*.part", "*.ytdl", "*.part-Frag*", "*.temp.*"):
        for p in dest_dir.glob(pattern):
            try:
                if p.stat().st_mtime >= started_at - 1:
                    p.unlink()
                    removed.append(p)
            except OSError as exc:
                log.warning("Cannot remove %s: %s", p, exc)
    return removed


def download_track(
    url: str,
    dest_dir: Path,
    prefix: str = "",
    fmt: str = "original",
    filename_template: str = "{prefix}{title}.{ext}",
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    log_fn: LogFn | None = None,
) -> DownloadResult:
    """Download one track. Progress payloads are yt-dlp progress dicts plus `phase`.

    No post-processing happens here except the format conversion yt-dlp itself does
    for `fmt` (`-x`). Cancellation kills yt-dlp (and its ffmpeg) and deletes `.part` files.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    if fmt not in FORMAT_ARGS:
        raise ValueError(f"Unknown format: {fmt}")
    args = base_args() + [
        "--newline",
        "--progress-template",
        "download:%(progress)j",
        "--progress-template",
        "postprocess:%(progress)j",
        "--print",
        f"after_move:{_FILE_MARK}%(filepath)s",
        "--no-playlist",
        "-o",
        output_template(dest_dir, prefix, filename_template),
        *FORMAT_ARGS[fmt],
        url,
    ]
    started = time.time()
    result = DownloadResult(ok=False)
    proc = binaries.popen(args)

    def on_line(line: str) -> None:
        result.output.append(line)
        if line.startswith(_FILE_MARK):
            result.path = Path(line[len(_FILE_MARK) :].strip())
            return
        if line.startswith("{"):
            try:
                payload = json.loads(line)
            except ValueError:
                if log_fn:
                    log_fn(line)
                return
            info = payload.get("info_dict") or {}
            if info and not result.track_id:
                result.track_id = str(info.get("id") or "")
                result.source = _source_of(info)
            if progress:
                slim = {k: v for k, v in payload.items() if k != "info_dict"}
                slim["phase"] = "postprocess" if "postprocessor" in payload else "download"
                slim["track_id"] = result.track_id
                progress(slim)
            return
        m = _ALREADY_RE.match(line)
        if m and result.path is None:
            result.path = Path(m.group(1).strip())
        if log_fn:
            log_fn(line)

    code = binaries.stream_lines(proc, on_line, is_cancelled)
    if is_cancelled and is_cancelled():
        removed = _cleanup_partials(dest_dir, started)
        if removed:
            log.info("Removed partial files: %s", [p.name for p in removed])
        result.cancelled = True
        result.error = "Скасовано"
        return result
    if code != 0:
        tail = "\n".join(result.output[-15:])
        result.error = f"yt-dlp завершився з кодом {code}\n{tail}"
        _cleanup_partials(dest_dir, started)
        return result
    if result.path is None or not result.path.exists():
        # Older yt-dlp or a skipped download: fall back to the filename from progress.
        result.error = "yt-dlp не повідомив шлях до файлу"
        return result
    result.ok = True
    return result
