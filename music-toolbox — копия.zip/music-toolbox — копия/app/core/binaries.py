"""Locate, inspect, install and run external binaries: yt-dlp, ffmpeg, ffprobe.

Search order for a binary: user data dir `bin/` → `bin/` next to the executable → PATH.
All subprocess calls go through `popen()` / `run()` so that Windows gets
CREATE_NO_WINDOW and every process uses UTF-8 I/O.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from collections.abc import Callable, Sequence
from pathlib import Path
from urllib.request import Request, urlopen

from . import paths
from .models import BinaryStatus

log = logging.getLogger(__name__)

NAMES = ("yt-dlp", "ffmpeg", "ffprobe")
IS_WINDOWS = sys.platform == "win32"
CREATE_NO_WINDOW = 0x08000000 if IS_WINDOWS else 0

# progress(stage: str, done: int, total: int) — total may be 0 when unknown
ProgressFn = Callable[[str, int, int], None]
CancelFn = Callable[[], bool]

YTDLP_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/" + (
    "yt-dlp.exe" if IS_WINDOWS else "yt-dlp_linux"
)
FFMPEG_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/" + (
    "ffmpeg-master-latest-win64-gpl.zip"
    if IS_WINDOWS
    else "ffmpeg-master-latest-linux64-gpl.tar.xz"
)

_USER_AGENT = "MusicToolbox/0.1 (+https://github.com/)"
_CHUNK = 256 * 1024


class CancelledError(Exception):
    """Raised when an install is cancelled by the caller."""


# --------------------------------------------------------------------------- lookup


def exe_name(name: str) -> str:
    return f"{name}.exe" if IS_WINDOWS else name


def candidates(name: str) -> list[Path]:
    exe = exe_name(name)
    return [paths.bin_dir() / exe, paths.app_root() / "bin" / exe]


def find(name: str) -> Path | None:
    if name not in NAMES:
        raise ValueError(f"Unknown binary: {name}")
    for cand in candidates(name):
        if cand.is_file():
            return cand
    found = shutil.which(name)
    return Path(found) if found else None


# --------------------------------------------------------------------------- subprocess


def popen_kwargs() -> dict:
    """Common kwargs so every child process is windowless and talks UTF-8."""
    env = dict(os.environ)
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    kwargs: dict = {
        "stdout": subprocess.PIPE,
        "stderr": subprocess.STDOUT,
        "stdin": subprocess.DEVNULL,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
        "env": env,
    }
    if IS_WINDOWS:
        kwargs["creationflags"] = CREATE_NO_WINDOW
    else:
        # Own process group so kill_tree() can take down ffmpeg children of yt-dlp.
        kwargs["start_new_session"] = True
    return kwargs


def kill_tree(proc: subprocess.Popen) -> None:
    """Kill a process started by popen() together with its children."""
    if proc.poll() is not None:
        return
    try:
        if IS_WINDOWS:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                capture_output=True,
                creationflags=CREATE_NO_WINDOW,
                check=False,
            )
        else:
            import signal

            os.killpg(proc.pid, signal.SIGKILL)
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("kill_tree(%s) failed: %s", proc.pid, exc)
    try:
        proc.kill()
    except OSError:
        pass
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        log.warning("Process %s did not exit after kill", proc.pid)


def stream_lines(
    proc: subprocess.Popen,
    on_line: Callable[[str], None],
    is_cancelled: CancelFn | None = None,
    poll_interval: float = 0.2,
) -> int:
    """Feed every stdout line to `on_line`; kill the process if `is_cancelled()` turns true.

    Reading happens on a helper thread so a silent child (e.g. ffmpeg muxing)
    never blocks cancellation. Returns the exit code.
    """
    import queue
    import threading

    q: queue.Queue[str | None] = queue.Queue()

    def reader() -> None:
        try:
            for line in proc.stdout:  # type: ignore[union-attr]
                q.put(line.rstrip("\r\n"))
        finally:
            q.put(None)

    threading.Thread(target=reader, daemon=True).start()
    cancelled = False
    while True:
        try:
            line = q.get(timeout=poll_interval)
        except queue.Empty:
            if is_cancelled and is_cancelled() and not cancelled:
                cancelled = True
                kill_tree(proc)
            continue
        if line is None:
            break
        on_line(line)
        if is_cancelled and is_cancelled() and not cancelled:
            cancelled = True
            kill_tree(proc)
    return proc.wait()


def format_command(args: Sequence[str | Path]) -> str:
    return subprocess.list2cmdline([str(a) for a in args])


def popen(args: Sequence[str | Path], **overrides) -> subprocess.Popen:
    """Start a process; the full command line is logged before launch."""
    cmd = [str(a) for a in args]
    log.info("RUN %s", format_command(cmd))
    kwargs = popen_kwargs()
    kwargs.update(overrides)
    return subprocess.Popen(cmd, **kwargs)


def run(args: Sequence[str | Path], timeout: float | None = 60) -> subprocess.CompletedProcess:
    """Run to completion and capture stdout (stderr merged)."""
    cmd = [str(a) for a in args]
    log.info("RUN %s", format_command(cmd))
    kwargs = popen_kwargs()  # stderr is merged into stdout, same as popen()
    return subprocess.run(cmd, timeout=timeout, check=False, **kwargs)


# --------------------------------------------------------------------------- version


_FF_VERSION_RE = re.compile(r"version\s+(\S+)")


def parse_version(name: str, output: str) -> str | None:
    """Extract a version string from `--version` / `-version` output."""
    first = next((ln.strip() for ln in output.splitlines() if ln.strip()), "")
    if not first:
        return None
    if name == "yt-dlp":
        return first
    m = _FF_VERSION_RE.search(first)
    return m.group(1) if m else first


def version(name: str) -> str | None:
    exe = find(name)
    if exe is None:
        return None
    flag = "--version" if name == "yt-dlp" else "-version"
    try:
        cp = run([exe, flag], timeout=30)
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("Cannot get version of %s: %s", exe, exc)
        return None
    if cp.returncode != 0:
        log.warning("%s %s exited with %s: %s", exe, flag, cp.returncode, cp.stdout.strip())
        return None
    return parse_version(name, cp.stdout)


def status(name: str) -> BinaryStatus:
    exe = find(name)
    return BinaryStatus(name=name, path=exe, version=version(name) if exe else None)


def status_all() -> dict[str, BinaryStatus]:
    return {n: status(n) for n in NAMES}


def all_available() -> bool:
    return all(find(n) is not None for n in NAMES)


# --------------------------------------------------------------------------- download / install


def download(
    url: str,
    dest: Path,
    progress: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
) -> Path:
    """Download `url` to `dest` atomically (via a .tmp file next to it)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".tmp")
    log.info("GET %s -> %s", url, dest)
    req = Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with urlopen(req, timeout=60) as resp, tmp.open("wb") as fh:
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            if progress:
                progress(dest.name, 0, total)
            while True:
                if is_cancelled and is_cancelled():
                    raise CancelledError(url)
                chunk = resp.read(_CHUNK)
                if not chunk:
                    break
                fh.write(chunk)
                done += len(chunk)
                if progress:
                    progress(dest.name, done, total)
        tmp.replace(dest)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return dest


def _make_executable(path: Path) -> None:
    if not IS_WINDOWS:
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def install_ytdlp(progress: ProgressFn | None = None, is_cancelled: CancelFn | None = None) -> Path:
    dest = paths.bin_dir() / exe_name("yt-dlp")
    download(YTDLP_URL, dest, progress, is_cancelled)
    _make_executable(dest)
    log.info("yt-dlp installed: %s (%s)", dest, version("yt-dlp"))
    return dest


def extract_ffmpeg_archive(archive: Path, bin_dir: Path) -> list[Path]:
    """Pull `ffmpeg` and `ffprobe` out of a BtbN zip/tar.xz into `bin_dir`."""
    wanted = {exe_name("ffmpeg"), exe_name("ffprobe")}
    bin_dir.mkdir(parents=True, exist_ok=True)
    out: list[Path] = []

    if archive.suffix == ".zip":
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                base = Path(info.filename).name
                if base in wanted and not info.is_dir():
                    target = bin_dir / base
                    with zf.open(info) as src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
                    out.append(target)
    else:
        with tarfile.open(archive, "r:*") as tf:
            for member in tf.getmembers():
                base = Path(member.name).name
                if base in wanted and member.isfile():
                    target = bin_dir / base
                    src = tf.extractfile(member)
                    if src is None:
                        continue
                    with src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
                    out.append(target)

    if len(out) != 2:
        raise RuntimeError(
            f"Archive {archive.name} does not contain both ffmpeg and ffprobe (found: {out})"
        )
    for p in out:
        _make_executable(p)
    return out


def install_ffmpeg(
    progress: ProgressFn | None = None, is_cancelled: CancelFn | None = None
) -> list[Path]:
    with tempfile.TemporaryDirectory(prefix="mtb-ffmpeg-") as tmpdir:
        archive = Path(tmpdir) / Path(FFMPEG_URL).name
        download(FFMPEG_URL, archive, progress, is_cancelled)
        if progress:
            progress("extract", 0, 0)
        out = extract_ffmpeg_archive(archive, paths.bin_dir())
    log.info("ffmpeg installed: %s (%s)", out, version("ffmpeg"))
    return out


def install(
    name: str, progress: ProgressFn | None = None, is_cancelled: CancelFn | None = None
) -> list[Path]:
    """Install/update one binary by name. ffmpeg and ffprobe always come together."""
    if name == "yt-dlp":
        return [install_ytdlp(progress, is_cancelled)]
    if name in ("ffmpeg", "ffprobe"):
        return install_ffmpeg(progress, is_cancelled)
    raise ValueError(f"Unknown binary: {name}")
