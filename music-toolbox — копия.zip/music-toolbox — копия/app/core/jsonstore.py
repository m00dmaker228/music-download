"""Tiny JSON list store shared by profiles.py and presets.py."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, fields
from pathlib import Path

log = logging.getLogger(__name__)


def load_list[T](path: Path, cls: type[T]) -> list[T]:
    if not path.is_file():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log.warning("Cannot read %s: %s", path, exc)
        return []
    known = {f.name for f in fields(cls)}
    out: list[T] = []
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        try:
            out.append(cls(**{k: v for k, v in item.items() if k in known}))
        except TypeError as exc:
            log.warning("Skipping invalid entry in %s: %s", path.name, exc)
    return out


def save_list(path: Path, items: list) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps([asdict(i) for i in items], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    tmp.replace(path)
    return path
