"""Track search: yt-dlp `scsearchN:` / `ytsearchN:` in parallel, iTunes Search API for hints."""

from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from . import downloader
from .models import Track

log = logging.getLogger(__name__)

SOURCES = {"soundcloud": "scsearch", "youtube": "ytsearch"}
ITUNES_URL = "https://itunes.apple.com/search"
_UA = "MusicToolbox/0.1"


@dataclass(slots=True)
class ItunesHit:
    title: str
    artist: str
    album: str
    year: str
    duration: float | None = None


def search_source(query: str, source: str, limit: int = 10, timeout: float = 120) -> list[Track]:
    """One yt-dlp search; returns tracks with webpage URLs."""
    if source not in SOURCES:
        raise ValueError(f"невідоме джерело: {source}")
    query = query.strip()
    if not query:
        return []
    url = f"{SOURCES[source]}{limit}:{query}"
    info = downloader.list_playlist(url, timeout=timeout)
    out: list[Track] = []
    for t in info.entries:
        if not t.source or t.source == "unknown":
            t.source = source
        out.append(t)
    return out


def search_all(
    query: str, sources: list[str], limit: int = 10, timeout: float = 120
) -> dict[str, list[Track] | Exception]:
    """Run the selected sources concurrently; errors are returned per source, not raised."""
    results: dict[str, list[Track] | Exception] = {}
    if not sources:
        return results
    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        futures = {s: pool.submit(search_source, query, s, limit, timeout) for s in sources}
        for s, fut in futures.items():
            try:
                results[s] = fut.result()
            except Exception as exc:  # noqa: BLE001 — surfaced to the UI per source
                log.error("Search %s failed: %s", s, exc)
                results[s] = exc
    return results


def itunes_lookup(query: str, limit: int = 5, timeout: float = 15) -> list[ItunesHit]:
    """Reference metadata only (title, artist, album, year); nothing is downloaded."""
    query = query.strip()
    if not query:
        return []
    params = urlencode({"term": query, "entity": "song", "limit": limit})
    req = Request(f"{ITUNES_URL}?{params}", headers={"User-Agent": _UA})
    with urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    hits: list[ItunesHit] = []
    for r in data.get("results", []):
        date = str(r.get("releaseDate") or "")
        ms = r.get("trackTimeMillis")
        hits.append(
            ItunesHit(
                title=str(r.get("trackName") or ""),
                artist=str(r.get("artistName") or ""),
                album=str(r.get("collectionName") or ""),
                year=date[:4],
                duration=(ms / 1000) if ms else None,
            )
        )
    return hits
